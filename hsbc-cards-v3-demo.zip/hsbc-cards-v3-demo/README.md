# HSBC Commercial Cards — agentic decline triage (v3)

Everything needed to run the v3 demo: the process models, the decision tables, the forms, the
RPA scripts, the back-office simulator, the demo mailer and the documentation.

**No credentials are included.** `connectors.env.example` lists what you must supply.

---

## Start here

| Read | For |
|---|---|
| **`RUNBOOK.md`** | **Setting it up and running it, from nothing. Start here.** |
| **`SETUP-AND-CONFIGURATION.md`** | **Architecture, every connector's configuration, prompts, and the full variable reference** |
| `SCENARIOS.md` | The 18 scenarios + 7 intake edge cases, flows, and a 20-minute demo script |
| `TEST-DATA.md` | Cards, account numbers, contacts, and what each card has behind it |
| `MESSAGE-CORRELATION.md` | How e-mails are matched to cases. Read before changing any listener |
| `process/README.md` | Design decisions and the defect history |
| `process/BUILD-NOTES.md` | How the models were built; tool contracts |

---

## What is in the box

```
process/                    7 BPMN, 10 DMN, 5 forms, 4 RPA scripts  -> deploy in ONE deployment
  *.bpmn                    triage, intake, agent, communication, 2 tools, late-reply helper
  dmn/                      routing and policy decision tables
  forms/                    the human task forms
  rpa/                      DQM, MiVision, eChamps, inline-image robots
  prompts/                  verbatim AI system/user prompts (documentation)
simulator/                  the eight back-office screens (React + TS + Vite)
demo-mailer/                send_demo_email.py and per-scenario wrappers
scripts/
  set-mailbox-folder.sh     point all 7 listener references at your mail folder
connectors.env.example      the 8 secrets you must provide
```

## The shortest possible path

```bash
cp connectors.env.example connectors.env && $EDITOR connectors.env   # 1. secrets
scripts/set-mailbox-folder.sh INBOX                                  # 2. your mail folder
cd process && c8ctl deploy *.bpmn dmn/*.dmn forms/*.form rpa/*.rpa --profile <you> && cd ..
cd simulator && npm install && npm run build && npx serve -s dist/public -l 8080 &
# start the Camunda RPA worker, then:
python3 demo-mailer/send_demo_email.py nt-s6 --v3
```

Each step has a section in `RUNBOOK.md` explaining what it does and how it fails.

---

## Three things that will cost you an hour if you skip them

1. **The mail folder is probably not `INBOX`.** If your mailbox is plus-addressed, the server
   files mail into `INBOX.<tag>`, and the listeners must point there. The scripted mailer
   appends over IMAP and bypasses that filing, so **every scripted test can pass while every
   real e-mail is ignored**. `MESSAGE-CORRELATION.md` §4.
2. **Deploy everything in one deployment.** Call activities, DMNs and forms use
   `bindingType="deployment"`; a partial deploy silently binds against the wrong versions.
3. **The RPA worker must be running** before you send anything, with
   `secrets.backend=camunda`. Without it cases stall at the first lookup with no incident and
   no error message.

---

## Not included, and why

- **`rpaScripts/`** — byte-identical copies of the v2 robot originals. Their resource ids
  collide with v2's live resources; deploying them would overwrite v2. Never widen the deploy
  glob to `**/*.rpa`.
- **`node_modules/`, `dist/`** — run `npm install && npm run build` in `simulator/`.
- **Anything with a credential in it.** Cluster connection files and connector secrets are
  deliberately absent. See `connectors.env.example`.

---

## Status

Built and verified on **2026-11-06** against Camunda **8.9** SaaS. All 9 scenarios run; the
fraud path closes `RESOLVED` on both outcome branches; the three record-not-found scenarios
escalate with system-specific guidance. Zero incidents on the verification runs.

The demo stores a **full PAN** in the `triageFacts.cardNumber` process variable. This is a
demo convenience and **must not go to production**.
