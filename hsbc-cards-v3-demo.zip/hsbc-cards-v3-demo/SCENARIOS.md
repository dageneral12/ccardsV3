# Scenarios and demo flows

Two sets.

- **A. Nine decline scenarios, one card each, per presenter** (18 runs). Each presenter holds
  nine cards under Burj Khalifah Travel, one per scenario, so the e-mail comes from a real
  mailbox about a card the systems really hold. These are the main demo.
- **B. Seven intake edge cases**, sent as Jasmin Al Rashid. These exercise what happens when the
  e-mail itself is wrong — no card number, another company's card, an unauthorised sender.

Card numbers, account numbers and contacts: `TEST-DATA.md`.
Expected outcomes below were observed on live runs on 2026-11-06 unless marked otherwise.

---

## A. The nine decline scenarios

Send with `python3 demo-mailer/send_demo_email.py <cmd> --v3`, or compose the e-mail yourself
(see `RUNBOOK.md` §7).

| # | Scenario | Nikita | Kailash | Cards (NT / KN) | eChamps | Route | Ends as |
|---|---|---|---|---|---|---|---|
| S1 | Insufficient spend limit | `nt-s1` | `kn-s1` | 1010 / 1019 | `0023 OPENTOBUY` | `OUT_OF_SCOPE_ESCALATION` | handover |
| S2 | Fraud alert block | `nt-s2` | `kn-s2` | 2026 / 2025 | `0713 FALC DECL` | `FRAUD_ALERT` | **RESOLVED** |
| S3 | MCC restriction | `nt-s3` | `kn-s3` | 3032 / 3031 | `0728 AOV EXCEED` | `OUT_OF_SCOPE_ESCALATION` | handover |
| S4 | MID restriction | `nt-s4` | `kn-s4` | 4048 / 4047 | `0854 MID RESTR` | `OUT_OF_SCOPE_ESCALATION` | handover |
| S5 | Incorrect expiry date | `nt-s5` | `kn-s5` | 5052 / 5051 | `0080 EXP DTE KY` | `OUT_OF_SCOPE_ESCALATION` | handover |
| S6 | Incorrect CVV | `nt-s6` | `kn-s6` | 6068 / 6067 | `0076 INV CVV` | `INCORRECT_CVV` | **RESOLVED** |
| S7 | Virtual card — amount range | `nt-s7` | `kn-s7` | 7074 / 7073 | *no rows* | `RECORD_NOT_FOUND_ESCALATION` | handover → SDG2 |
| S8 | Virtual card — expiry mismatch | `nt-s8` | `kn-s8` | 8080 / 8089 | *no rows* | `RECORD_NOT_FOUND_ESCALATION` | handover → SDG2 |
| S9 | POS / Mastercard network decline | `nt-s9` | `kn-s9` | 9096 / 9095 | `NO DECLINE RECORD` | `RECORD_NOT_FOUND_ESCALATION` | handover → GHCS/MC |

### The two that close themselves

**S6 — incorrect CVV.** The cleanest end-to-end story and the one to lead with.

> Customer writes → DQM opens the sender's own case → MiVision confirms the card and cardholder
> → eChamps finds `0076 / INV CVV` → decision tables route to `INCORRECT_CVV` → agent drafts
> retry advice → **Mentor approves** → e-mail sent → agent waits → closes `RESOLVED`.

Two human touches: approving the e-mail, and nothing else. ~12 minutes end to end including
the reply wait; the Mentor task appears in 1–3 minutes.

**S2 — fraud alert.** The longest and the best for showing orchestration across humans.

> … eChamps finds `0713 / FALC DECL`, block `F` → agent e-mails the **fraud team** (internal, no
> Mentor) → waits → chases after the SLA if no answer → fraud team replies → `InterpretFraudReply`
> reads it → agent drafts the customer outcome → **Mentor approves** (and now sees what the fraud
> team actually said) → sent → closes `RESOLVED`.

Drive the fraud team's answer with:

```bash
python3 demo-mailer/send_demo_email.py fraud-reply HSBC-V3-<n>-1 keep --v3     # keep the block
python3 demo-mailer/send_demo_email.py fraud-reply HSBC-V3-<n>-1 remove --v3   # release it
```

Or reply to the fraud e-mail yourself from any mailbox — the fraud listener matches on the
subject tag, not the sender. Both outcome branches are verified:
`BLOCK_REMOVED` and `KEEP_BLOCK_REISSUE`.

### The four that escalate by design

S1, S3, S4 and S5 are **not failures**. The decline is real and correctly diagnosed, but the
remedy — raise a limit, lift an MCC or MID block, correct an expiry — is an action the agent is
not allowed to take. It hands over with the evidence attached. That is the point: the agent
knows the answer *and* knows it may not act on it.

S3 and S4 also leave evidence in WHIRL (AOV table 30, MID table 36) and S4 in GWIS, so you can
show the handler the exact restriction table.

### The three that route by what is *missing*

S7, S8 and S9 are the subtlest and worth rehearsing.

- **S7 / S8 (virtual cards).** eChamps holds no authorisation rows at all, because virtual-card
  declines are raised by InControl, not the authorisation host. The robot reports
  `NO_AUTH_RECORDS`, and MiVision's `cardForm = VIRTUAL` sends the handover note to **SDG2**,
  naming the purchase request.
- **S9 (network decline).** eChamps has activity on the card but no decline of any kind —
  `finalAction: No Record`. The robot reports `NO_DECLINE_ON_CARD`, and the handover note sends
  the handler down the **network path: GHCS, then Mastercard Connect**.

The line to use: *the absence of a record is itself the diagnosis.* A near miss — the customer
mistyped the date, and declines exist that simply do not match — still asks the customer to
confirm, which is the right first move. The system distinguishes the two.

---

## B. Intake edge cases (sent as Jasmin Al Rashid)

These test the e-mail, not the card. Run them with the shell wrappers or
`send_demo_email.py <name>`.

| Command | What is wrong with the e-mail | Expected |
|---|---|---|
| `s1-no-card.sh` | no card number anywhere | e-mail asks for the **last four digits only** |
| `s2-incomplete-card.sh` | fewer than 16 digits | e-mail asks for the full 16-digit number |
| `s3-other-company.sh` | a card not under this customer | e-mail asks the customer to check the card |
| `s4-cvv.sh` | nothing — the happy path | CVV retry advice, then `RESOLVED` |
| `s5-unauthorised.sh` | sender is not an authorised contact | notice to the authorised contact; nothing to the sender |
| `s6-fraud.sh` | nothing — fraud path | fraud-team e-mail, case waits |
| `s7-two-requests.sh` | two separate requests in one e-mail | escalation task, no customer e-mail |
| `screenshot.sh` | details only in a pasted image | agent reads the image (**needs the RPA worker**) |

`s5-unauthorised.sh` is the one that cannot be driven from your own mail client — it needs a
`From` that is not a seeded contact.

Follow-ups:

```bash
python3 demo-mailer/send_demo_email.py reply <caseId> "<text>" --v3
python3 demo-mailer/send_demo_email.py reply <caseId> "<text>" --v3 --as nt   # as a presenter
```

---

## Suggested 20-minute demo

1. **S6 as yourself**, from your own mail client. Show the e-mail leaving your Outlook/Gmail.
2. While it runs, show the **simulator** — these are the screens a human would open.
3. Show **Operate**: the robots driving DQM, MiVision, eChamps; the decision tables deciding,
   not the model.
4. **Approve the Mentor task.** Point out the agent drafted it and a person owns it.
5. Show the e-mail arriving back in your inbox.
6. **S9** for the contrast: the agent finds nothing, and *that* is the finding. Read the
   handover note aloud — it names GHCS and Mastercard Connect.
7. If there is time, **S2** for the fraud loop and the second human.

Start S2 early if you want it in the room — it has two waits.

---

## What each scenario proves

| Claim | Scenario |
|---|---|
| The agent does the clerical investigation a human would | S6 |
| Decisions are auditable tables, not model opinion | S1, S3, S4, S5 |
| A person owns every customer e-mail | all |
| The agent will not act beyond its authority | S1, S3, S4, S5 |
| It orchestrates across humans and time | S2 |
| It knows which system holds the answer | S7, S8, S9 |
| It asks only when asking can help | S9 vs a genuine near miss |
| It refuses unverified senders | `s5-unauthorised.sh` |
| It reads attachments | `screenshot.sh` |
