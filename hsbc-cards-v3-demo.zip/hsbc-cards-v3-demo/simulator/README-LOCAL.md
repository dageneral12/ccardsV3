# HSBC CCS System Simulator — Local Setup

This simulator is a frontend-only web app. It does not require a database, API
server, credentials, or environment secrets.

## Requirements

- Node.js 20 or newer
- npm 10 or newer

## Run in development mode

From this folder:

```bash
npm install
npm run dev
```

Open `http://localhost:5173`.

To use a different port:

**macOS/Linux**

```bash
PORT=8080 npm run dev
```

**Windows PowerShell**

```powershell
$env:PORT=8080; npm run dev
```

## Create and preview a production build

```bash
npm install
npm run build
npm run serve
```

Open `http://localhost:5173`.

The production-ready static files are generated in `dist/public`.

## Deploy under a URL subfolder

The default build is hosted at `/`. To deploy at a subfolder such as
`https://example.com/hsbc-sim/`, build with a matching base path:

**macOS/Linux**

```bash
BASE_PATH=/hsbc-sim/ npm run build
```

**Windows PowerShell**

```powershell
$env:BASE_PATH="/hsbc-sim/"; npm run build
```

Your web server must serve `index.html` as the fallback for unknown paths so
that direct links such as `/mivision/login` work.

### Nginx example

```nginx
server {
  listen 80;
  server_name _;

  root /var/www/hsbc-sim;
  index index.html;

  location / {
    try_files $uri $uri/ /index.html;
  }
}
```

Copy the contents of `dist/public` to `/var/www/hsbc-sim`.

## Deploy with a simple local static server

After running `npm run build`, you can use:

```bash
npx serve -s dist/public -l 8080
```

Then open `http://localhost:8080`.

## Notes

- All simulator data is stored in the frontend bundle and resets when the page
  is refreshed.
- This is a training simulator, not a connection to live HSBC systems.
- Do not expose it publicly with real customer or card data.