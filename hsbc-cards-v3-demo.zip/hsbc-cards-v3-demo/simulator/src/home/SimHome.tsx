import React from 'react';
import { Link } from 'wouter';
import { useSim } from '../context/SimContext';
import { MC_OTP, MIVISION_CLIENTS } from '../data/seed';
import { PRESENTERS } from '../data/presenters';

const SCENARIO_LABELS: Record<string, string> = {
  S1: 'Insufficient spend limit',
  S2: 'Fraud alert block',
  S3: 'MCC restriction',
  S4: 'MID restriction',
  S5: 'Incorrect expiry date',
  S6: 'Incorrect CVV',
  S7: 'Virtual card — amount range',
  S8: 'Virtual card — expiry mismatch',
  S9: 'POS / Mastercard network decline'
};

export default function SimHome() {
  const { state, dispatch } = useSim();

  return (
    <div className="min-h-screen bg-gray-100 font-sans pb-16">
      {/* Header */}
      <header className="bg-[#1a1a2e] text-white px-6 py-4 flex justify-between items-center">
        <div className="font-bold text-lg tracking-wide flex items-center gap-2">
          <div className="w-3 h-3 bg-white" /> HSBC
        </div>
        <div className="text-sm text-gray-400">Internal Systems</div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto mt-10 bg-white shadow-sm border border-gray-200 p-8 rounded-md">
        <h1 className="text-2xl font-bold text-[#212121] mb-2">GPS Commercial Cards Servicing — System Simulator</h1>
        <p className="text-[#595959] mb-8">PoC Build | Camunda DSM Agent</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
          {[
            { id: "dqm", name: "DQM", subtitle: "Microsoft Dynamics", link: "/dqm/cases", action: () => dispatch.LOGIN("dqm") },
            { id: "mivision", name: "MiVision", subtitle: "Card Account Portal", link: "/mivision/login" },
            { id: "echamps", name: "eChamps", subtitle: "Card Authorisation", link: "/echamps/login" },
            { id: "sdg2", name: "SDG2", subtitle: "Smart Data InControl", link: "/sdg2/login" },
            { id: "whirl", name: "WHIRL", subtitle: "HUB Core Cards", link: "/whirl/login" },
            { id: "gwis", name: "GWIS", subtitle: "Group Workflow & Image System", link: "/gwis/login" },
            { id: "ghcs", name: "GHCS", subtitle: "Solutions Center (IT Tickets)", link: "/ghcs/portal" },
            { id: "mastercard", name: "Mastercard Connect", subtitle: "Network Case Management", link: "/mastercard/login" },
          ].map(sys => (
            <div key={sys.id} className="border border-gray-200 p-4 rounded flex items-center justify-between hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-[#DB0011] flex items-center justify-center text-white font-bold text-xs rounded-sm">H</div>
                <div>
                  <div className="font-semibold text-[#212121]">{sys.name}</div>
                  <div className="text-xs text-[#595959]">{sys.subtitle}</div>
                </div>
              </div>
              <Link 
                href={sys.link} 
                onClick={sys.action}
                className="text-sm bg-gray-100 hover:bg-gray-200 px-3 py-1.5 border border-gray-300 rounded font-medium transition-colors"
                data-testid={`launch-${sys.id}`}
              >
                Launch →
              </Link>
            </div>
          ))}
        </div>

        {/* MFA / OTP Cheat Sheet */}
        <div className="mb-8">
          <h2 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-3">MFA Codes — Current Session</h2>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-amber-50 border border-amber-300 rounded p-3">
              <div className="text-xs font-bold text-amber-700 uppercase tracking-wider mb-1">SDG2 — One-Time Password</div>
              <div className="font-mono text-2xl font-bold tracking-[0.3em] text-amber-900" data-testid="home-sdg2-otp">{state.mfa.sdg2.otp}</div>
            </div>
            <div className="bg-amber-50 border border-amber-300 rounded p-3">
              <div className="text-xs font-bold text-amber-700 uppercase tracking-wider mb-1">Mastercard Connect — OTP</div>
              <div className="font-mono text-2xl font-bold tracking-[0.3em] text-amber-900" data-testid="home-mc-otp">{MC_OTP[state.activeScenario] ?? MC_OTP['S9']}</div>
            </div>
            <div className="bg-amber-50 border border-amber-300 rounded p-3">
              <div className="text-xs font-bold text-amber-700 uppercase tracking-wider mb-2">MiVision — Security Number</div>
              <div className="flex gap-1" data-testid="home-mivision-challenge">
                {state.mfa.mivision.securityNumber.split('').map((digit, i) => {
                  const pos = i + 1;
                  const isRequired = state.mfa.mivision.challenge.includes(pos);
                  return (
                    <div key={i} className={`w-7 h-8 flex flex-col items-center justify-between rounded ${isRequired ? 'bg-amber-400' : 'bg-amber-100'}`}>
                      <div className="text-[8px] font-bold text-amber-700 pt-0.5">{pos}</div>
                      <div className={`font-mono text-sm font-bold pb-0.5 ${isRequired ? 'text-amber-900' : 'text-amber-500'}`}>{digit}</div>
                    </div>
                  );
                })}
              </div>
              <div className="text-xs text-amber-600 mt-1">Highlighted = required positions</div>
            </div>
          </div>
        </div>

        {/* Presenter cards */}
        <div className="mb-8">
          <h2 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-1">Demo Cards</h2>
          <p className="text-xs text-[#595959] mb-3">
            Quote one of these card numbers in the e-mail you send from the matching mailbox. Every
            system here is keyed by card, so the card you name decides which scenario plays out —
            nothing has to be selected first.
          </p>
          {PRESENTERS.map(p => {
            const cards = MIVISION_CLIENTS[0].cards.filter(c => c.cardHolder === p.name);
            return (
              <div key={p.initials} className="border border-gray-200 rounded mb-3 overflow-hidden" data-testid={`presenter-${p.initials}`}>
                <div className="bg-gray-50 border-b border-gray-200 px-3 py-2 text-sm">
                  <span className="font-semibold text-[#212121]">{p.name}</span>
                  <span className="text-[#595959]"> — {p.jobTitle} · </span>
                  <span className="font-mono text-xs text-[#595959]">{p.email}</span>
                </div>
                <table className="w-full text-xs">
                  <tbody>
                    {cards.map(c => (
                      <tr key={c.lastFour} className="border-b border-gray-100 last:border-0">
                        <td className="px-3 py-1.5 font-mono w-44">{c.fullNumber}</td>
                        <td className="px-3 py-1.5 text-[#595959]">{SCENARIO_LABELS[c.scenarioId] ?? c.scenarioId}</td>
                        <td className="px-3 py-1.5 text-right text-[#595959] w-24">exp {c.expiry}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          })}
        </div>

        {/* Action Log */}
        <div>
          <h2 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-4">Agent Action Log</h2>
          <div className="border border-gray-200 rounded overflow-hidden">
            {state.agentActionLog.length === 0 ? (
              <div className="p-4 text-sm text-gray-500 text-center">No actions recorded in this session.</div>
            ) : (
              <div className="max-h-64 overflow-y-auto">
                {state.agentActionLog.map((log, i) => (
                  <div key={i} className="flex gap-4 p-3 border-b border-gray-100 last:border-0 text-sm">
                    <div className="text-gray-400 w-24 shrink-0 font-mono text-xs">{new Date(log.ts).toLocaleTimeString()}</div>
                    <div className="w-16 shrink-0 font-bold text-xs">[{log.system.toUpperCase()}]</div>
                    <div className="font-semibold">{log.event}</div>
                    <div className="text-gray-600 truncate">{log.detail}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Scenario Selector */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#1a1a2e] text-white px-6 py-3 flex items-center justify-between z-50">
        <div className="flex items-center gap-4 text-sm">
          <span className="font-semibold text-gray-300" title="Records are keyed by card, not by scenario. This only picks the SDG2 and Mastercard Connect demo OTPs.">MFA code set:</span>
          <select 
            value={state.activeScenario}
            onChange={(e) => dispatch.SET_SCENARIO(e.target.value)}
            className="bg-[#2a2a4a] border border-gray-600 rounded px-2 py-1 outline-none focus:ring-1 focus:ring-white"
            data-testid="scenario-selector"
          >
            <option value="S1">S1 — Insufficient Spend Limit (physical)</option>
            <option value="S2">S2 — Fraud Alert Block (physical)</option>
            <option value="S3">S3 — MCC Restriction (physical)</option>
            <option value="S4">S4 — MID Restriction (physical)</option>
            <option value="S5">S5 — Incorrect Expiry Date (physical)</option>
            <option value="S6">S6 — Incorrect CVV (physical)</option>
            <option value="S7">S7 — Virtual Card Amount Range (virtual)</option>
            <option value="S8">S8 — Virtual Card Expiry Mismatch (virtual)</option>
            <option value="S9">S9 — POS / Mastercard Network Decline (physical)</option>
          </select>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-xs text-gray-500 uppercase tracking-widest">RESTRICTED — Internal PoC use only</div>
          <button 
            onClick={() => dispatch.RESET_MFA()}
            className="text-xs bg-red-900 hover:bg-red-800 text-white px-3 py-1 rounded"
          >
            [Reset session]
          </button>
        </div>
      </div>
    </div>
  );
}
