import React, { useState } from 'react';
import { useLocation, useParams } from 'wouter';
import { useSim } from '../../context/SimContext';
import { BrowserChrome } from '../../shared/BrowserChrome';
import { SimHelper } from '../../shared/SimHelper';
import { ApprovalGateModal } from '../../shared/ApprovalGateModal';
import { MC_OTP, MC_CASES } from '../../data/seed';

// ─── Nav ──────────────────────────────────────────────────────────────────────

function McNav({ children, activePage }: { children: React.ReactNode; activePage?: string }) {
  const { state } = useSim();
  const [, setLocation] = useLocation();

  return (
    <BrowserChrome url="https://connect.mastercard.com/support">
      <div>
        <div className="bg-[#1a1a1a] px-6 py-3 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <div className="w-8 h-8 rounded-full bg-[#EB001B]" />
              <div className="w-8 h-8 rounded-full bg-[#F79E1B] -ml-4 opacity-90" />
            </div>
            <div className="text-white font-light text-lg ml-2">Mastercard <span className="font-bold">Connect</span></div>
          </div>
          {state.auth.mc && (
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <span className="cursor-pointer hover:text-white">My Profile</span>
              <span className="cursor-pointer hover:text-white">Preferences</span>
              <button onClick={() => setLocation('/mastercard/login')} className="text-orange-400 hover:text-orange-300 font-medium">Sign Out</button>
            </div>
          )}
        </div>

        {state.auth.mc && (
          <div className="bg-[#222] px-6 flex gap-6 text-sm border-t border-gray-700">
            <div
              onClick={() => setLocation('/mastercard/cases')}
              className={`py-3 cursor-pointer font-medium border-b-2 transition-colors ${activePage === 'cases' ? 'text-orange-400 border-orange-400' : 'text-gray-400 border-transparent hover:text-white hover:border-gray-500'}`}
            >
              Support Case Management
            </div>
            <div className="py-3 text-gray-600 cursor-default font-medium border-b-2 border-transparent">Resources</div>
            <div className="py-3 text-gray-600 cursor-default font-medium border-b-2 border-transparent">Alerts</div>
            <div className="py-3 text-gray-600 cursor-default font-medium border-b-2 border-transparent">Reports</div>
          </div>
        )}
      </div>
      <div className="bg-gray-100 min-h-[600px] p-8">
        {children}
      </div>
    </BrowserChrome>
  );
}

// ─── Login ────────────────────────────────────────────────────────────────────

export function McLogin() {
  const [, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation('/mastercard/login/otp');
  };

  return (
    <McNav>
      <div className="max-w-md mx-auto mt-12">
        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="bg-gradient-to-r from-[#EB001B] to-[#F79E1B] p-6 text-center">
            <div className="flex items-center justify-center gap-1 mb-2">
              <div className="w-10 h-10 rounded-full bg-[#EB001B] border-2 border-white" />
              <div className="w-10 h-10 rounded-full bg-[#F79E1B] -ml-5 border-2 border-white" />
            </div>
            <div className="text-white font-light text-xl">Mastercard <strong>Connect</strong></div>
            <div className="text-orange-100 text-xs mt-1">Secure Partner Portal</div>
          </div>

          <div className="p-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-6 text-center">Sign In</h2>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                <input
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-orange-400"
                  required
                  data-testid="input-mc-username"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input
                  type="password"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-orange-400"
                  required
                  data-testid="input-mc-password"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-[#EB001B] hover:bg-[#c00015] text-white font-semibold py-2.5 rounded-lg transition-colors shadow-sm mt-2"
                data-testid="btn-mc-signin"
              >
                Sign In
              </button>
            </form>
            <p className="text-xs text-gray-400 text-center mt-4">
              Mastercard Connect is for authorised partner institutions only.
            </p>
          </div>
        </div>
      </div>
    </McNav>
  );
}

// ─── OTP ──────────────────────────────────────────────────────────────────────

export function McOtp() {
  const { state, dispatch } = useSim();
  const [, setLocation] = useLocation();
  const [val, setVal] = useState('');
  const [error, setError] = useState('');

  const expectedOtp = MC_OTP[state.activeScenario] ?? MC_OTP['S9'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (val === expectedOtp) {
      dispatch.LOGIN('mc');
      dispatch.LOG_ACTION('mastercard', 'mfa_passed', null);
      setLocation('/mastercard/cases');
    } else {
      setError('Incorrect verification code. Please check and try again.');
    }
  };

  return (
    <McNav>
      <span data-testid="mc-otp-value" style={{ display: 'none' }}>{expectedOtp}</span>
      <SimHelper>Mastercard Connect OTP: {expectedOtp}</SimHelper>

      <div className="max-w-md mx-auto mt-12">
        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="bg-gradient-to-r from-[#EB001B] to-[#F79E1B] p-4 text-center">
            <div className="text-white font-semibold text-sm">Mastercard Connect — Two-Factor Verification</div>
          </div>

          <div className="p-8">
            <h2 className="text-lg font-semibold text-gray-800 mb-2">Verify Your Identity</h2>
            <p className="text-sm text-gray-500 mb-4 leading-relaxed">
              A one-time verification code has been sent to your registered email address. Please enter it below.
            </p>

            {/* Demo OTP display */}
            <div className="mb-5 bg-amber-50 border-2 border-amber-400 rounded-lg p-4 text-center">
              <div className="text-xs font-bold text-amber-700 uppercase tracking-wider mb-1">⚡ Demo Mode — Your OTP Code</div>
              <div className="font-mono text-3xl font-bold tracking-[0.35em] text-amber-900" data-testid="mc-otp-display">{expectedOtp}</div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded text-sm mb-4">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Verification Code</label>
                <input
                  value={val}
                  onChange={e => { setVal(e.target.value); setError(''); }}
                  className="w-full border border-gray-300 rounded-lg p-3 text-center tracking-[0.5em] text-lg font-mono outline-none focus:ring-2 focus:ring-orange-400"
                  maxLength={6}
                  required
                  data-testid="input-mc-otp"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-[#EB001B] hover:bg-[#c00015] text-white font-semibold py-2.5 rounded-lg transition-colors shadow-sm"
                data-testid="btn-mc-verify-otp"
              >
                Sign In
              </button>
              <div className="text-center">
                <button type="button" className="text-xs text-orange-600 hover:text-orange-800">Resend code</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </McNav>
  );
}

// ─── Cases List ───────────────────────────────────────────────────────────────

export function McCases() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<'active' | 'resolved'>('active');
  const [showNew, setShowNew] = useState(false);

  if (!state.auth.mc) {
    setLocation('/mastercard/login');
    return null;
  }

  const cases = MC_CASES;
  const activeCases = cases.filter(c => c.status !== 'Resolved');
  const resolvedCases = cases.filter(c => c.status === 'Resolved');
  const displayCases = activeTab === 'active' ? activeCases : resolvedCases;

  return (
    <McNav activePage="cases">
      <div className="max-w-5xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-xl font-semibold text-gray-800">Support Case Management</h1>
            <p className="text-sm text-gray-500 mt-1">View, create, and track Mastercard support cases.</p>
          </div>
          <button
            onClick={() => setLocation('/mastercard/cases/new')}
            className="bg-[#EB001B] hover:bg-[#c00015] text-white px-5 py-2 rounded-lg text-sm font-semibold shadow-sm transition-colors"
            data-testid="btn-mc-create-case"
          >
            + Create New Case
          </button>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg shadow-sm">
          <div className="border-b border-gray-200 flex">
            <button
              onClick={() => setActiveTab('active')}
              className={`px-6 py-3 text-sm font-semibold border-b-2 transition-colors ${activeTab === 'active' ? 'border-orange-500 text-orange-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
              data-testid="tab-mc-active"
            >
              Active Cases {activeCases.length > 0 && <span className="ml-1.5 bg-orange-100 text-orange-700 text-xs px-1.5 py-0.5 rounded-full">{activeCases.length}</span>}
            </button>
            <button
              onClick={() => setActiveTab('resolved')}
              className={`px-6 py-3 text-sm font-semibold border-b-2 transition-colors ${activeTab === 'resolved' ? 'border-orange-500 text-orange-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
              data-testid="tab-mc-resolved"
            >
              Resolved Cases {resolvedCases.length > 0 && <span className="ml-1.5 bg-green-100 text-green-700 text-xs px-1.5 py-0.5 rounded-full">{resolvedCases.length}</span>}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider border-b border-gray-200">
                <tr>
                  <th className="px-5 py-3 font-semibold">Case ID</th>
                  <th className="px-5 py-3 font-semibold">Subject</th>
                  <th className="px-5 py-3 font-semibold">Card Number</th>
                  <th className="px-5 py-3 font-semibold">Category</th>
                  <th className="px-5 py-3 font-semibold">Status</th>
                  <th className="px-5 py-3 font-semibold">Created</th>
                  <th className="px-5 py-3 font-semibold">Resolved</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {displayCases.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-5 py-12 text-center text-gray-400 italic">
                      No {activeTab} cases.
                    </td>
                  </tr>
                ) : (
                  displayCases.map((c, i) => (
                    <tr key={i} className="hover:bg-orange-50/30 transition-colors">
                      <td className="px-5 py-4">
                        <button
                          onClick={() => setLocation(`/mastercard/cases/${encodeURIComponent(c.caseId)}`)}
                          className="font-mono text-orange-700 hover:text-orange-900 font-semibold hover:underline text-sm"
                          data-testid={`link-mc-case-${i}`}
                        >
                          {c.caseId}
                        </button>
                      </td>
                      <td className="px-5 py-4 text-gray-700 max-w-xs truncate">{c.subject}</td>
                      <td className="px-5 py-4 font-mono text-gray-600 text-xs">{c.cardNumber}</td>
                      <td className="px-5 py-4 text-gray-600 text-xs">{c.category}<br /><span className="text-gray-400">{c.subCategory}</span></td>
                      <td className="px-5 py-4">
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${c.status === 'Resolved' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`} data-testid={`mc-case-status-${i}`}>
                          {c.status}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-gray-500 text-xs">{c.createdDate}</td>
                      <td className="px-5 py-4 text-gray-500 text-xs">{c.resolvedDate ?? '—'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </McNav>
  );
}

// ─── New Case ─────────────────────────────────────────────────────────────────

export function McNewCase() {
  const { state, dispatch } = useSim();
  const [, setLocation] = useLocation();
  const [modalOpen, setModalOpen] = useState(false);

  if (!state.auth.mc) {
    setLocation('/mastercard/login');
    return null;
  }

  // Prefills from ?card=<last four> so a presenter raising a case for their own card gets
  // their own details; with no card named it falls back to the first case.
  const cardParam = new URLSearchParams(window.location.search).get('card') ?? '';
  const existingCase = MC_CASES.find(c => c.cardLastFour === cardParam) ?? MC_CASES[0];

  const [subject, setSubject] = useState(existingCase?.subject ?? '');
  const [cardNumber, setCardNumber] = useState(existingCase?.cardNumber ?? '');
  const [category, setCategory] = useState(existingCase?.category ?? 'Transaction Investigation');
  const [subCategory, setSubCategory] = useState(existingCase?.subCategory ?? '');
  const [details, setDetails] = useState('');

  return (
    <McNav activePage="cases">
      <div className="max-w-3xl mx-auto">
        <div className="mb-4">
          <button onClick={() => setLocation('/mastercard/cases')} className="text-orange-600 hover:text-orange-800 text-sm font-medium">
            ← Back to Cases
          </button>
        </div>

        <div className="mb-5">
          <h1 className="text-xl font-semibold text-gray-800 mb-1">Create New Support Case</h1>
          <p className="text-sm text-gray-500">Complete the form below to submit a new case to Mastercard.</p>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); setModalOpen(true); }} className="bg-white border border-gray-200 rounded-lg shadow-sm divide-y divide-gray-100">
          <div className="p-6 space-y-5">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Case Subject <span className="text-red-500">*</span></label>
              <input
                value={subject}
                onChange={e => setSubject(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-400"
                required
                data-testid="input-mc-subject"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1">Category <span className="text-red-500">*</span></label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-400 bg-white"
                  data-testid="select-mc-category"
                >
                  <option>Transaction Investigation</option>
                  <option>Fraud Dispute</option>
                  <option>Chargeback</option>
                  <option>Technical Issue</option>
                  <option>Network Connectivity</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1">Sub-Category</label>
                <select
                  value={subCategory}
                  onChange={e => setSubCategory(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-400 bg-white"
                  data-testid="select-mc-subcategory"
                >
                  <option>POS Decline — Network</option>
                  <option>Unposted Transaction</option>
                  <option>Duplicate Charge</option>
                  <option>Merchant Dispute</option>
                  <option>ATM Decline</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Card Number <span className="text-red-500">*</span></label>
              <input
                value={cardNumber}
                onChange={e => setCardNumber(e.target.value)}
                placeholder="e.g. 5550-4100-9901-6614"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm font-mono outline-none focus:ring-2 focus:ring-orange-400"
                required
                data-testid="input-mc-new-card"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Case Details <span className="text-red-500">*</span></label>
              <textarea
                value={details}
                onChange={e => setDetails(e.target.value)}
                placeholder="Describe the issue in detail, including transaction date, merchant name, amount, and any relevant context..."
                rows={5}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-400 resize-none"
                required
                data-testid="input-mc-details"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Attachments</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-5 text-center text-sm text-gray-400 cursor-pointer hover:border-orange-400 hover:text-orange-400 transition-colors">
                📎 Drag & drop files here, or click to attach transaction receipts
              </div>
            </div>
          </div>

          <div className="px-6 py-4 bg-gray-50 flex justify-between items-center">
            <button type="button" onClick={() => setLocation('/mastercard/cases')} className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-100">
              Cancel
            </button>
            <button type="submit" className="bg-[#EB001B] hover:bg-[#c00015] text-white px-8 py-2 rounded-lg text-sm font-semibold shadow-sm" data-testid="btn-mc-submit-case">
              Submit Case
            </button>
          </div>
        </form>
      </div>

      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={(v) => {
          setModalOpen(v);
          if (!v) {
            dispatch.LOG_ACTION('mastercard', 'case_submitted', `New case: ${subject} — ${cardNumber}`);
            setLocation('/mastercard/cases');
          }
        }}
        system="Mastercard Connect"
        actionDesc={`Submit Support Case to Mastercard: "${subject}" — Card: ${cardNumber} — Category: ${category} / ${subCategory}`}
      />
    </McNav>
  );
}

// ─── Case Detail ──────────────────────────────────────────────────────────────

export function McCaseDetail() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams<{ caseId: string }>();

  if (!state.auth.mc) {
    setLocation('/mastercard/login');
    return null;
  }

  const caseId = decodeURIComponent(params.caseId ?? '');
  const c = MC_CASES.find(x => x.caseId === caseId);

  if (!c) {
    return (
      <McNav activePage="cases">
        <div className="text-center py-16 text-gray-500">Case not found.</div>
      </McNav>
    );
  }

  return (
    <McNav activePage="cases">
      <div className="max-w-3xl mx-auto">
        <div className="mb-4">
          <button onClick={() => setLocation('/mastercard/cases')} className="text-orange-600 hover:text-orange-800 text-sm font-medium">
            ← Back to Cases
          </button>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg shadow-sm divide-y divide-gray-100">
          <div className="p-6 flex justify-between items-start">
            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-1">{c.subject}</h2>
              <p className="font-mono text-sm text-orange-700 font-semibold" data-testid="mc-case-id">{c.caseId}</p>
            </div>
            <span className={`px-3 py-1 rounded-full text-sm font-semibold ${c.status === 'Resolved' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`} data-testid="mc-detail-status">
              {c.status}
            </span>
          </div>

          <div className="p-6">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4">Case Details</h3>
            <div className="grid grid-cols-2 gap-4">
              <CRow label="Case ID" value={c.caseId} mono testId="mc-detail-case-id" />
              <CRow label="Card Number" value={c.cardNumber} mono testId="mc-detail-card" />
              <CRow label="Category" value={c.category} testId="mc-detail-category" />
              <CRow label="Sub-Category" value={c.subCategory} testId="mc-detail-subcat" />
              <CRow label="Created" value={c.createdDate} testId="mc-detail-created" />
              <CRow label="Resolved" value={c.resolvedDate ?? '—'} testId="mc-detail-resolved" />
            </div>
          </div>

          {c.resolution && (
            <div className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center text-white text-xs">✓</div>
                <h3 className="text-sm font-bold text-green-700 uppercase tracking-wider">Investigation Resolution</h3>
              </div>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-sm text-gray-700 leading-relaxed" data-testid="mc-detail-resolution">{c.resolution}</p>
              </div>
              <div className="mt-3 bg-blue-50 border border-blue-200 rounded p-3 text-xs text-blue-700">
                Please share the investigation outcome with the client via DQM Reply All, then resolve the DQM case.
              </div>
            </div>
          )}
        </div>
      </div>
    </McNav>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function CRow({ label, value, testId, mono }: { label: string; value: string; testId?: string; mono?: boolean }) {
  return (
    <div>
      <div className="text-xs text-gray-500 mb-0.5">{label}</div>
      <div className={`text-sm text-gray-800 font-medium ${mono ? 'font-mono' : ''}`} data-testid={testId}>{value}</div>
    </div>
  );
}
