import React, { useState } from 'react';
import { useLocation, Link, useParams } from 'wouter';
import { useSim } from '../../context/SimContext';
import { BrowserChrome } from '../../shared/BrowserChrome';
import { SimHelper } from '../../shared/SimHelper';
import { StatusPill } from '../../shared/StatusPill';
import { ApprovalGateModal } from '../../shared/ApprovalGateModal';
import { DQM_CASES, MIVISION_CLIENTS, DqmCase } from '../../data/seed';
import { SimState } from '../../context/SimContext';
import { Star, ChevronDown, ChevronRight, Menu, Search } from 'lucide-react';

function getDqmCases(state: SimState): DqmCase[] {
  const base = [...DQM_CASES, ...state.dqmSplitCases];
  return base.map(c => state.dqmCaseOverrides[c.id] ? { ...c, ...state.dqmCaseOverrides[c.id] } : c);
}

const CASE_TYPE_OPTIONS = ["Unknown", "Transaction Related"];
const CASE_SUB_TYPE_OPTIONS = ["Unknown", "Decline, Transaction not going through"];

function DqmNav({ children, title }: { children: React.ReactNode, title?: string }) {
  return (
    <BrowserChrome url="https://dqm.internal.hsbc.com/main.aspx">
      <div className="bg-[#1a1a2e] text-white flex justify-between items-center px-4 h-12">
        <div className="flex items-center gap-3">
          <svg width="24" height="24" viewBox="0 0 16 16"><polygon points="8,0 14,4 14,12 8,16 2,12 2,4" fill="white"/><text x="8" y="12" textAnchor="middle" fill="#DB0011" fontSize="8" fontWeight="bold">H</text></svg>
          <span className="font-semibold tracking-wide">DQM</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <div className="w-8 h-8 rounded-full bg-gray-500 flex items-center justify-center text-xs font-bold">SM</div>
          <span>Service Manager</span>
        </div>
      </div>
      <div className="bg-white border-b border-gray-300 flex px-4 gap-6 text-sm overflow-x-auto">
        <div className="py-2 text-gray-500 cursor-pointer">CSS</div>
        <div className="py-2 text-gray-500 cursor-pointer">Cases My Assigned Cases...</div>
        <div className="py-2 text-[#DB0011] border-b-2 border-[#DB0011] font-medium whitespace-nowrap">Cases Specialist view</div>
      </div>
      <div className="p-4 flex-1">
        {children}
      </div>
      <SimHelper>DQM loaded. No MFA required.</SimHelper>
    </BrowserChrome>
  );
}

export function DqmLogin() {
  const [, setLocation] = useLocation();
  const { dispatch } = useSim();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch.LOGIN("dqm");
    setLocation("/dqm/cases");
  };

  return (
    <DqmNav>
      <div className="max-w-md mx-auto mt-20 border border-gray-300 p-8 bg-white shadow-sm">
        <h2 className="text-xl font-bold mb-6 text-[#212121]">Sign in to DQM</h2>
        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          <input className="border border-gray-300 p-2 text-sm outline-none" placeholder="Username" required data-testid="input-username" />
          <input className="border border-gray-300 p-2 text-sm outline-none" type="password" placeholder="Password" required data-testid="input-password" />
          <button type="submit" className="bg-[#1a1a2e] text-white p-2 font-semibold hover:bg-black mt-2" data-testid="button-submit">Sign In</button>
        </form>
      </div>
    </DqmNav>
  );
}

export function DqmCases() {
  const { state, dispatch } = useSim();
  const [, setLocation] = useLocation();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [deleteModal, setDeleteModal] = useState(false);

  if (!state.auth.dqm) {
    setLocation("/dqm/login");
    return null;
  }

  const cases = getDqmCases(state);
  const splitCaseIds = new Set(state.dqmSplitCases.map(c => c.id));
  const selectableIds = cases.filter(c => splitCaseIds.has(c.id)).map(c => c.id);
  const selectedSplitIds = selectedIds.filter(id => splitCaseIds.has(id));
  const allSelectableSelected = selectableIds.length > 0 && selectableIds.every(id => selectedIds.includes(id));

  const toggleRow = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const toggleAll = () => {
    setSelectedIds(allSelectableSelected ? [] : selectableIds);
  };

  const handleBulkDeleteConfirm = () => {
    selectedSplitIds.forEach(id => dispatch.DQM_DELETE_SPLIT_CASE(id));
    setSelectedIds([]);
    setDeleteModal(false);
  };

  return (
    <DqmNav>
      <div className="border border-gray-300 bg-white">
        {/* Toolbar */}
        <div className="flex justify-between items-center border-b border-gray-300 px-3 py-2 bg-gray-50 text-sm">
          <div className="flex gap-4 items-center">
            <span className="text-[#0070C0] cursor-pointer font-medium flex items-center">Show As <ChevronDown className="w-4 h-4 ml-1"/></span>
            <span className="text-[#0070C0] cursor-pointer">Show Chart</span>
            <span className="text-[#0070C0] cursor-pointer">+ New Case</span>
            <span className="text-[#0070C0] cursor-pointer">↺ Refresh</span>
            <span className="text-[#0070C0] cursor-pointer">Collaborate</span>
            {selectedSplitIds.length > 0 && (
              <span
                className="text-red-600 cursor-pointer font-medium"
                onClick={() => setDeleteModal(true)}
                data-testid="btn-bulk-delete"
              >
                Delete Selected ({selectedSplitIds.length})
              </span>
            )}
          </div>
          <div className="flex gap-3 items-center">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-2 top-1.5 text-gray-400"/>
              <input type="text" placeholder="Filter by keyword" className="border border-gray-300 pl-8 pr-2 py-1 text-sm outline-none w-48" />
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm whitespace-nowrap">
            <thead>
              <tr className="bg-gray-100 border-b border-gray-300 text-gray-700">
                <th className="p-2 w-8">
                  <input
                    type="checkbox"
                    checked={allSelectableSelected}
                    onChange={toggleAll}
                    disabled={selectableIds.length === 0}
                    title={selectableIds.length === 0 ? "No split cases available to delete. Split a case first (Case Detail > Split Case)." : "Select all split cases"}
                    data-testid="checkbox-select-all"
                  />
                </th>
                <th className="p-2 w-8"></th>
                <th className="p-2 w-8">⭐</th>
                <th className="p-2 font-normal">Status</th>
                <th className="p-2 font-normal">Subject</th>
                <th className="p-2 font-normal">Contact</th>
                <th className="p-2 font-normal">Owner</th>
                <th className="p-2 font-normal">Current Mailbox</th>
                <th className="p-2 font-normal">Case Number</th>
                <th className="p-2 font-normal">Client</th>
                <th className="p-2 font-normal">Case Type</th>
                <th className="p-2 font-normal">Case Sub-Type</th>
                <th className="p-2 font-normal">Created On</th>
              </tr>
            </thead>
            <tbody>
              {cases.map((c, i) => {
                const isSplitCase = splitCaseIds.has(c.id);
                return (
                  <tr key={c.id} className={`border-b border-gray-200 hover:bg-[#f0f7ff] ${c.cardLastFour === state.activeCardLastFour ? 'bg-[#e8f4fd] font-medium' : i % 2 === 0 ? 'bg-white' : 'bg-[#fafafa]'}`} data-testid={`case-row-${c.id}`}>
                    <td className="p-2">
                      <input
                        type="checkbox"
                        checked={selectedIds.includes(c.id)}
                        onChange={() => toggleRow(c.id)}
                        disabled={!isSplitCase}
                        title={isSplitCase ? "Select for bulk delete" : "Original cases cannot be deleted, only split cases"}
                        data-testid={`checkbox-case-${c.id}`}
                      />
                    </td>
                    <td className="p-2"><ChevronRight className="w-4 h-4 text-gray-400"/></td>
                    <td className="p-2"><div className="w-4 h-4 bg-amber-500 rounded-full flex items-center justify-center"><Star className="w-2.5 h-2.5 text-white fill-white"/></div></td>
                    <td className="p-2"><StatusPill status={c.status} /></td>
                    {/* Who the case came from. A real case queue shows this, and it lets the DQM
                        robot pick the sender's own case without opening every case in the list. */}
                    <td className="p-2 text-gray-700">
                      <div>{c.email.contactName}</div>
                      <div className="text-xs text-gray-500" data-testid={`case-contact-${c.id}`}>{c.email.from}</div>
                    </td>
                    <td className="p-2 text-gray-700">{c.owner}</td>
                    <td className="p-2 text-gray-600">{c.mailbox}</td>
                    <td className="p-2 text-[#0070C0] hover:underline"><Link href={`/dqm/cases/${c.id}`}>{c.id}</Link></td>
                    <td className="p-2 text-[#0070C0] hover:underline"><Link href={`/dqm/clients/${c.clientId}`}>{c.client}</Link></td>
                    <td className="p-2 text-gray-600">{c.caseType}</td>
                    <td className="p-2 text-gray-600">{c.caseSubType}</td>
                    <td className="p-2 text-gray-600">{c.createdOn}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      {deleteModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50" data-testid="modal-bulk-delete-case">
          <div className="bg-white rounded shadow-lg w-full max-w-md p-6">
            <h3 className="font-bold text-[#212121] mb-2">Delete {selectedSplitIds.length} Case{selectedSplitIds.length !== 1 ? 's' : ''}</h3>
            <p className="text-sm text-gray-600 mb-4">
              This will permanently delete the following split case{selectedSplitIds.length !== 1 ? 's' : ''}: <span className="font-semibold">{selectedSplitIds.join(', ')}</span>. This action cannot be undone. Continue?
            </p>
            <div className="flex justify-end gap-3 text-sm">
              <button className="px-4 py-2 border border-gray-300 rounded" onClick={() => setDeleteModal(false)} data-testid="btn-bulk-delete-cancel">Cancel</button>
              <button className="px-4 py-2 bg-red-600 text-white rounded" onClick={handleBulkDeleteConfirm} data-testid="btn-bulk-delete-confirm">Delete</button>
            </div>
          </div>
        </div>
      )}
    </DqmNav>
  );
}

export function DqmCaseDetail() {
  const { state, dispatch } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const allCases = getDqmCases(state);
  const c = allCases.find(x => x.id === params.caseId);
  const parentCase = c?.splitFromCaseId ? allCases.find(x => x.id === c.splitFromCaseId) : undefined;

  const handleCaseTypeChange = (caseType: string) => {
    if (!c) return;
    dispatch.DQM_CLASSIFY_CASE(c.id, { caseType, caseSubType: c.caseSubType || "Unknown" });
  };
  const handleCaseSubTypeChange = (caseSubType: string) => {
    if (!c) return;
    dispatch.DQM_CLASSIFY_CASE(c.id, { caseType: c.caseType || "Unknown", caseSubType });
  };
  const handleOwnerChange = (owner: string) => {
    if (!c) return;
    dispatch.DQM_CLASSIFY_CASE(c.id, { caseType: c.caseType || "Unknown", caseSubType: c.caseSubType || "Unknown", owner });
  };

  if (!state.auth.dqm) {
    setLocation("/dqm/login");
    return null;
  }
  if (!c) return <DqmNav>Case not found</DqmNav>;

  return (
    <DqmNav>
      <div className="text-xs text-gray-500 mb-2 flex items-center gap-1">
        <Link href="/dqm/cases" className="text-[#0070C0] hover:underline">🏠 Home</Link>
        <span>/</span>
        <span className="text-[#212121]">{c.subject}</span>
        <Link href="/dqm/cases" className="ml-1 text-gray-400 hover:text-gray-700">×</Link>
      </div>
      <div className="bg-white border border-gray-300">
        <div className="flex px-4 gap-6 text-sm border-b border-gray-300 bg-gray-50">
          <div className="py-2 text-[#0070C0] border-b-2 border-[#0070C0] font-medium">Summary</div>
          <div className="py-2 text-gray-600">Case Relationships</div>
          <div className="py-2 text-gray-600">Operations</div>
          <div className="py-2 text-gray-600">Original Email</div>
        </div>

        {(() => {
          const [resolveModal, setResolveModal] = React.useState(false);
          const [splitModal, setSplitModal] = React.useState(false);
          const [deleteModal, setDeleteModal] = React.useState(false);
          const isSplitCase = Boolean(c.splitFromCaseId);

          const handleSplitConfirm = () => {
            const newCaseId = dispatch.DQM_SPLIT_CASE(c.id);
            setSplitModal(false);
            if (newCaseId) setLocation(`/dqm/cases/${newCaseId}`);
          };

          const handleDeleteConfirm = () => {
            dispatch.DQM_DELETE_SPLIT_CASE(c.id);
            setDeleteModal(false);
            setLocation('/dqm/cases');
          };

          return (
            <>
              <div className="flex border-b border-gray-300 px-3 py-2 bg-gray-50 text-sm gap-4 text-[#0070C0]">
                <span className="cursor-pointer hover:underline">Save</span>
                <span className="cursor-pointer hover:underline" onClick={() => setLocation('/dqm/cases')} data-testid="btn-save-close">Save &amp; Close</span>
                <span className="cursor-pointer hover:underline font-semibold" onClick={() => setResolveModal(true)} data-testid="btn-resolve-case">Resolve</span>
                <span className="cursor-pointer hover:underline" onClick={() => setSplitModal(true)} data-testid="btn-split-case">Split Case</span>
                <span className="cursor-pointer hover:underline text-gray-400">Cancel Case</span>
                {isSplitCase && (
                  <span className="cursor-pointer hover:underline text-red-600 ml-auto" onClick={() => setDeleteModal(true)} data-testid="btn-delete-case">Delete Case</span>
                )}
              </div>
              <ApprovalGateModal open={resolveModal} onOpenChange={setResolveModal} system="DQM" actionDesc={`Resolve case ${c.id} and close`} />
              {splitModal && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50" data-testid="modal-split-case">
                  <div className="bg-white rounded shadow-lg w-full max-w-md p-6">
                    <h3 className="font-bold text-[#212121] mb-2">Split Case</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      This will create a new, unclassified case with a copy of all data from case {c.id}, assigned to <span className="font-semibold">Yachnit Sharma</span> for classification. Continue?
                    </p>
                    <div className="flex justify-end gap-3 text-sm">
                      <button className="px-4 py-2 border border-gray-300 rounded" onClick={() => setSplitModal(false)} data-testid="btn-split-cancel">Cancel</button>
                      <button className="px-4 py-2 bg-[#0070C0] text-white rounded" onClick={handleSplitConfirm} data-testid="btn-split-confirm">Split Case</button>
                    </div>
                  </div>
                </div>
              )}
              {deleteModal && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50" data-testid="modal-delete-case">
                  <div className="bg-white rounded shadow-lg w-full max-w-md p-6">
                    <h3 className="font-bold text-[#212121] mb-2">Delete Case</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      This will permanently delete split case <span className="font-semibold">{c.id}</span>. This action cannot be undone. Continue?
                    </p>
                    <div className="flex justify-end gap-3 text-sm">
                      <button className="px-4 py-2 border border-gray-300 rounded" onClick={() => setDeleteModal(false)} data-testid="btn-delete-cancel">Cancel</button>
                      <button className="px-4 py-2 bg-red-600 text-white rounded" onClick={handleDeleteConfirm} data-testid="btn-delete-confirm">Delete Case</button>
                    </div>
                  </div>
                </div>
              )}
            </>
          );
        })()}

        <div className="flex">
          {/* Timeline */}
          <div className="w-[60%] border-r border-gray-300 p-4 min-h-[500px]">
            <h3 className="font-bold text-[#212121] mb-4 flex items-center justify-between">
              Email Timeline
              <span className="text-gray-400 font-normal space-x-2">+ ☐ ▼ ℹ ↺ ⋮</span>
            </h3>
            
            <div className="flex gap-3 mb-6">
              <div className="w-8 h-8 rounded-full bg-purple-200 text-purple-800 flex items-center justify-center font-bold text-xs shrink-0">
                {c.email.from.charAt(0).toUpperCase()}
              </div>
              <div className="border border-gray-200 rounded p-3 w-full bg-gray-50">
                <div className="flex justify-between items-start mb-2">
                  <div className="font-bold text-sm">{c.email.subject}</div>
                  <div className="text-xs text-gray-500">{c.createdOn}</div>
                </div>
                <div className="text-sm text-gray-600 line-clamp-2 mb-3">{c.email.body}</div>
                <Link href={`/dqm/cases/${c.id}/email`} className="text-xs bg-white border border-gray-300 px-3 py-1 rounded hover:bg-gray-100" data-testid="button-open-email">
                  Open Record
                </Link>
              </div>
            </div>
          </div>

          {/* Metadata */}
          <div className="w-[40%] p-4 bg-[#fafafa]">
            <div className="flex justify-between items-center mb-6">
              <div className="text-sm">
                <span className="text-gray-500">Priority:</span>{' '}
                <span className={c.priority === 'High' ? 'text-red-600 font-bold' : 'text-gray-700'}>{c.priority} ˅</span>
              </div>
              <StatusPill status={c.status} />
              <div className="text-sm"><span className="text-gray-500">Info Classification:</span> Restricted ˅</div>
            </div>

            <div className="space-y-4 text-sm">
              <div><span className="text-gray-500 inline-block w-36">Client:</span> <Link href={`/dqm/clients/${c.clientId}`} className="text-[#0070C0]">{c.client}</Link></div>
              <div><span className="text-gray-500 inline-block w-36">Client Tier:</span> GPS Premium</div>
              <div><span className="text-gray-500 inline-block w-36">Product:</span> ● Cards</div>
              <div className="flex items-center">
                <span className="text-gray-500 inline-block w-36">Case Type:</span>
                <select
                  className="border border-gray-300 p-1 text-sm outline-none bg-white flex-1"
                  value={c.caseType || "Unknown"}
                  onChange={e => handleCaseTypeChange(e.target.value)}
                  data-testid="select-casetype"
                >
                  {CASE_TYPE_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-center">
                <span className="text-gray-500 inline-block w-36">Case Sub-Type:</span>
                <select
                  className="border border-gray-300 p-1 text-sm outline-none bg-white flex-1"
                  value={c.caseSubType || "Unknown"}
                  onChange={e => handleCaseSubTypeChange(e.target.value)}
                  data-testid="select-casesubtype"
                >
                  {CASE_SUB_TYPE_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
              <div><span className="text-gray-500 inline-block w-36">Sub-Type Category:</span> {c.caseSubTypeCategory}</div>
              <div className="flex items-center">
                <span className="text-gray-500 inline-block w-36">Assigned To:</span>
                <input
                  className="border border-gray-300 p-1 text-sm outline-none flex-1"
                  defaultValue={c.owner}
                  onBlur={e => handleOwnerChange(e.target.value)}
                  data-testid="input-owner"
                  key={c.owner}
                />
              </div>

              <div className="border-t border-gray-300 pt-4 mt-4 font-bold text-xs tracking-wider text-gray-500">APPLICABLE SLA</div>
              <div><span className="text-gray-500 inline-block w-36">SLA First Response By:</span> {c.slaFirstResponseBy}</div>
              <div><span className="text-gray-500 inline-block w-36">SLA Resolve By:</span> {c.slaResolveBy}</div>

              <div className="border-t border-gray-300 pt-4 mt-4 font-bold text-xs tracking-wider text-gray-500">CASE DETAILS</div>
              <div><span className="text-gray-500 inline-block w-36">Case Number:</span> {c.id}</div>
              <div><span className="text-gray-500 inline-block w-36">Account Number:</span> <span className="font-mono">{c.accountNumber}</span></div>
              <div><span className="text-gray-500 inline-block w-36">Created On:</span> {c.createdOn}</div>
              <div><span className="text-gray-500 inline-block w-36">Country:</span> 🇦🇪 {c.country}</div>
              {c.splitFromCaseId && (
                <div>
                  <span className="text-gray-500 inline-block w-36 align-top">Split From Case ⓘ:</span>{' '}
                  {parentCase ? (
                    <Link href={`/dqm/cases/${c.splitFromCaseId}`} className="text-[#0070C0] hover:underline" data-testid="link-split-from-case">
                      {c.splitFromCaseId}
                    </Link>
                  ) : (
                    <span data-testid="text-split-from-case">{c.splitFromCaseId}</span>
                  )}
                </div>
              )}

            </div>
          </div>
        </div>
      </div>
    </DqmNav>
  );
}

export function DqmEmail() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const c = getDqmCases(state).find(x => x.id === params.caseId);
  const client = c ? MIVISION_CLIENTS.find(x => x.id === c.clientId) : undefined;
  const [modalDesc, setModalDesc] = useState('');

  if (!state.auth.dqm) {
    setLocation("/dqm/login");
    return null;
  }
  if (!c) return null;

  return (
    <DqmNav>
      <div className="text-xs text-gray-500 mb-2 flex items-center gap-1">
        <Link href="/dqm/cases" className="text-[#0070C0] hover:underline">🏠 Home</Link>
        <span>/</span>
        <Link href={`/dqm/cases/${c.id}`} className="text-[#0070C0] hover:underline">{c.subject}</Link>
        <span>/</span>
        <span className="text-[#212121]">Email Record</span>
        <Link href={`/dqm/cases/${c.id}`} className="ml-1 text-gray-400 hover:text-gray-700">×</Link>
      </div>
      <div className="bg-white border border-gray-300 flex flex-col">
        <div className="flex px-4 gap-6 text-sm border-b border-gray-300 bg-gray-50">
          <div className="py-2 text-[#0070C0] border-b-2 border-[#0070C0] font-medium">Email</div>
        </div>
        
        <div className="flex border-b border-gray-300 px-3 py-2 bg-gray-50 text-sm gap-4 text-[#0070C0]">
          <span className="cursor-pointer" onClick={() => setLocation(`/dqm/cases/${c.id}/email-draft`)} data-testid="btn-reply">Reply</span>
          <span className="cursor-pointer font-semibold" onClick={() => setLocation(`/dqm/cases/${c.id}/email-draft`)} data-testid="btn-reply-all">Reply all</span>
          <span className="cursor-pointer" onClick={() => setModalDesc(`Forward email to fraud prevention team — CSS-UAE-FraudPrev@hsbc.com`)} data-testid="btn-forward">→ Forward</span>
        </div>

        <div className="flex flex-1 min-h-[500px]">
          <div className="w-[70%] border-r border-gray-300 p-6 flex flex-col">
            <div className="grid grid-cols-[100px_1fr] gap-2 text-sm mb-6 items-center">
              <div className="text-gray-500">Subject:</div>
              <div className="font-semibold">{c.email.subject}</div>
              <div className="text-gray-500">From:</div>
              <div className="text-[#0070C0]">{c.email.from}</div>
              <div className="text-gray-500">Regarding:</div>
              <div className="text-[#0070C0]">{c.subject}</div>
            </div>
            
            <textarea 
              readOnly 
              className="w-full flex-1 border border-gray-300 p-4 text-sm font-sans outline-none resize-none bg-gray-50"
              value={c.email.body}
            />
          </div>

          <div className="w-[30%] p-4 bg-[#fafafa] overflow-y-auto">
            <div className="border border-gray-300 rounded bg-white p-3 mb-4 shadow-sm">
              <h4 className="font-bold text-xs text-gray-700 mb-2 uppercase">Sender</h4>
              <div className="text-sm">
                <div className="font-medium text-[#0070C0]">{c.email.contactName}</div>
                <div className="text-gray-500 text-xs">{c.email.from}</div>
                <div className="text-gray-500 text-xs mt-0.5">{c.email.contactTitle} — {c.email.contactRole}</div>
                {!c.email.authorisedContact && (
                  <div className="mt-1 text-xs bg-red-50 text-red-700 inline-block px-2 py-0.5 rounded border border-red-300">
                    Unauthorised
                  </div>
                )}
              </div>
            </div>

            {client?.authorisedContacts && client.authorisedContacts.length > 0 && (
              <div className="border border-gray-300 rounded bg-white p-3 shadow-sm">
                <h4 className="font-bold text-xs text-gray-700 mb-2 uppercase">External Contacts</h4>
                <table className="w-full text-xs" data-testid="table-authorised-contacts">
                  <thead>
                    <tr className="text-gray-500 border-b border-gray-200">
                      <th className="text-left font-semibold pb-1 pr-1">Name</th>
                      <th className="text-left font-semibold pb-1 pr-1">Email Address</th>
                      <th className="text-left font-semibold pb-1 pr-1">Job Title</th>
                      <th className="text-left font-semibold pb-1 pr-1">Primary Role</th>
                      <th className="text-left font-semibold pb-1">Secondary Role</th>
                    </tr>
                  </thead>
                  <tbody>
                    {client.authorisedContacts.map((ac, i) => (
                      <tr key={i} className="border-b border-gray-100" data-testid={`authorised-contact-row-${i}`}>
                        <td className="py-1 pr-1 font-medium text-[#212121]" data-testid={`authorised-contact-name-${i}`}>{ac.name}</td>
                        <td className="py-1 pr-1 text-gray-600" data-testid={`authorised-contact-email-${i}`}>{ac.email}</td>
                        <td className="py-1 pr-1 text-gray-600">{ac.jobTitle}</td>
                        <td className="py-1 pr-1 text-gray-600">{ac.primaryRole}</td>
                        <td className="py-1 text-gray-600">{ac.secondaryRole || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
      <ApprovalGateModal 
        open={!!modalDesc} 
        onOpenChange={open => { if (!open) setModalDesc(''); }} 
        system="DQM" 
        actionDesc={modalDesc} 
      />
    </DqmNav>
  );
}

function getDraftBody(c: DqmCase): string {
  const cat = c.caseSubTypeCategory ?? '';
  const name = c.email.contactName;

  if (cat.includes('Virtual Card') && cat.includes('Incorrect Card Details') && c.declineReason?.toLowerCase().includes('expiry')) {
    const actualExpiry = c.vcnExpiry ?? 'N/A';
    return `Dear ${name},\n\nThank you for contacting HSBC Commercial Cards Servicing.\n\nWe have investigated the decline on your virtual card ending ${c.cardLastFour} at ${c.createdOn.split(' ')[0]}.\n\nThe transaction was declined due to an incorrect expiry date entered at the time of the transaction (InControl Response: Expiry Match Fail). The correct expiry date on the virtual card is ${actualExpiry}. Please re-attempt the transaction entering the correct virtual card expiry date.\n\nShould you require any further assistance, please do not hesitate to contact us.\n\nKind regards,\nHSBC Commercial Cards Servicing\nGPS UAE`;
  }
  if (cat.includes('Incorrect Card Details') && c.declineReason?.toLowerCase().includes('expiry')) {
    return `Dear ${name},\n\nThank you for contacting HSBC Commercial Cards Servicing.\n\nWe have reviewed your query regarding the declined transaction on card ending ${c.cardLastFour} at the point of sale on ${c.createdOn.split(' ')[0]}.\n\nThe transaction was declined due to an incorrect expiry date entered at the point of sale. Please re-attempt the transaction using the correct expiry date printed on the card.\n\nShould you require any further assistance, please do not hesitate to contact us.\n\nKind regards,\nHSBC Commercial Cards Servicing\nGPS UAE`;
  }
  if (cat.includes('Incorrect Card Details') && c.declineReason?.toLowerCase().includes('cvv')) {
    return `Dear ${name},\n\nThank you for contacting HSBC Commercial Cards Servicing.\n\nWe have reviewed your query regarding the declined transaction on card ending ${c.cardLastFour} at the point of sale on ${c.createdOn.split(' ')[0]}.\n\nThe transaction was declined due to an incorrect CVV entered at the point of sale (decline code 0076/INV CVV). Please re-attempt the transaction entering the correct 3-digit CVV printed on the reverse of the card.\n\nShould you require any further assistance, please do not hesitate to contact us.\n\nKind regards,\nHSBC Commercial Cards Servicing\nGPS UAE`;
  }
  if (cat.includes('Incorrect Card Details')) {
    return `Dear ${name},\n\nThank you for contacting HSBC Commercial Cards Servicing.\n\nWe have reviewed your query regarding the declined transaction on card ending ${c.cardLastFour}.\n\nThe transaction was declined due to incorrect card details entered at the point of sale. Please verify the card details and re-attempt the transaction.\n\nKind regards,\nHSBC Commercial Cards Servicing\nGPS UAE`;
  }
  if (cat.includes('Virtual Card') && cat.includes('Amount Control')) {
    const prId = c.purchaseRequestId ?? 'N/A';
    const min = c.purchaseRequestMin ?? 'N/A';
    const max = c.purchaseRequestMax ?? 'N/A';
    const requestor = c.requestorName ?? 'the card requestor';
    return `Dear ${name},\n\nThank you for contacting HSBC Commercial Cards Servicing.\n\nWe have investigated the decline on your virtual card ending ${c.cardLastFour}.\n\nThe transaction was declined because the transaction amount falls outside the Exact Amount Range Control configured on Purchase Request ID ${prId} (minimum: AED ${min} — maximum: AED ${max}). Any transaction amount outside this range will be automatically declined.\n\nTo resolve this, please ask the requestor ${requestor} to log in to Smart Data InControl (SDG2), navigate to Purchase Requests > View Requests, locate Purchase Request ID ${prId}, and click the pencil icon to edit the Exact Amount Range to accommodate the intended transaction amount. Please note that the updated purchase request will require approval from the designated approver before the card can be used.\n\nShould you require any further assistance, please do not hesitate to contact us.\n\nKind regards,\nHSBC Commercial Cards Servicing\nGPS UAE`;
  }
  if (cat.includes('AOV') || cat.includes('Amount')) {
    return `Dear ${name},\n\nThank you for contacting HSBC Commercial Cards Servicing.\n\nWe have reviewed the declined transaction on card ending ${c.cardLastFour}.\n\nThe transaction was declined as it exceeded the single transaction (AOV) limit configured for this card programme. Please contact your Relationship Manager to request a limit amendment if required.\n\nKind regards,\nHSBC Commercial Cards Servicing\nGPS UAE`;
  }
  if (cat.includes('POS') || cat.includes('Network Decline')) {
    return `Dear ${name},\n\nThank you for contacting HSBC Commercial Cards Servicing.\n\nWe have received your query regarding the declined transaction on card ending ${c.cardLastFour}. We were unable to locate a decline record for this transaction in our card authorisation system (eChamps), which indicates the decline may have occurred at the Mastercard network or merchant terminal level.\n\nTo assist with the investigation, we kindly request the following:\n\n1. Please provide the transaction receipt from the POS terminal.\n2. Please confirm whether the POS machine was functioning correctly at the time of the transaction.\n3. Please check if the card is working at other POS terminals or ATMs to rule out a card or terminal fault.\n\nWe are escalating this matter to our IT team and raising a Mastercard Connect investigation ticket. We will revert with an update as soon as possible.\n\nKind regards,\nHSBC Commercial Cards Servicing\nGPS UAE`;
  }
  return `Dear ${name},\n\nThank you for contacting HSBC Commercial Cards Servicing.\n\nWe have reviewed your recent query and will provide an update shortly.\n\nKind regards,\nHSBC Commercial Cards Servicing\nGPS UAE`;
}

export function DqmEmailDraft() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const c = getDqmCases(state).find(x => x.id === params.caseId);
  const client = c ? MIVISION_CLIENTS.find(x => x.id === c.clientId) : undefined;
  const [modalOpen, setModalOpen] = useState(false);
  const [ccRecipients, setCcRecipients] = useState<Array<{ name: string; email: string }>>(c?.email.originalCc ?? []);
  const [ccInput, setCcInput] = useState('');

  if (!state.auth.dqm) {
    setLocation("/dqm/login");
    return null;
  }
  if (!c) return null;

  const isAuthorised = c.email.authorisedContact;

  const authorisedEmails = new Set((client?.authorisedContacts ?? []).map(a => a.email.toLowerCase()));
  const isEmailAuthorised = (email: string) => authorisedEmails.has(email.trim().toLowerCase());

  const addCcRecipient = () => {
    const value = ccInput.trim().replace(/,$/, '');
    if (!value) return;
    if (ccRecipients.some(r => r.email.toLowerCase() === value.toLowerCase())) {
      setCcInput('');
      return;
    }
    setCcRecipients(prev => [...prev, { name: value, email: value }]);
    setCcInput('');
  };

  const removeCcRecipient = (email: string) => {
    setCcRecipients(prev => prev.filter(r => r.email !== email));
  };

  const anyUnauthorised = !isAuthorised || ccRecipients.some(r => !isEmailAuthorised(r.email));

  return (
    <DqmNav>
      <div className="text-xs text-gray-500 mb-2 flex items-center gap-1">
        <Link href="/dqm/cases" className="text-[#0070C0] hover:underline">🏠 Home</Link>
        <span>/</span>
        <Link href={`/dqm/cases/${c.id}`} className="text-[#0070C0] hover:underline">{c.subject}</Link>
        <span>/</span>
        <Link href={`/dqm/cases/${c.id}/email`} className="text-[#0070C0] hover:underline">Email Record</Link>
        <span>/</span>
        <span className="text-[#212121]">Reply All</span>
        <Link href={`/dqm/cases/${c.id}/email`} className="ml-1 text-gray-400 hover:text-gray-700">×</Link>
      </div>

      {anyUnauthorised && (
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-3 mb-4 text-sm flex items-center gap-2 text-yellow-800">
          ⚠ One or more recipients are not on the client's authorised contact list — please verify before sending
        </div>
      )}

      <div className="bg-white border border-gray-300 flex flex-col">
        <div className="flex border-b border-gray-300 px-3 py-2 bg-gray-50 text-sm gap-4 text-[#0070C0]">
          <span className="cursor-pointer font-semibold" onClick={() => setModalOpen(true)} data-testid="btn-send">Send</span>
          <span className="cursor-pointer text-gray-500">Save Draft</span>
          <span className="cursor-pointer text-gray-500">Discard</span>
        </div>

        <div className="p-6 text-sm space-y-3">
          {/* To field */}
          <div className="flex gap-3 items-start">
            <div className="w-14 text-gray-500 pt-1.5 shrink-0">To:</div>
            <div className="flex flex-wrap gap-2 flex-1 border border-gray-200 rounded p-2 min-h-[36px]">
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium border ${
                  isAuthorised
                    ? 'border-gray-300 bg-gray-100 text-[#212121]'
                    : 'border-red-400 bg-red-50 text-red-700'
                }`}
                data-testid="recipient-to"
              >
                {!isAuthorised && <span className="text-red-600 font-bold">✗</span>}
                {c.email.contactName} &lt;{c.email.from}&gt;
                <span className="ml-1 cursor-pointer opacity-60 hover:opacity-100">×</span>
              </span>
            </div>
          </div>

          {/* CC field */}
          <div className="flex gap-3 items-start">
            <div className="w-14 text-gray-500 pt-1.5 shrink-0">CC:</div>
            <div className="flex flex-wrap gap-2 flex-1 border border-gray-200 rounded p-2 min-h-[36px] focus-within:border-[#0070C0]">
              {ccRecipients.map((r) => {
                const authorised = isEmailAuthorised(r.email);
                return (
                  <span
                    key={r.email}
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium border ${
                      authorised
                        ? 'border-gray-300 bg-gray-100 text-[#212121]'
                        : 'border-red-400 bg-red-50 text-red-700'
                    }`}
                    data-testid={`recipient-cc-${r.email}`}
                  >
                    {!authorised && <span className="text-red-600 font-bold">✗</span>}
                    {r.name}
                    <span
                      className="ml-1 cursor-pointer opacity-60 hover:opacity-100"
                      onClick={() => removeCcRecipient(r.email)}
                      data-testid={`remove-cc-${r.email}`}
                    >
                      ×
                    </span>
                  </span>
                );
              })}
              <input
                className="flex-1 min-w-[160px] border-none outline-none text-sm py-0.5"
                placeholder="Add CC recipients…"
                value={ccInput}
                onChange={e => setCcInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' || e.key === ',' || e.key === 'Tab') {
                    e.preventDefault();
                    addCcRecipient();
                  }
                }}
                onBlur={addCcRecipient}
                data-testid="input-cc"
              />
            </div>
          </div>

          {/* Subject */}
          <div className="flex gap-3 items-center">
            <div className="w-14 text-gray-500 shrink-0">Subject:</div>
            <input
              className="flex-1 border border-gray-200 rounded px-2 py-1 text-sm outline-none focus:border-[#0070C0]"
              defaultValue={`RE: ${c.email.subject}`}
              data-testid="input-subject"
            />
          </div>

          {/* Body */}
          <textarea
            className="w-full min-h-[280px] border border-gray-300 rounded p-4 text-sm font-sans outline-none focus:border-[#0070C0]"
            defaultValue={getDraftBody(c)}
            data-testid="input-body"
          />

          {/* Recipient verification panel */}
          <div className={`border rounded p-3 ${anyUnauthorised ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-gray-50'}`} data-testid="panel-recipient-verification">
            <div className="font-bold text-xs mb-2 uppercase tracking-wider text-gray-600">Recipient Verification</div>
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm" data-testid="verify-row-to">
                <span className={`font-semibold ${isAuthorised ? 'text-[#212121]' : 'text-red-700'}`}>
                  {c.email.contactName}
                </span>
                <span className="text-gray-500 text-xs">({c.email.contactTitle} — {c.email.contactRole})</span>
                {!isAuthorised ? (
                  <span className="text-xs px-2 py-0.5 rounded border ml-auto bg-red-100 text-red-800 border-red-300">
                    ✗ Not Authorised — not on client's contact list
                  </span>
                ) : (
                  <span className="text-xs text-gray-500 ml-auto">On client's authorised contact list</span>
                )}
              </div>
              {ccRecipients.map((r) => {
                const authorised = isEmailAuthorised(r.email);
                return (
                  <div key={r.email} className="flex items-center gap-2 text-sm" data-testid={`verify-row-cc-${r.email}`}>
                    <span className={`font-semibold ${authorised ? 'text-[#212121]' : 'text-red-700'}`}>
                      {r.name}
                    </span>
                    <span className="text-gray-500 text-xs">(CC{r.email !== r.name ? ` — ${r.email}` : ''})</span>
                    {!authorised ? (
                      <span className="text-xs px-2 py-0.5 rounded border ml-auto bg-red-100 text-red-800 border-red-300">
                        ✗ Not Authorised — not on client's contact list
                      </span>
                    ) : (
                      <span className="text-xs text-gray-500 ml-auto">On client's authorised contact list</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* External Contacts reference table for cross-verification */}
          {client?.authorisedContacts && client.authorisedContacts.length > 0 && (
            <div className="border border-gray-300 rounded p-3">
              <h4 className="font-bold text-xs text-gray-600 mb-2 uppercase tracking-wider">External Contacts</h4>
              <table className="w-full text-xs" data-testid="table-authorised-contacts">
                <thead>
                  <tr className="text-gray-500 border-b border-gray-200">
                    <th className="text-left font-semibold pb-1 pr-1">Name</th>
                    <th className="text-left font-semibold pb-1 pr-1">Email Address</th>
                    <th className="text-left font-semibold pb-1 pr-1">Job Title</th>
                    <th className="text-left font-semibold pb-1 pr-1">Primary Role</th>
                    <th className="text-left font-semibold pb-1">Secondary Role</th>
                  </tr>
                </thead>
                <tbody>
                  {client.authorisedContacts.map((ac, i) => (
                    <tr key={i} className="border-b border-gray-100" data-testid={`authorised-contact-row-${i}`}>
                      <td className="py-1 pr-1 font-medium text-[#212121]" data-testid={`authorised-contact-name-${i}`}>{ac.name}</td>
                      <td className="py-1 pr-1 text-gray-600" data-testid={`authorised-contact-email-${i}`}>{ac.email}</td>
                      <td className="py-1 pr-1 text-gray-600">{ac.jobTitle}</td>
                      <td className="py-1 pr-1 text-gray-600">{ac.primaryRole}</td>
                      <td className="py-1 text-gray-600">{ac.secondaryRole || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        system="DQM"
        actionDesc={`Send reply-all to ${c.email.contactName} <${c.email.from}> regarding case ${c.id}`}
      />
    </DqmNav>
  );
}

export function DqmClient() {
  const params = useParams();
  const client = MIVISION_CLIENTS.find(x => x.id === params.clientId);
  if (!client) return <DqmNav>Client not found</DqmNav>;

  return (
    <DqmNav>
      <div className="text-xs text-gray-500 mb-2 flex items-center gap-1">
        <Link href="/dqm/cases" className="text-[#0070C0] hover:underline">🏠 Home</Link>
        <span>/</span>
        <span className="text-[#212121]">{client.clientName}</span>
      </div>
      <div className="bg-white border border-gray-300">
        <div className="p-6 flex items-center gap-6 border-b border-gray-300 bg-[#f8f9fa]">
          <div className="w-16 h-16 bg-pink-600 text-white rounded-full flex items-center justify-center text-2xl font-bold">
            {client.initialsAvatar}
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#212121]">{client.clientName}</h2>
            <div className="text-sm text-gray-500 mt-1">LLC · Saved | Restricted Information Classification</div>
          </div>
        </div>
        <div className="p-6 grid grid-cols-2 gap-8 text-sm border-b border-gray-200">
          <div>
            <h3 className="font-bold text-gray-600 mb-4 uppercase tracking-wide text-xs">Information</h3>
            <div className="grid grid-cols-[140px_1fr] gap-3">
              <div className="text-gray-500">Relationship Type:</div><div>Client</div>
              <div className="text-gray-500">CIN:</div><div>{client.cin}</div>
              <div className="text-gray-500">Country:</div><div>🌐 {client.country}</div>
              <div className="text-gray-500">Client Tier:</div><div className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded inline-block w-max font-medium">{client.tier}</div>
            </div>
          </div>
          <div>
            <h3 className="font-bold text-gray-600 mb-4 uppercase tracking-wide text-xs">Active Accounts</h3>
            <div className="border border-gray-200 rounded p-4 bg-gray-50">
              <div className="font-mono text-sm text-[#0070C0] mb-2">{client.cards[0].companyAccountMasked}</div>
              <div className="text-gray-500 text-xs">Primary Billing Account</div>
            </div>
          </div>
        </div>

        {client.internalContacts && client.internalContacts.length > 0 && (
          <div className="p-6 text-sm">
            <h3 className="font-bold text-gray-600 mb-4 uppercase tracking-wide text-xs">Internal Contacts</h3>
            <div className="space-y-4">
              {client.internalContacts.map((ic, i) => (
                <div key={i} className="border border-gray-200 rounded p-4 bg-gray-50 grid grid-cols-[140px_1fr] gap-2">
                  <div className="text-gray-500">Name:</div>
                  <div className="font-semibold text-[#212121]" data-testid={`rm-name-${i}`}>{ic.name}</div>
                  <div className="text-gray-500">Role:</div>
                  <div>{ic.role}</div>
                  <div className="text-gray-500">Email:</div>
                  <div className="text-[#0070C0]" data-testid={`rm-email-${i}`}>{ic.email}</div>
                  <div className="text-gray-500">Phone:</div>
                  <div>{ic.phone}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </DqmNav>
  );
}
