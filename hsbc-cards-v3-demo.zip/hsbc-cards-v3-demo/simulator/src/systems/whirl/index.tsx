import React, { useState } from 'react';
import { useLocation, useParams } from 'wouter';
import { useSim } from '../../context/SimContext';
import { BrowserChrome } from '../../shared/BrowserChrome';
import { ApprovalGateModal } from '../../shared/ApprovalGateModal';
import { WHIRL_AOV, WHIRL_CARD_TABLES, WHIRL_MID, MIVISION_CLIENTS } from '../../data/seed';

function WhirlNav({ children }: { children: React.ReactNode }) {
  const { state } = useSim();
  const [, setLocation] = useLocation();

  return (
    <BrowserChrome url="https://hubcore.systems.hsbc/whirl">
      <div className="bg-[#f0f0f0] min-h-[600px] font-mono text-sm text-[#333]">
        <div className="bg-[#333] text-white px-4 py-1.5 flex justify-between items-center shadow-md">
          <div className="font-bold tracking-widest text-[15px]">HUB Core Cards — WHIRL</div>
          {state.auth.whirl && (
            <div className="flex gap-4 text-xs">
              <span>OpId: SYSTEM</span>
              <button onClick={() => setLocation('/whirl/login')} className="hover:text-gray-300 underline">Logoff</button>
            </div>
          )}
        </div>
        <div className="p-6">
          {children}
        </div>
      </div>
    </BrowserChrome>
  );
}

// ─── WH-01: Login (LOGON APPLID + credentials) ───────────────────────────────

export function WhirlLogin() {
  const [, setLocation] = useLocation();
  const { dispatch } = useSim();
  const [phase, setPhase] = useState<'logon' | 'login'>('logon');

  const handleLogon = (e: React.FormEvent) => {
    e.preventDefault();
    setPhase('login');
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch.LOGIN("whirl");
    setLocation("/whirl/search");
  };

  if (phase === 'logon') {
    return (
      <WhirlNav>
        <form onSubmit={handleLogon} className="max-w-2xl mx-auto mt-10">
          <div className="bg-black text-green-400 font-mono p-6 min-h-[260px] border-2 border-[#444] shadow-[4px_4px_0_#999]">
            <div className="mb-4 text-green-300 text-xs tracking-widest uppercase">HUB Core Cards — WHIRL Terminal v4.2</div>
            <div className="mb-2 text-green-600 text-xs">READY</div>
            <div className="flex items-center gap-2 mb-8">
              <span className="text-green-500 text-lg">&gt;</span>
              <input
                className="bg-transparent border-none outline-none text-green-400 w-72 font-mono caret-green-400 text-sm"
                defaultValue="LOGON APPLID (EPCCM134)"
                readOnly
                data-testid="input-logon-command"
              />
              <span className="animate-pulse text-green-400 text-lg leading-none">█</span>
            </div>
            <div className="text-xs text-green-800">Press Enter to connect to EPCCM134</div>
          </div>
          <div className="flex justify-end mt-3">
            <button
              type="submit"
              className="bg-gray-200 border-2 border-[#333] px-8 py-1.5 font-bold hover:bg-gray-300 shadow-[2px_2px_0_#333] active:shadow-none"
              data-testid="btn-logon-enter"
            >
              Enter
            </button>
          </div>
        </form>
      </WhirlNav>
    );
  }

  return (
    <WhirlNav>
      <div className="max-w-md mx-auto mt-16 border-2 border-[#333] bg-white shadow-[4px_4px_0_#999]">
        <div className="bg-[#333] text-white font-bold p-2 text-center uppercase tracking-widest border-b-2 border-[#333]">
          Authorised Access Only
        </div>
        <form onSubmit={handleLogin} className="p-8 space-y-6">
          <div className="flex items-center justify-between">
            <label className="font-bold w-24">Staff ID</label>
            <input
              className="border-2 border-gray-400 p-1 flex-1 outline-none focus:border-[#333] uppercase"
              required
              data-testid="input-whirl-userid"
            />
          </div>
          <div className="flex items-center justify-between">
            <label className="font-bold w-24">Password</label>
            <input
              type="password"
              className="border-2 border-gray-400 p-1 flex-1 outline-none focus:border-[#333]"
              required
              data-testid="input-whirl-password"
            />
          </div>
          <div className="pt-4 flex justify-end">
            <button
              type="submit"
              className="bg-gray-200 border-2 border-[#333] px-6 py-1.5 font-bold hover:bg-gray-300 shadow-[2px_2px_0_#333] active:shadow-none"
              data-testid="btn-whirl-login"
            >
              Login
            </button>
          </div>
        </form>
      </div>
    </WhirlNav>
  );
}

// ─── WH-02: ARQE — Card Number Entry ─────────────────────────────────────────

export function WhirlSearch() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const [cardNum, setCardNum] = useState("");

  if (!state.auth.whirl) {
    setLocation("/whirl/login");
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cardNum) setLocation(`/whirl/card/${cardNum.trim()}`);
  };

  return (
    <WhirlNav>
      <div className="bg-[#222] text-green-400 font-mono px-4 py-2 mb-6 flex items-center gap-4 -mx-6 -mt-6">
        <span className="text-[#888] text-xs">Command:</span>
        <span className="bg-[#111] border border-[#444] px-2 py-0.5 text-green-300 text-xs">[ ARQE ]</span>
        <span className="text-gray-600 text-xs ml-auto">PF3=Exit · Enter to submit</span>
      </div>

      <div className="max-w-2xl mx-auto mt-4">
        <div className="bg-[#e0e0e0] border border-gray-400 p-2 font-bold mb-4 uppercase tracking-widest text-center text-sm">
          Card Account Enquiry — ARQE
        </div>

        <form onSubmit={handleSubmit} className="bg-white border-2 border-gray-400 p-6 shadow-[2px_2px_0_#ccc]">
          <div className="grid grid-cols-[160px_1fr] gap-4 items-center mb-4">
            <label className="font-bold text-right pr-4">Card Number</label>
            <input
              value={cardNum}
              onChange={e => setCardNum(e.target.value)}
              className="border-2 border-gray-300 p-1 outline-none focus:border-blue-500 w-64 uppercase"
              placeholder="e.g. 7404 or full card number"
              required
              data-testid="input-whirl-card"
            />

            <label className="font-bold text-right pr-4">Page Number</label>
            <input
              value={WHIRL_CARD_TABLES[cardNum.replace(/\D/g, '').slice(-4)]?.page ?? '30'}
              readOnly
              className="border-2 border-gray-300 p-1 outline-none focus:border-blue-500 w-16"
              data-testid="input-whirl-page"
            />
          </div>
          <div className="border-t-2 border-gray-200 pt-4 flex justify-center mt-6">
            <button
              type="submit"
              className="bg-[#005090] text-white border-2 border-[#003060] px-8 py-1.5 font-bold hover:bg-[#004080] shadow-[2px_2px_0_#003060]"
              data-testid="btn-whirl-search"
            >
              Enter
            </button>
          </div>
        </form>
      </div>
    </WhirlNav>
  );
}

// ─── WH-03: ARQE Result — Card Detail + AOV Table Number (Page 30) ───────────

export function WhirlCard() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();

  if (!state.auth.whirl) {
    setLocation("/whirl/login");
    return null;
  }

  const client = MIVISION_CLIENTS[0];
  const card = client.cards.find(c =>
    c.lastFour === params.cardNumber ||
    c.fullMasked.replace(/-/g, '') === (params.cardNumber ?? '').replace(/-/g, '')
  );
  // Which table this card's programme points at. Keyed by the card, so the screen follows
  // whichever card was searched for rather than a globally selected scenario.
  const aovInfo = WHIRL_CARD_TABLES[card?.lastFour ?? ''] ?? { tableNumber: '30', org: '031', logo: '741', page: '30', tableType: 'AOV' as const };
  const tableType = aovInfo.tableType ?? 'AOV';
  const isMid = tableType === 'MID';

  return (
    <WhirlNav>
      <div className="bg-[#222] text-green-400 font-mono px-4 py-2 mb-4 flex items-center gap-4 -mx-6 -mt-6">
        <span className="text-[#888] text-xs">Command:</span>
        <span className="bg-[#111] border border-[#444] px-2 py-0.5 text-green-300 text-xs">[ ARQE ]</span>
        <span className="text-gray-600 text-xs ml-auto">PF3=Exit · PF7/PF8=Scroll</span>
      </div>

      {!card ? (
        <div className="max-w-2xl mx-auto mt-8">
          <div className="bg-red-50 border border-red-300 p-4 text-red-700 font-mono text-sm">
            Card not found — check card number and retry.
          </div>
          <button onClick={() => setLocation('/whirl/search')} className="mt-3 bg-gray-200 border-2 border-[#333] px-4 py-1 font-bold">
            [Back]
          </button>
        </div>
      ) : (
        <div className="max-w-5xl mx-auto">
          <div className="bg-white border-2 border-[#333] shadow-[4px_4px_0_#ccc] p-6 mb-4">
            <div className="text-[#003060] font-bold uppercase tracking-wider mb-4 border-b-2 border-gray-300 pb-2 text-sm">
              Card Account Overview — ARQE
            </div>

            <div className="grid grid-cols-2 gap-x-16 gap-y-1.5 text-sm mb-6">
              <div className="flex gap-2">
                <span className="text-gray-500 w-40">Card Number:</span>
                <span className="font-bold" data-testid="arqe-card-number">{card.fullMasked.replace(/-/g, '')}</span>
              </div>
              <div className="flex gap-2">
                <span className="text-gray-500 w-40">Cardholder:</span>
                <span data-testid="arqe-cardholder">{card.cardHolder}</span>
              </div>
              <div className="flex gap-2">
                <span className="text-gray-500 w-40">Status:</span>
                <span className="text-green-700 font-bold">ACTIVE</span>
              </div>
              <div className="flex gap-2">
                <span className="text-gray-500 w-40">Product Type:</span>
                <span>{card.productType}</span>
              </div>
              <div className="flex gap-2">
                <span className="text-gray-500 w-40">Expiry Date:</span>
                <span>{card.expiry}</span>
              </div>
              <div className="flex gap-2">
                <span className="text-gray-500 w-40">Credit Limit:</span>
                <span>{card.creditLimit}</span>
              </div>
            </div>

            {/* Page reference — AOV (S3) or MID (S4) */}
            <div className="border-t-2 border-dashed border-gray-300 pt-4">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-xs text-gray-500">Page:</span>
                <span className="border border-gray-400 bg-yellow-50 px-3 py-0.5 font-bold" data-testid="display-page">{aovInfo.page ?? '30'}</span>
                <span className="text-xs text-gray-400">— Scroll to view restriction table assignments</span>
              </div>

              <div className={`border-2 p-4 ${isMid ? 'bg-[#fff8f0] border-orange-400' : 'bg-[#fffbe6] border-yellow-400'}`}>
                <div className={`font-bold text-xs mb-3 uppercase tracking-wider text-[#003060]`}>
                  Page {aovInfo.page ?? '30'} — {isMid ? 'MID' : 'AOV'} Table Reference
                </div>
                <div className="grid grid-cols-3 gap-8 text-sm">
                  <div>
                    <div className="text-xs text-gray-500 mb-1">{isMid ? 'MID' : 'AOV'} Table Number</div>
                    <div className="font-bold text-2xl text-[#003060]" data-testid="aov-table-number">{aovInfo.tableNumber}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500 mb-1">Table Reference</div>
                    <div className="font-bold" data-testid="aov-table-ref">{isMid ? 'MID' : 'AOV'}-031741-{aovInfo.tableNumber}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500 mb-1">Programme</div>
                    <div className="font-bold">031741</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            {isMid ? (
              <button
                onClick={() => setLocation(`/whirl/mid/${aovInfo.tableNumber}`)}
                className="bg-[#005090] text-white border-2 border-[#003060] px-8 py-2 font-bold hover:bg-[#004080] shadow-[2px_2px_0_#003060]"
                data-testid="btn-goto-rrdq"
              >
                [RRDQ] View MID Table Details
              </button>
            ) : (
              <button
                onClick={() => setLocation(`/whirl/aov/${aovInfo.tableNumber}`)}
                className="bg-[#005090] text-white border-2 border-[#003060] px-8 py-2 font-bold hover:bg-[#004080] shadow-[2px_2px_0_#003060]"
                data-testid="btn-goto-groq"
              >
                [GROQ] View AOV Table Details
              </button>
            )}
            <button
              onClick={() => setLocation('/whirl/search')}
              className="bg-gray-200 border-2 border-[#333] px-6 py-2 font-bold hover:bg-gray-300 shadow-[2px_2px_0_#333]"
            >
              [Back]
            </button>
          </div>
        </div>
      )}
    </WhirlNav>
  );
}

// ─── WH-04: GROQ — AOV Table Details ─────────────────────────────────────────

export function WhirlAov() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const [modalOpen, setModalOpen] = useState(false);

  if (!state.auth.whirl) {
    setLocation("/whirl/login");
    return null;
  }

  // AOV tables belong to the programme, so they are keyed by the table number in the route.
  const tableNumber = params.programmeNumber ?? '30';
  const data = WHIRL_AOV[tableNumber] || [];
  const aovInfo = { tableNumber, org: '031', logo: '741' };
  const tableRef = `AOV-031741-${aovInfo.tableNumber}`;

  return (
    <WhirlNav>
      <div className="bg-[#222] text-green-400 font-mono px-4 py-2 mb-4 flex items-center gap-4 -mx-6 -mt-6">
        <span className="text-[#888] text-xs">Command:</span>
        <span className="bg-[#111] border border-[#444] px-2 py-0.5 text-green-300 text-xs">[ GROQ ]</span>
        <span className="text-gray-600 text-xs ml-auto">PF3=Exit · PF7/PF8=Scroll</span>
      </div>

      <div className="max-w-5xl mx-auto">
        {/* GROQ fields — ORG / LOGO / Table / Country prepopulated */}
        <div className="bg-[#e8e8e0] border-2 border-[#333] p-4 mb-4 shadow-[2px_2px_0_#999]">
          <div className="grid grid-cols-4 gap-4 text-sm">
            <div>
              <label className="block text-xs font-bold text-gray-600 mb-1">ORG</label>
              <input
                className="border border-gray-400 bg-white p-1 w-full outline-none font-mono"
                defaultValue={aovInfo.org}
                readOnly
                data-testid="input-groq-org"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-600 mb-1">LOGO</label>
              <input
                className="border border-gray-400 bg-white p-1 w-full outline-none font-mono"
                defaultValue={aovInfo.logo}
                readOnly
                data-testid="input-groq-logo"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-600 mb-1">AOV Table Number</label>
              <input
                className="border border-gray-400 bg-yellow-50 p-1 w-full outline-none font-mono font-bold"
                defaultValue={aovInfo.tableNumber}
                readOnly
                data-testid="input-groq-table"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-600 mb-1">Country</label>
              <input
                className="border border-gray-400 bg-white p-1 w-full outline-none font-mono"
                defaultValue="998"
                readOnly
                data-testid="input-groq-country"
              />
            </div>
          </div>
        </div>

        <div className="bg-[#e0e0e0] border border-gray-400 p-2 mb-3 flex justify-between items-center">
          <div>
            <div className="font-bold uppercase tracking-wider text-[#003060] text-sm">Group Override Table — MCC/MID Restrictions</div>
            <div className="text-gray-600 text-xs mt-0.5">
              Table Ref: <span className="font-bold text-black" data-testid="display-table-ref">{tableRef}</span>
            </div>
          </div>
          <button
            onClick={() => setLocation('/whirl/search')}
            className="border border-gray-400 bg-gray-100 hover:bg-gray-200 px-4 py-1 font-bold text-xs"
          >
            [Back to ARQE]
          </button>
        </div>

        <div className="bg-white border-2 border-gray-400 shadow-[4px_4px_0_#ccc] mb-6">
          <table className="w-full text-left border-collapse">
            <thead className="bg-[#333] text-white">
              <tr>
                <th className="p-2 border-r border-[#555] w-16 text-center">Seq</th>
                <th className="p-2 border-r border-[#555] w-20">Type</th>
                <th className="p-2 border-r border-[#555] w-36">Code</th>
                <th className="p-2 border-r border-[#555]">Description</th>
                <th className="p-2 border-r border-[#555] w-24 text-center">Status</th>
                <th className="p-2 border-r border-[#555] w-28">Effective Date</th>
                <th className="p-2 border-r border-[#555] w-28">Expiry Date</th>
                <th className="p-2 w-24 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {data.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-gray-500 italic bg-gray-50" data-testid="aov-empty">
                    No MCC/MID overrides configured for this table.
                  </td>
                </tr>
              ) : (
                data.map((row, i) => (
                  <tr key={i} className="border-b border-gray-200 hover:bg-blue-50">
                    <td className="p-2 border-r border-gray-200 text-center text-gray-500">{row.seq}</td>
                    <td className="p-2 border-r border-gray-200 font-bold">{row.type}</td>
                    <td className="p-2 border-r border-gray-200 font-bold font-mono">{row.code}</td>
                    <td className="p-2 border-r border-gray-200">{row.description}</td>
                    <td className="p-2 border-r border-gray-200 text-center">
                      <span className="bg-red-600 text-white px-2 py-0.5 font-bold text-[11px] uppercase tracking-wider">{row.status}</span>
                    </td>
                    <td className="p-2 border-r border-gray-200 text-gray-600">{row.effectiveDate}</td>
                    <td className="p-2 border-r border-gray-200 text-gray-600">{row.expiryDate}</td>
                    <td className="p-2 text-center">
                      <button
                        onClick={() => setModalOpen(true)}
                        className="text-red-600 hover:bg-red-50 border border-transparent hover:border-red-200 px-2 py-0.5 text-xs font-bold"
                      >
                        [Remove]
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="bg-gray-100 border-2 border-gray-400 p-4 shadow-[4px_4px_0_#ccc]">
          <div className="font-bold uppercase tracking-wider mb-4 border-b border-gray-300 pb-2 text-sm">Add New Restriction</div>
          <div className="flex gap-4 items-end">
            <div>
              <label className="block text-xs font-bold mb-1">Type</label>
              <select className="border border-gray-400 p-1.5 bg-white w-24 outline-none">
                <option>MCC</option>
                <option>MID</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">Code</label>
              <input className="border border-gray-400 p-1.5 w-28 outline-none focus:border-blue-500" placeholder="e.g. 5411" data-testid="input-new-mcc" />
            </div>
            <div className="flex-1">
              <label className="block text-xs font-bold mb-1 text-gray-500">Description (Auto-filled)</label>
              <input className="border border-gray-300 bg-gray-200 p-1.5 w-full text-gray-500" disabled placeholder="Description will populate automatically" />
            </div>
            <button
              onClick={() => setModalOpen(true)}
              className="bg-[#005090] text-white px-6 py-1.5 font-bold hover:bg-[#004080] border border-[#003060] shadow-[2px_2px_0_#003060]"
              data-testid="btn-add-restriction"
            >
              Add Restriction
            </button>
          </div>
        </div>
      </div>

      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        system="WHIRL"
        actionDesc="Modify AOV override rules for programme"
      />
    </WhirlNav>
  );
}

// ─── WH-05: RRDQ — MID Restriction Table Details ──────────────────────────────

export function WhirlRrdq() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const [modalOpen, setModalOpen] = useState(false);

  if (!state.auth.whirl) {
    setLocation("/whirl/login");
    return null;
  }

  const tableNumber = params.tableNumber ?? '36';
  const midData = WHIRL_MID[tableNumber] ?? [];
  const aovInfo = { tableNumber, org: '031', logo: '741', page: tableNumber, tableType: 'MID' as const };
  const tableRef = `MID-031741-${aovInfo.tableNumber}`;

  return (
    <WhirlNav>
      <div className="bg-[#222] text-green-400 font-mono px-4 py-2 mb-4 flex items-center gap-4 -mx-6 -mt-6">
        <span className="text-[#888] text-xs">Command:</span>
        <span className="bg-[#111] border border-[#444] px-2 py-0.5 text-green-300 text-xs">[ RRDQ ]</span>
        <span className="text-gray-600 text-xs ml-auto">PF3=Exit · PF7/PF8=Scroll</span>
      </div>

      <div className="space-y-4">
        {/* Header info */}
        <div className="border-2 border-[#003060] bg-white p-4">
          <div className="font-bold text-xs text-[#003060] uppercase tracking-wider mb-3">
            RRDQ — Merchant ID Restriction Table Inquiry
          </div>
          <div className="grid grid-cols-4 gap-6 text-sm">
            <div>
              <div className="text-xs text-gray-500 mb-0.5">ORG</div>
              <div className="font-bold font-mono" data-testid="rrdq-org">{aovInfo.org}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-0.5">LOGO</div>
              <div className="font-bold font-mono" data-testid="rrdq-logo">{aovInfo.logo}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-0.5">MID Table Number</div>
              <div className="font-bold font-mono text-xl text-[#003060]" data-testid="rrdq-table-number">{aovInfo.tableNumber}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-0.5">Table Reference</div>
              <div className="font-bold font-mono" data-testid="rrdq-table-ref">{tableRef}</div>
            </div>
          </div>
        </div>

        {/* MID restriction entries */}
        <div className="border-2 border-[#003060] bg-white">
          <div className="bg-[#003060] text-white px-4 py-2 flex items-center justify-between">
            <span className="font-bold text-xs uppercase tracking-wider">MID Restriction Entries</span>
            <span className="text-xs text-blue-300">{midData.length} record(s)</span>
          </div>

          {midData.length === 0 ? (
            <div className="p-8 text-center">
              <div className="text-gray-400 font-mono text-sm">NO RECORDS FOUND FOR TABLE {aovInfo.tableNumber}</div>
              <div className="text-gray-400 text-xs mt-2">MID restriction table is currently empty — no merchant IDs are blocked.</div>
            </div>
          ) : (
            <table className="w-full text-left font-mono text-sm">
              <thead className="bg-[#e0e8f0] border-b-2 border-[#003060]">
                <tr>
                  <th className="px-4 py-2 text-[#003060] text-xs">SEQ</th>
                  <th className="px-4 py-2 text-[#003060] text-xs">TYPE</th>
                  <th className="px-4 py-2 text-[#003060] text-xs">MID CODE</th>
                  <th className="px-4 py-2 text-[#003060] text-xs">DESCRIPTION</th>
                  <th className="px-4 py-2 text-[#003060] text-xs">STATUS</th>
                  <th className="px-4 py-2 text-[#003060] text-xs">EFF DATE</th>
                  <th className="px-4 py-2 text-[#003060] text-xs">EXP DATE</th>
                </tr>
              </thead>
              <tbody>
                {midData.map((row, i) => (
                  <tr key={i} className="border-b border-gray-200 hover:bg-blue-50">
                    <td className="px-4 py-2">{row.seq}</td>
                    <td className="px-4 py-2">{row.type}</td>
                    <td className="px-4 py-2 font-bold text-[#003060]" data-testid={`rrdq-mid-${i}`}>{row.code}</td>
                    <td className="px-4 py-2">{row.description}</td>
                    <td className="px-4 py-2">
                      <span className="bg-red-100 text-red-800 border border-red-300 px-2 py-0.5 text-xs">{row.status}</span>
                    </td>
                    <td className="px-4 py-2">{row.effectiveDate}</td>
                    <td className="px-4 py-2">{row.expiryDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Add new MID */}
        <div className="border-2 border-dashed border-gray-400 p-4 bg-gray-50">
          <div className="text-xs font-bold text-gray-500 mb-3 uppercase tracking-wider">Add New MID Restriction</div>
          <div className="flex gap-4 items-end">
            <div>
              <label className="block text-xs font-bold mb-1">MID Code</label>
              <input
                className="border border-gray-400 p-1.5 w-36 outline-none focus:border-blue-500 font-mono"
                placeholder="e.g. MID-792301445"
                data-testid="input-new-mid"
              />
            </div>
            <div className="flex-1">
              <label className="block text-xs font-bold mb-1 text-gray-500">Description (Auto-filled)</label>
              <input
                className="border border-gray-300 bg-gray-200 p-1.5 w-full text-gray-500"
                disabled
                placeholder="Merchant name will populate automatically"
              />
            </div>
            <button
              onClick={() => setModalOpen(true)}
              className="bg-[#005090] text-white px-6 py-1.5 font-bold hover:bg-[#004080] border border-[#003060] shadow-[2px_2px_0_#003060]"
              data-testid="btn-add-mid-restriction"
            >
              Add MID
            </button>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex gap-3">
          <button
            onClick={() => setLocation('/whirl/search')}
            className="bg-gray-200 border-2 border-[#333] px-6 py-2 font-bold hover:bg-gray-300 shadow-[2px_2px_0_#333]"
          >
            [ARQE] Back to Search
          </button>
        </div>
      </div>

      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        system="WHIRL"
        actionDesc="Add MID restriction to MID table — pending Card Operations processing"
      />
    </WhirlNav>
  );
}
