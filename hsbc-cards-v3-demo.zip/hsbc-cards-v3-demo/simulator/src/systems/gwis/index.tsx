import React, { useState } from 'react';
import { useLocation, useParams } from 'wouter';
import { useSim } from '../../context/SimContext';
import { BrowserChrome } from '../../shared/BrowserChrome';
import { SimHelper } from '../../shared/SimHelper';
import { GWIS_DOCS } from '../../data/seed';

function GwisLayout({ children, title = "GWIS Document Management" }: { children: React.ReactNode; title?: string }) {
  return (
    <BrowserChrome url="https://gwis.systems.hsbc.ae">
      <div className="min-h-[600px] bg-[#f4f6f8] font-sans text-sm">
        <div className="bg-[#1a3a5c] text-white px-6 py-3 flex items-center justify-between shadow">
          <div className="flex items-center gap-3">
            <div className="font-bold text-white text-base tracking-wide">GWIS</div>
            <div className="text-blue-300 text-xs border-l border-blue-500 pl-3">Group Workflow & Image System</div>
          </div>
          <div className="text-xs text-blue-300">HSBC Internal — Restricted Access</div>
        </div>

        <div className="bg-[#2c5282] text-white px-6 py-2 text-xs flex items-center gap-6 border-b border-blue-800">
          <span className="font-semibold">{title}</span>
        </div>

        <div className="p-6">
          {children}
        </div>
      </div>
    </BrowserChrome>
  );
}

// ─── GW-01: Login ─────────────────────────────────────────────────────────────

export function GwisLogin() {
  const [, setLocation] = useLocation();
  const { dispatch } = useSim();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch.LOGIN("gwis");
    dispatch.LOG_ACTION('gwis', 'login', null);
    setLocation("/gwis/search");
  };

  return (
    <GwisLayout title="Log On">
      <SimHelper>GWIS: Use any credentials to log in (PoC — accepts any non-empty input)</SimHelper>
      <div className="max-w-md mx-auto mt-12 bg-white border border-gray-300 shadow-sm">
        <div className="bg-[#1a3a5c] text-white px-6 py-4">
          <div className="font-bold text-sm">GWIS — Secure Sign In</div>
          <div className="text-blue-300 text-xs mt-0.5">Enter your PS ID and Password to continue</div>
        </div>

        <form onSubmit={handleLogin} className="p-6 space-y-4">
          <div className="grid grid-cols-[120px_1fr] gap-3 items-center">
            <label className="font-semibold text-gray-600 text-sm">User ID (PS ID)</label>
            <input
              className="border border-gray-300 px-3 py-1.5 outline-none focus:border-[#1a3a5c] text-sm"
              required
              placeholder="e.g. PS12345"
              data-testid="input-gwis-userid"
            />
          </div>
          <div className="grid grid-cols-[120px_1fr] gap-3 items-center">
            <label className="font-semibold text-gray-600 text-sm">Password</label>
            <input
              type="password"
              className="border border-gray-300 px-3 py-1.5 outline-none focus:border-[#1a3a5c] text-sm"
              required
              data-testid="input-gwis-password"
            />
          </div>

          <div className="flex justify-end pt-2 border-t border-gray-100">
            <button
              type="submit"
              className="bg-[#1a3a5c] text-white px-6 py-2 font-semibold text-sm hover:bg-[#142e4a] border border-[#0f2238]"
              data-testid="btn-gwis-login"
            >
              Log On
            </button>
          </div>
        </form>
      </div>
    </GwisLayout>
  );
}

// ─── GW-02: Customer / Account Search ─────────────────────────────────────────

export function GwisSearch() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const [accountNo, setAccountNo] = useState("");

  if (!state.auth.gwis) {
    setLocation("/gwis/login");
    return null;
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (accountNo.trim()) {
      setLocation(`/gwis/documents/${encodeURIComponent(accountNo.trim())}`);
    }
  };

  return (
    <GwisLayout title="Work Queue Search">
      <SimHelper>Enter account number to search GWIS queue. For S4 use: 0000110000000031741</SimHelper>

      <div className="max-w-2xl mx-auto">
        <div className="bg-white border border-gray-300 shadow-sm">
          <div className="bg-gray-100 border-b border-gray-300 px-4 py-2 font-semibold text-[#1a3a5c] text-xs uppercase tracking-wider">
            Customer Work Queue Search
          </div>
          <form onSubmit={handleSearch} className="p-6 space-y-4">
            <div className="grid grid-cols-[180px_1fr] gap-4 items-center">
              <label className="font-semibold text-gray-700 text-sm">Customer No. / Account</label>
              <input
                value={accountNo}
                onChange={e => setAccountNo(e.target.value)}
                className="border border-gray-300 px-3 py-1.5 outline-none focus:border-[#1a3a5c] text-sm font-mono"
                placeholder="e.g. 0000110000000031741"
                required
                data-testid="input-gwis-account"
              />
            </div>

            <div className="flex gap-3 justify-end pt-2 border-t border-gray-100">
              <button
                type="submit"
                className="bg-[#1a3a5c] text-white px-6 py-1.5 font-semibold text-sm hover:bg-[#142e4a]"
                data-testid="btn-gwis-search"
              >
                Search
              </button>
              <button
                type="button"
                onClick={() => setAccountNo("")}
                className="bg-gray-100 border border-gray-300 px-4 py-1.5 text-sm hover:bg-gray-200"
              >
                Clear
              </button>
            </div>
          </form>
        </div>
      </div>
    </GwisLayout>
  );
}

// ─── GW-03: Document / Work Item List ─────────────────────────────────────────

export function GwisDocumentList() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();

  if (!state.auth.gwis) {
    setLocation("/gwis/login");
    return null;
  }

  // One work queue per account, as GWIS really has: every card under the account shares it.
  const docs = GWIS_DOCS.filter(d => !params.accountNumber || d.accountNumber === params.accountNumber);

  return (
    <GwisLayout title="Work Queue — Scanned Documents">
      <SimHelper>Scanned documents for account {params.accountNumber}. Click "Open" to view the scanned form.</SimHelper>

      <div className="max-w-5xl mx-auto space-y-4">
        {/* Breadcrumb */}
        <div className="text-xs text-gray-500 flex items-center gap-2">
          <span
            className="text-[#1a3a5c] hover:underline cursor-pointer"
            onClick={() => setLocation('/gwis/search')}
          >
            Work Queue Search
          </span>
          <span>›</span>
          <span>Account: {params.accountNumber}</span>
        </div>

        <div className="bg-white border border-gray-300 shadow-sm">
          <div className="bg-gray-100 border-b border-gray-300 px-4 py-2 flex items-center justify-between">
            <span className="font-semibold text-[#1a3a5c] text-xs uppercase tracking-wider">Scanned Work Items</span>
            <span className="text-xs text-gray-500">{docs.length} item(s) found</span>
          </div>

          {docs.length === 0 ? (
            <div className="p-8 text-center text-gray-500 text-sm italic">
              No scanned documents found for this account in the work queue.
            </div>
          ) : (
            <table className="w-full text-left text-sm">
              <thead className="bg-[#e8eef5] border-b border-gray-300">
                <tr>
                  <th className="px-4 py-2 font-semibold text-[#1a3a5c] text-xs">GWIS Request No.</th>
                  <th className="px-4 py-2 font-semibold text-[#1a3a5c] text-xs">Document Type</th>
                  <th className="px-4 py-2 font-semibold text-[#1a3a5c] text-xs">Client</th>
                  <th className="px-4 py-2 font-semibold text-[#1a3a5c] text-xs">Submitted</th>
                  <th className="px-4 py-2 font-semibold text-[#1a3a5c] text-xs">Scanned</th>
                  <th className="px-4 py-2 font-semibold text-[#1a3a5c] text-xs">Status</th>
                  <th className="px-4 py-2 font-semibold text-[#1a3a5c] text-xs">Action</th>
                </tr>
              </thead>
              <tbody>
                {docs.map((doc, i) => (
                  <tr key={i} className="border-b border-gray-100 hover:bg-blue-50">
                    <td className="px-4 py-3 font-mono font-bold text-[#1a3a5c]" data-testid="gwis-request-number">{doc.requestNumber}</td>
                    <td className="px-4 py-3">{doc.documentType}</td>
                    <td className="px-4 py-3 text-gray-600">{doc.clientName}</td>
                    <td className="px-4 py-3 text-gray-600">{doc.submittedDate}</td>
                    <td className="px-4 py-3 text-gray-600">{doc.scannedDate}</td>
                    <td className="px-4 py-3">
                      <span className="bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 text-xs font-semibold rounded-sm">
                        {doc.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => setLocation(`/gwis/document/${doc.requestNumber}`)}
                        className="bg-[#1a3a5c] text-white px-3 py-1 text-xs hover:bg-[#142e4a] font-semibold"
                        data-testid={`btn-open-${doc.requestNumber}`}
                      >
                        Open
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </GwisLayout>
  );
}

// ─── GW-04: Document Viewer ────────────────────────────────────────────────────

export function GwisDocumentView() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();

  if (!state.auth.gwis) {
    setLocation("/gwis/login");
    return null;
  }

  const doc = GWIS_DOCS.find(d => d.requestNumber === params.requestNumber) ?? GWIS_DOCS[0];

  if (!doc) {
    return (
      <GwisLayout title="Document Viewer">
        <div className="text-center py-12 text-gray-500">Document not found.</div>
      </GwisLayout>
    );
  }

  return (
    <GwisLayout title={`Document — ${doc.requestNumber}`}>
      <SimHelper>GWIS document viewer — GWIS request number: {doc.requestNumber}</SimHelper>

      <div className="max-w-4xl mx-auto space-y-4">
        {/* Breadcrumb */}
        <div className="text-xs text-gray-500 flex items-center gap-2">
          <span className="text-[#1a3a5c] hover:underline cursor-pointer" onClick={() => setLocation('/gwis/search')}>Work Queue</span>
          <span>›</span>
          <span className="text-[#1a3a5c] hover:underline cursor-pointer" onClick={() => history.back()}>Documents</span>
          <span>›</span>
          <span>{doc.requestNumber}</span>
        </div>

        {/* Document header */}
        <div className="bg-white border border-gray-300 shadow-sm">
          <div className="bg-[#1a3a5c] text-white px-4 py-3 flex items-center justify-between">
            <div>
              <div className="font-bold text-sm">{doc.requestNumber}</div>
              <div className="text-blue-300 text-xs mt-0.5">{doc.documentType}</div>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-amber-400 text-amber-900 px-3 py-1 text-xs font-bold rounded-sm">{doc.status}</span>
            </div>
          </div>

          <div className="p-6 grid grid-cols-2 gap-x-12 gap-y-3 text-sm">
            <div className="flex gap-2">
              <span className="text-gray-500 w-36">GWIS Request No.:</span>
              <span className="font-bold font-mono" data-testid="gwis-doc-request-number">{doc.requestNumber}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-gray-500 w-36">Document Type:</span>
              <span className="font-semibold">{doc.documentType}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-gray-500 w-36">Client:</span>
              <span>{doc.clientName}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-gray-500 w-36">Account Number:</span>
              <span className="font-mono">{doc.accountNumber}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-gray-500 w-36">Submitted:</span>
              <span>{doc.submittedDate}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-gray-500 w-36">Scanned:</span>
              <span>{doc.scannedDate}</span>
            </div>
          </div>

          <div className="px-6 pb-6">
            <div className="bg-gray-50 border border-gray-200 p-4 rounded-sm text-sm text-gray-700">
              <div className="font-semibold text-[#1a3a5c] mb-2 text-xs uppercase tracking-wider">Document Description</div>
              <p>{doc.description}</p>
            </div>
          </div>
        </div>

        {/* Scanned image placeholder */}
        <div className="bg-white border border-gray-300 shadow-sm">
          <div className="bg-gray-100 border-b border-gray-300 px-4 py-2 font-semibold text-[#1a3a5c] text-xs uppercase tracking-wider">
            Scanned Document Preview
          </div>
          <div className="p-6 flex flex-col items-center justify-center min-h-[280px] bg-gray-50">
            <div className="border-2 border-dashed border-gray-300 w-full max-w-md min-h-[200px] flex flex-col items-center justify-center text-gray-400 bg-white">
              <div className="text-4xl mb-3">📄</div>
              <div className="font-semibold text-sm text-gray-500">Company Letterhead</div>
              <div className="text-xs mt-1 text-gray-400">MID Restriction Addition Request</div>
              <div className="text-xs mt-2 text-gray-400 font-mono">{doc.requestNumber}.pdf</div>
              <div className="mt-4 text-xs text-green-600 font-semibold border border-green-300 bg-green-50 px-3 py-1 rounded-sm">
                ✓ Wet-ink signature verified
              </div>
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => history.back()}
            className="bg-gray-100 border border-gray-300 px-4 py-1.5 text-sm hover:bg-gray-200 font-semibold"
          >
            ← Back
          </button>
        </div>
      </div>
    </GwisLayout>
  );
}
