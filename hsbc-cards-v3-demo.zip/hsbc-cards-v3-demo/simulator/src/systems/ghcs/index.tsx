import React, { useState } from 'react';
import { useLocation, useParams } from 'wouter';
import { useSim } from '../../context/SimContext';
import { BrowserChrome } from '../../shared/BrowserChrome';
import { SimHelper } from '../../shared/SimHelper';
import { ApprovalGateModal } from '../../shared/ApprovalGateModal';
import { GHCS_TICKETS } from '../../data/seed';

// ─── Nav ──────────────────────────────────────────────────────────────────────

function GhcsNav({ children, breadcrumbs }: { children: React.ReactNode; breadcrumbs?: string[] }) {
  const [, setLocation] = useLocation();

  return (
    <BrowserChrome url="https://ghcs.solutions.hsbc.com">
      <div className="bg-white border-b border-gray-200">
        <div className="px-6 py-3 flex justify-between items-center bg-[#003366]">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 bg-white flex items-center justify-center rounded-sm">
              <span className="text-[#003366] font-black text-xs">H</span>
            </div>
            <div className="text-white font-semibold text-lg tracking-tight">GHCS <span className="font-light">Solutions Center</span></div>
            <div className="text-blue-300 text-xs ml-2 border border-blue-400 px-2 py-0.5 rounded">IT Support Portal</div>
          </div>
          <div className="flex items-center gap-4 text-sm text-blue-200">
            <span className="cursor-pointer hover:text-white">My Tickets</span>
            <span className="cursor-pointer hover:text-white">Knowledge Base</span>
            <span className="cursor-pointer hover:text-white">Support</span>
          </div>
        </div>
        {breadcrumbs && breadcrumbs.length > 0 && (
          <div className="px-6 py-2 bg-gray-50 border-b border-gray-200 flex items-center gap-2 text-sm text-gray-500">
            <span className="cursor-pointer hover:text-blue-600" onClick={() => setLocation('/ghcs/portal')}>Home</span>
            {breadcrumbs.map((b, i) => (
              <React.Fragment key={i}>
                <span className="text-gray-300">›</span>
                <span className={i === breadcrumbs.length - 1 ? 'text-gray-800 font-medium' : 'cursor-pointer hover:text-blue-600'}>{b}</span>
              </React.Fragment>
            ))}
          </div>
        )}
      </div>
      <div className="bg-gray-50 min-h-[600px] p-8">
        {children}
      </div>
    </BrowserChrome>
  );
}

// ─── Portal Landing ───────────────────────────────────────────────────────────

export function GhcsPortal() {
  const [, setLocation] = useLocation();

  const categories = [
    { id: 'cards-support', title: 'Cards Support', desc: 'Card investigations, blocks, disputes, and transaction queries', icon: '💳', color: 'blue' },
    { id: 'network', title: 'Network & Connectivity', desc: 'System outages, connectivity issues, and VPN support', icon: '🌐', color: 'green' },
    { id: 'access', title: 'Access & Identity', desc: 'Password resets, account access, and permissions', icon: '🔑', color: 'purple' },
    { id: 'hardware', title: 'Hardware & Devices', desc: 'Device requests, hardware faults, and equipment', icon: '🖥️', color: 'orange' },
    { id: 'software', title: 'Software & Applications', desc: 'Application issues, installations, and software requests', icon: '⚙️', color: 'teal' },
    { id: 'general', title: 'General Enquiries', desc: 'Other IT support requests and general queries', icon: '📋', color: 'gray' },
  ];

  return (
    <GhcsNav>
      <SimHelper>GHCS Solutions Center — S9 flow: Cards Support → Cards Investigation → New Ticket</SimHelper>

      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-semibold text-gray-800 mb-2">How can we help you?</h1>
          <p className="text-gray-500 text-sm">Select a support category below to raise a ticket or search for a solution.</p>
          <div className="mt-4 relative">
            <input
              type="text"
              placeholder="Search for help, e.g. 'card investigation', 'password reset'..."
              className="w-full border border-gray-300 rounded-lg px-4 py-3 pl-10 text-sm outline-none focus:ring-2 focus:ring-blue-500 bg-white shadow-sm"
            />
            <span className="absolute left-3 top-3 text-gray-400 text-sm">🔍</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => cat.id === 'cards-support' ? setLocation('/ghcs/cards-support') : undefined}
              className={`text-left p-5 bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md hover:border-blue-300 transition-all group ${cat.id !== 'cards-support' ? 'opacity-60 cursor-default' : 'cursor-pointer'}`}
              data-testid={`ghcs-category-${cat.id}`}
            >
              <div className="text-3xl mb-3">{cat.icon}</div>
              <div className="font-semibold text-gray-800 group-hover:text-blue-800 mb-1">{cat.title}</div>
              <div className="text-xs text-gray-500 leading-relaxed">{cat.desc}</div>
            </button>
          ))}
        </div>

        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center gap-4">
          <div className="text-2xl">📞</div>
          <div>
            <div className="font-semibold text-blue-800 text-sm">Need urgent help?</div>
            <div className="text-xs text-blue-600 mt-0.5">Call the GHCS Help Desk: <span className="font-mono font-bold">+44 (0)20 7991 8888</span> | Available 24/7</div>
          </div>
        </div>
      </div>
    </GhcsNav>
  );
}

// ─── Cards Support ────────────────────────────────────────────────────────────

export function GhcsCardsSupport() {
  const [, setLocation] = useLocation();

  const subCategories = [
    { id: 'cards-investigation', title: 'Cards Investigation', desc: 'Declined transactions, missing auths, and card anomaly investigations', badge: 'S9', active: true },
    { id: 'card-blocking', title: 'Card Blocking / Unblocking', desc: 'Emergency card blocks, fraud blocks, and card status changes', active: false },
    { id: 'limit-amendment', title: 'Limit Amendment', desc: 'Spend limit, AOV, and credit limit change requests', active: false },
    { id: 'new-card', title: 'New Card Issuance', desc: 'New card requests, replacements, and PIN issues', active: false },
    { id: 'statement', title: 'Statement & Reporting', desc: 'Statement queries, transaction disputes, and reporting issues', active: false },
    { id: 'virtual-cards', title: 'Virtual Card Support', desc: 'Virtual card creation, controls, and purchase request issues', active: false },
  ];

  return (
    <GhcsNav breadcrumbs={['Cards Support']}>
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-xl font-semibold text-gray-800 mb-1">Cards Support</h1>
          <p className="text-sm text-gray-500">Select the type of cards support you require.</p>
        </div>

        <div className="space-y-3">
          {subCategories.map(sub => (
            <button
              key={sub.id}
              onClick={() => sub.id === 'cards-investigation' ? setLocation('/ghcs/new-ticket') : undefined}
              className={`w-full text-left p-4 bg-white border rounded-lg flex items-center justify-between transition-all group ${
                sub.active
                  ? 'border-blue-300 hover:border-blue-500 hover:shadow-md cursor-pointer'
                  : 'border-gray-200 opacity-60 cursor-default'
              }`}
              data-testid={`ghcs-sub-${sub.id}`}
            >
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className={`font-semibold text-sm ${sub.active ? 'text-gray-800 group-hover:text-blue-800' : 'text-gray-600'}`}>{sub.title}</span>
                  {sub.badge && <span className="text-xs bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded font-semibold">Active for {sub.badge}</span>}
                </div>
                <div className="text-xs text-gray-500 mt-0.5">{sub.desc}</div>
              </div>
              {sub.active && <span className="text-blue-400 group-hover:text-blue-600 text-lg">›</span>}
            </button>
          ))}
        </div>
      </div>
    </GhcsNav>
  );
}

// ─── New Ticket ───────────────────────────────────────────────────────────────

export function GhcsNewTicket() {
  const { state, dispatch } = useSim();
  const [, setLocation] = useLocation();
  const [modalOpen, setModalOpen] = useState(false);
  // The form prefills from ?card=<last four> so a presenter raising a ticket for their own
  // card gets their own details; with no card named it falls back to the first ticket.
  const cardParam = new URLSearchParams(window.location.search).get('card') ?? '';
  const tickets = Object.values(GHCS_TICKETS);
  const ticket = tickets.find(t => t.cardLastFour === cardParam) ?? tickets[0];

  const [subject, setSubject] = useState(ticket?.subject ?? '');
  const [cardNumber, setCardNumber] = useState(ticket?.cardNumber ?? '');
  const [location_, setLocation_] = useState(ticket?.impactedLocation ?? 'United Arab Emirates');
  const [lob, setLob] = useState(ticket?.lineOfBusiness ?? 'Commercial Banking (CMB)');
  const [coreApp, setCoreApp] = useState(ticket?.coreApplication ?? '');
  const [details, setDetails] = useState(ticket?.issueDetails ?? '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setModalOpen(true);
  };

  return (
    <GhcsNav breadcrumbs={['Cards Support', 'Cards Investigation', 'New Ticket']}>
      <SimHelper>GHCS Ticket — Incident Subject, Card Number, Location, LoB, Core Application, Issue Details → Save</SimHelper>

      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="text-xl font-semibold text-gray-800 mb-1">Cards Investigation — New Incident</h1>
          <p className="text-sm text-gray-500">Complete all required fields and click Save to raise the incident ticket.</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white border border-gray-200 rounded-lg shadow-sm divide-y divide-gray-100">
          <div className="p-6 space-y-5">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Incident Subject <span className="text-red-500">*</span></label>
              <input
                value={subject}
                onChange={e => setSubject(e.target.value)}
                className="w-full border border-gray-300 rounded px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                required
                data-testid="input-ghcs-subject"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Card Number <span className="text-red-500">*</span></label>
              <input
                value={cardNumber}
                onChange={e => setCardNumber(e.target.value)}
                placeholder="e.g. 5550-4100-9901-6614"
                className="w-full border border-gray-300 rounded px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                required
                data-testid="input-ghcs-card-number"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1">Impacted System Location <span className="text-red-500">*</span></label>
                <select
                  value={location_}
                  onChange={e => setLocation_(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  data-testid="select-ghcs-location"
                >
                  <option>United Arab Emirates</option>
                  <option>United Kingdom</option>
                  <option>Hong Kong</option>
                  <option>Singapore</option>
                  <option>India</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1">Impacted Line of Business <span className="text-red-500">*</span></label>
                <select
                  value={lob}
                  onChange={e => setLob(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  data-testid="select-ghcs-lob"
                >
                  <option>Commercial Banking (CMB)</option>
                  <option>Global Banking & Markets (GBM)</option>
                  <option>Wealth & Personal Banking (WPB)</option>
                  <option>Corporate Centre</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Core Application <span className="text-red-500">*</span></label>
              <select
                value={coreApp}
                onChange={e => setCoreApp(e.target.value)}
                className="w-full border border-gray-300 rounded px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                data-testid="select-ghcs-core-app"
              >
                <option value="">— Select Core Application —</option>
                <option>Statement/Transaction enquiries</option>
                <option>Card Authorisation (eChamps)</option>
                <option>Card Issuance & Management</option>
                <option>MiVision Card Portal</option>
                <option>Smart Data InControl (SDG2)</option>
                <option>WHIRL HUB Core Cards</option>
                <option>General Banking Systems</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Issue / Clarification Details <span className="text-red-500">*</span></label>
              <textarea
                value={details}
                onChange={e => setDetails(e.target.value)}
                rows={6}
                className="w-full border border-gray-300 rounded px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                required
                data-testid="input-ghcs-details"
              />
              <div className="text-xs text-gray-400 mt-1">Please include the card number, date/time of incident, transaction amount, and any relevant context.</div>
            </div>
          </div>

          <div className="px-6 py-4 bg-gray-50 flex justify-between items-center">
            <button type="button" onClick={() => setLocation('/ghcs/cards-support')} className="border border-gray-300 text-gray-700 px-4 py-2 rounded text-sm font-medium hover:bg-gray-100">
              Cancel
            </button>
            <button type="submit" className="bg-[#003366] text-white px-8 py-2 rounded text-sm font-semibold hover:bg-[#002244] shadow-sm" data-testid="btn-ghcs-save">
              Save
            </button>
          </div>
        </form>
      </div>

      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={(v) => {
          setModalOpen(v);
          if (!v) {
            const ticketId = ticket?.ticketId ?? 'INC0084521';
            dispatch.LOG_ACTION('ghcs', 'ticket_raised', `Ticket ${ticketId}: ${subject}`);
            setLocation(`/ghcs/ticket/${ticketId}`);
          }
        }}
        system="GHCS Solutions Center"
        actionDesc={`Raise Cards Investigation incident ticket: "${subject}" — Card: ${cardNumber} — ${location_} — ${coreApp}`}
      />
    </GhcsNav>
  );
}

// ─── Ticket Confirmation ──────────────────────────────────────────────────────

export function GhcsTicketConfirmation() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams<{ ticketId: string }>();
  const ticketId = params.ticketId ?? Object.values(GHCS_TICKETS)[0]?.ticketId ?? 'INC0084521';
  const ticket = GHCS_TICKETS[ticketId];

  return (
    <GhcsNav breadcrumbs={['Cards Support', 'Cards Investigation', ticketId]}>
      <div className="max-w-3xl mx-auto">
        <div className="bg-white border border-green-200 rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600 text-xl">✓</div>
            <div>
              <h2 className="text-lg font-semibold text-green-800">Incident Raised Successfully</h2>
              <p className="text-sm text-green-600">Your ticket has been submitted and assigned to the Cards Investigation team.</p>
            </div>
          </div>

          <div className="bg-green-50 border border-green-200 rounded p-4 flex items-center justify-between">
            <div>
              <div className="text-xs text-green-600 font-semibold uppercase tracking-wider">Ticket Reference</div>
              <div className="text-2xl font-mono font-bold text-green-800 mt-1" data-testid="ghcs-ticket-id">{ticketId}</div>
            </div>
            <div className="text-xs text-green-600">
              <div>Priority: <span className="font-semibold">High</span></div>
              <div className="mt-1">SLA: <span className="font-semibold">4 business hours</span></div>
            </div>
          </div>
        </div>

        {ticket && (
          <div className="bg-white border border-gray-200 rounded-lg shadow-sm divide-y divide-gray-100">
            <div className="p-5">
              <h3 className="text-sm font-bold text-gray-600 uppercase tracking-wider mb-4">Ticket Details</h3>
              <div className="space-y-3">
                <Detail label="Subject" value={ticket.subject} testId="ghcs-detail-subject" />
                <Detail label="Card Number" value={ticket.cardNumber} mono testId="ghcs-detail-card" />
                <Detail label="Impacted Location" value={ticket.impactedLocation} testId="ghcs-detail-location" />
                <Detail label="Line of Business" value={ticket.lineOfBusiness} testId="ghcs-detail-lob" />
                <Detail label="Core Application" value={ticket.coreApplication} testId="ghcs-detail-app" />
                <Detail label="Created" value={ticket.createdDate} testId="ghcs-detail-created" />
                <Detail label="Status" value={ticket.status} testId="ghcs-detail-status" badge badgeColor="amber" />
              </div>
            </div>

            <div className="p-5">
              <h3 className="text-sm font-bold text-gray-600 uppercase tracking-wider mb-3">Issue Details</h3>
              <p className="text-sm text-gray-700 leading-relaxed" data-testid="ghcs-detail-issue">{ticket.issueDetails}</p>
            </div>

            <div className="p-5">
              <h3 className="text-sm font-bold text-gray-600 uppercase tracking-wider mb-3">Resolution / Next Steps</h3>
              <p className="text-sm text-gray-700 leading-relaxed" data-testid="ghcs-detail-resolution">{ticket.resolution}</p>
              <div className="mt-4 bg-amber-50 border border-amber-200 rounded p-3 text-xs text-amber-800">
                If no resolution is provided by the IT team after investigation, escalate to Mastercard Connect by raising a Support Case.
              </div>
            </div>
          </div>
        )}

        <div className="mt-4 flex gap-3">
          <button onClick={() => setLocation('/ghcs/portal')} className="border border-gray-300 text-gray-700 px-4 py-2 rounded text-sm font-medium hover:bg-gray-50">
            Back to Portal
          </button>
        </div>
      </div>
    </GhcsNav>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function Detail({ label, value, testId, mono, badge, badgeColor }: {
  label: string; value: string; testId?: string; mono?: boolean; badge?: boolean; badgeColor?: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <span className="text-xs text-gray-500 w-36 shrink-0 pt-0.5">{label}</span>
      {badge ? (
        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${badgeColor === 'amber' ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800'}`} data-testid={testId}>{value}</span>
      ) : (
        <span className={`text-sm text-gray-800 font-medium ${mono ? 'font-mono' : ''}`} data-testid={testId}>{value}</span>
      )}
    </div>
  );
}
