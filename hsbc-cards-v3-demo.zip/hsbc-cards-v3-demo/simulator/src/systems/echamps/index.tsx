import React, { useState } from 'react';
import { useLocation, Link, useParams } from 'wouter';
import { useSim } from '../../context/SimContext';
import { BrowserChrome } from '../../shared/BrowserChrome';
import { ApprovalGateModal } from '../../shared/ApprovalGateModal';
import { MIVISION_CLIENTS, ECHAMPS_AUTHS } from '../../data/seed';

const CLIENT = MIVISION_CLIENTS[0];

const ECHAMPS_ACCOUNT_NUMBER = "0000110000000031741";

function EChampsLayout({ children, hideNav = false, hideYellowBar = false, cardLastFour, pageTitle = "Account Overview", activeNavItem = "A/C Overview" }: { children: React.ReactNode, hideNav?: boolean, hideYellowBar?: boolean, cardLastFour?: string, pageTitle?: string, activeNavItem?: string }) {
  const systemDate = "24/06/2026";

  const navSection = (label: string, items: Array<{ label: string; href?: string; testId?: string }>, expanded = true) => (
    <div className="mb-1">
      <div className="px-3 py-1 flex items-center gap-1 cursor-pointer hover:bg-white/10 text-[#a8b8d8]">
        <span className="text-[10px]">{expanded ? '▾' : '▸'}</span> <span>{label}</span>
      </div>
      {expanded && items.map((item) => {
        const isActive = item.label === activeNavItem;
        const content = (
          <div
            className={`px-7 py-0.5 cursor-pointer hover:bg-blue-800/60 ${isActive ? 'text-[#ff4d4d] font-bold' : 'text-cyan-200'}`}
          >
            {isActive ? '• ' : ''}{item.label}
          </div>
        );
        return item.href ? (
          <Link key={item.label} href={item.href} data-testid={item.testId}>{content}</Link>
        ) : (
          <div key={item.label}>{content}</div>
        );
      })}
    </div>
  );

  return (
    <BrowserChrome url="https://wk-evg-echampshbmebank.systems.uk.hsbc/hbannual/eCAFE">
      <div className="flex flex-col min-h-[600px] bg-white font-sans text-sm">
        {/* Header */}
        <div className="bg-white flex justify-between items-start px-4 py-2 border-b-2 border-[#DB0011]">
          <div className="flex items-start gap-3">
            <div className="font-bold text-2xl text-[#DB0011] tracking-tighter leading-none">
              HSBC <span className="inline-block w-3 h-3 bg-[#DB0011] align-middle ml-0.5" style={{clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)'}}></span>
            </div>
            <div className="leading-tight text-[11px] pt-1">
              <div className="font-bold">HSBC/HBME</div>
              <div className="font-bold">{pageTitle}</div>
            </div>
          </div>
          <div className="text-right text-[11px]">
            <div className="flex gap-3 justify-end items-center mb-1">
              <span className="flex items-center gap-1 cursor-pointer"><span className="text-[#DB0011]">⌂</span> Home</span>
              <span className="flex items-center gap-1 cursor-pointer"><span className="text-[#DB0011]">🖶</span> Print</span>
              <span className="flex items-center gap-1 cursor-pointer"><span className="text-[#DB0011]">?</span> Help</span>
              <span className="flex items-center gap-1 cursor-pointer"><span className="text-[#DB0011]">✕</span> Logoff</span>
            </div>
            <div className="text-gray-600">R99807 | System Date: {systemDate} | EP39 Normal Mode</div>
          </div>
        </div>

        {/* Purple account bar */}
        {!hideYellowBar && (
          <div className="bg-[#c8c8f0] border-b border-gray-400 px-3 py-1.5 flex gap-6 items-center text-[13px]">
            <div className="flex items-center gap-2">
              <span className="font-bold">Account Number</span>
              <select className="border border-gray-400 bg-white py-0.5 font-mono text-xs" defaultValue={ECHAMPS_ACCOUNT_NUMBER}>
                <option value={ECHAMPS_ACCOUNT_NUMBER}>{ECHAMPS_ACCOUNT_NUMBER}</option>
              </select>
              <button className="bg-gray-200 border border-gray-400 px-3 py-0.5 hover:bg-gray-300 text-xs font-bold">Submit</button>
            </div>
            <div className="font-bold">Customer Name <span className="font-normal ml-1">{CLIENT.clientName}</span></div>
            <div className="font-bold ml-auto">Current Balance <span className="font-normal ml-1">AED {(0).toFixed(2)}</span></div>
          </div>
        )}

        <div className="flex flex-1">
          {/* Sidebar */}
          {!hideNav && (
            <div className="w-[190px] bg-[#0c1a3a] text-white shrink-0 py-3 font-sans text-[12.5px]">
              {navSection('Locate A/C', [
                { label: 'Cust A/C Search' },
                { label: 'Demographic Search' },
                { label: 'Company Search' },
              ], false)}
              {navSection('A/C Info', [
                { label: 'A/C Overview' },
                { label: 'Balance Detail', href: '/echamps/balance-detail', testId: 'link-balance-detail' },
                { label: 'A/C Detail' },
                { label: 'Credit Plan Detail' },
              ])}
              {navSection('Commercial', [
                { label: 'A/C List', href: `/echamps/accounts/${ECHAMPS_ACCOUNT_NUMBER}` },
              ])}
              {navSection('Cards', cardLastFour ? [
                { label: 'Card Info', href: `/echamps/card/${cardLastFour}/info`, testId: 'sidebar-card-info' },
              ] : [], !!cardLastFour)}
              {navSection('A/C Maint', [], false)}
              {navSection('Loyalty', [], false)}
              {navSection('Memos', [], false)}
              {navSection('Risk', cardLastFour ? [
                { label: 'View Card Auths', href: `/echamps/card/${cardLastFour}/auths`, testId: 'sidebar-view-card-auths' },
              ] : [], !!cardLastFour)}
              {navSection('Monetaries', [], false)}
              {navSection('Statements', [], false)}

              <div className="border-t border-white/20 mt-3 pt-2 text-[#a8b8d8]">
                <div className="px-3 py-0.5 cursor-pointer hover:bg-white/10">Text Size</div>
                <div className="px-3 py-0.5 cursor-pointer hover:bg-white/10">Show UI Hints</div>
                <div className="px-3 py-0.5 cursor-pointer hover:bg-white/10">Hide Nav</div>
                <div className="px-3 py-0.5 cursor-pointer hover:bg-white/10">Maintain Application Preferences</div>
                <div className="px-3 py-0.5 cursor-pointer hover:bg-white/10">Telephony Options</div>
              </div>
            </div>
          )}

          {/* Content */}
          <div className="flex-1 p-4 relative">
            {children}
          </div>
        </div>
      </div>
    </BrowserChrome>
  );
}

export function EChampsLogin() {
  const [, setLocation] = useLocation();
  const { dispatch } = useSim();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch.LOGIN('echamps');
    dispatch.LOG_ACTION('echamps', 'login', null);
    setLocation("/echamps/search");
  };

  return (
    <EChampsLayout hideNav hideYellowBar>
      <div className="max-w-xl mx-auto mt-12 border-2 border-red-600 p-6 bg-gray-50">
        <div className="text-red-600 font-bold text-center mb-6">
          UNAUTHORISED ACCESS IS STRICTLY FORBIDDEN AND IS A DISCIPLINARY OFFENCE.<br/>
          YOU MAY NOW ATTEMPT TO LOG ON:
        </div>
        <form onSubmit={handleLogin} className="w-64 mx-auto space-y-4">
          <div className="flex justify-between items-center">
            <label className="font-bold">User Id</label>
            <input className="border border-gray-400 w-32 px-1 outline-none uppercase bg-white" required />
          </div>
          <div className="flex justify-between items-center">
            <label className="font-bold">Password</label>
            <input type="password" className="border border-gray-400 w-32 px-1 outline-none bg-white" required />
          </div>
          <div className="flex gap-2 justify-center pt-4">
            <button type="submit" className="bg-gray-200 border border-gray-400 px-4 py-1 hover:bg-gray-300 font-bold">Log On</button>
            <button type="button" className="bg-gray-200 border border-gray-400 px-4 py-1 hover:bg-gray-300">Change Password</button>
          </div>
        </form>
      </div>
    </EChampsLayout>
  );
}

export function EChampsSearch() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const [acct, setAcct] = useState("");

  if (!state.auth.echamps) {
    setLocation("/echamps/login");
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (acct) setLocation(`/echamps/overview/${acct}`);
  };

  return (
    <EChampsLayout hideYellowBar>
      <div className="flex gap-1 border-b border-gray-300 mb-6">
        <div className="bg-gray-200 px-4 py-1.5 border border-gray-400 border-b-0 font-bold -mb-[1px]">Cust A/C Search</div>
        <div className="bg-gray-100 px-4 py-1.5 border border-gray-300 border-b-0 text-gray-500">Demographic Search</div>
        <div className="bg-gray-100 px-4 py-1.5 border border-gray-300 border-b-0 text-gray-500">Company Search</div>
      </div>

      <div className="mb-6 border border-blue-200 bg-blue-50 p-2">
        <div className="font-bold text-blue-800">► Errors/Messages</div>
        <div className="text-blue-900 ml-4 text-xs">• Telephony options updated successfully.</div>
      </div>

      <form onSubmit={handleSubmit} className="max-w-md bg-gray-50 border border-gray-300 p-6">
        <div className="grid grid-cols-[150px_1fr] gap-4 items-center mb-4">
          <label className="font-bold text-right text-gray-700">Account/Card Number</label>
          <input 
            value={acct} 
            onChange={e => setAcct(e.target.value)} 
            className="border border-gray-400 px-2 py-1 outline-none w-full uppercase" 
            data-testid="input-acct-search"
          />
          
          <label className="font-bold text-right text-gray-700">Search Type</label>
          <select className="border border-gray-400 px-2 py-1 outline-none w-full bg-white">
            <option>Card</option>
            <option>Account</option>
            <option value="Relationship">Relationship</option>
          </select>
        </div>
        <div className="flex justify-end pt-4 border-t border-gray-200">
          <button type="submit" className="bg-[#0070C0] text-white px-6 py-1.5 font-bold hover:bg-[#005090]" data-testid="btn-search">Submit</button>
        </div>
      </form>
    </EChampsLayout>
  );
}

const ECHAMPS_MEMOS = [
  { date: "12/05/2026", time: "09:11:01", priority: "0", reviewRep: "0", reviewAsmOrg: "", rep: "OGH", type: "N", action: "", desc: "CREDIT LIMIT FROM : 00000007500000000 TO : 00000007437637500", ref: "A41593", amount: "0.00", plan: "00000", seq: "00", store: "000000000", status: "C", referralRep: "000" },
  { date: "30/12/2025", time: "13:48:17", priority: "0", reviewRep: "0", reviewAsmOrg: "", rep: "OGH", type: "N", action: "", desc: "CREDIT LIMIT FROM : 00000007456000000 TO : 00000007500000000", ref: "S05901", amount: "0.00", plan: "00000", seq: "00", store: "000000000", status: "C", referralRep: "000" },
  { date: "24/10/2024", time: "06:12:23", priority: "0", reviewRep: "0", reviewAsmOrg: "", rep: "OGH", type: "N", action: "", desc: "CREDIT LIMIT FROM : 00000007471000000 TO : 00000007456000000", ref: "S05901", amount: "0.00", plan: "00000", seq: "00", store: "000000000", status: "C", referralRep: "000" },
  { date: "15/09/2024", time: "06:43:43", priority: "0", reviewRep: "0", reviewAsmOrg: "", rep: "OGH", type: "N", action: "", desc: "CREDIT LIMIT FROM : 00000007481000000 TO : 00000007471000000", ref: "J57760", amount: "0.00", plan: "00000", seq: "00", store: "000000000", status: "C", referralRep: "000" },
  { date: "14/05/2024", time: "01:34:16", priority: "0", reviewRep: "0", reviewAsmOrg: "", rep: "OGH", type: "N", action: "", desc: "CREDIT LIMIT FROM : 00000001481000000 TO : 00000007481000000", ref: "K81896", amount: "0.00", plan: "00000", seq: "00", store: "000000000", status: "C", referralRep: "000" },
];

export function EChampsOverview() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const [expandedMemo, setExpandedMemo] = useState<number | null>(null);
  const contact = CLIENT.internalContacts?.[0];

  if (!state.auth.echamps) {
    setLocation("/echamps/login");
    return null;
  }

  return (
    <EChampsLayout>
      <div className="border border-gray-400 bg-white px-4 py-3 mb-4 text-[13px]">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="w-40">Requester:</span>
          <select className="border border-gray-400 bg-white px-1 py-0.5 text-xs" defaultValue="Primary">
            <option>Primary</option>
          </select>
        </div>
        <div className="flex items-center gap-2 mb-1.5">
          <span className="w-40 shrink-0">Special Info One:</span>
          <span data-testid="text-special-info-one">AUTH.{contact ? contact.name.toUpperCase().replace(' ', ' ') : 'JEEVITHAA SOMASUNDARAM'} PP:N9311399 PH:{contact ? contact.phone.replace(/\D/g, '').slice(-9) : '553037641'}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-40 shrink-0">Special Info Two:</span>
          <span data-testid="text-special-info-two">DOB:3/10/85</span>
        </div>
      </div>

      <div className="space-y-1 mb-6 text-[#0000FF] font-bold text-[13px]">
        <div className="cursor-pointer hover:underline">▸ Account Information</div>
        <div className="cursor-pointer hover:underline">▸ Branched Customer</div>
        <div className="cursor-pointer hover:underline">▸ Marketing Codes</div>
        <div className="cursor-pointer hover:underline">▸ Stamp Tax Info</div>
      </div>

      <div className="mt-4">
        <div className="font-bold text-[14px] mb-2 border-b-2 border-gray-800 pb-0.5 inline-block pr-8">Memo History</div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[11px] border-collapse" data-testid="table-memo-history">
            <thead className="bg-[#e8e8f8] border-y border-gray-400">
              <tr>
                <th className="p-1 w-4"></th>
                <th className="p-1 border-r border-gray-300">Date</th>
                <th className="p-1 border-r border-gray-300">Time</th>
                <th className="p-1 border-r border-gray-300">Priority</th>
                <th className="p-1 border-r border-gray-300">Review Rep</th>
                <th className="p-1 border-r border-gray-300">Review ASM Org</th>
                <th className="p-1 border-r border-gray-300">Rep</th>
                <th className="p-1 border-r border-gray-300">Type</th>
                <th className="p-1 border-r border-gray-300">Action</th>
                <th className="p-1 border-r border-gray-300">Action Description</th>
                <th className="p-1 border-r border-gray-300 text-right">Amount</th>
                <th className="p-1 border-r border-gray-300">Plan Number</th>
                <th className="p-1 border-r border-gray-300">Sequence No</th>
                <th className="p-1 border-r border-gray-300">Store Number</th>
                <th className="p-1 border-r border-gray-300">Status</th>
                <th className="p-1">Referral Rep</th>
              </tr>
            </thead>
            <tbody>
              {ECHAMPS_MEMOS.map((m, i) => (
                <React.Fragment key={i}>
                  <tr
                    className={`cursor-pointer hover:bg-yellow-50 border-b border-gray-200 ${i % 2 === 0 ? 'bg-white' : 'bg-[#f4f4fb]'}`}
                    onClick={() => setExpandedMemo(expandedMemo === i ? null : i)}
                    data-testid={`row-memo-${i}`}
                  >
                    <td className="p-1 text-[#0000FF] text-center">{expandedMemo === i ? '▾' : '▸'}</td>
                    <td className="p-1 border-r border-gray-200">{m.date}</td>
                    <td className="p-1 border-r border-gray-200">{m.time}</td>
                    <td className="p-1 border-r border-gray-200">{m.priority}</td>
                    <td className="p-1 border-r border-gray-200">{m.reviewRep}</td>
                    <td className="p-1 border-r border-gray-200">{m.reviewAsmOrg}</td>
                    <td className="p-1 border-r border-gray-200">{m.rep}</td>
                    <td className="p-1 border-r border-gray-200">{m.type}</td>
                    <td className="p-1 border-r border-gray-200">{m.action}</td>
                    <td className="p-1 border-r border-gray-200 whitespace-nowrap">CREDIT LIMIT FROM : {m.desc.split(' TO : ')[0].replace('CREDIT LIMIT FROM : ', '')} TO : {m.desc.split(' TO : ')[1]}</td>
                    <td className="p-1 border-r border-gray-200 text-right">AED {m.amount}</td>
                    <td className="p-1 border-r border-gray-200">{m.plan}</td>
                    <td className="p-1 border-r border-gray-200">{m.seq}</td>
                    <td className="p-1 border-r border-gray-200">{m.store}</td>
                    <td className="p-1 border-r border-gray-200">{m.status}</td>
                    <td className="p-1">{m.referralRep}</td>
                  </tr>
                  <tr className="border-b border-gray-300">
                    <td className="p-1 pl-6 text-gray-500 text-[10px]" colSpan={16}>
                      {m.date} {m.ref} CREDIT LIMIT FROM : {m.desc.split(' TO : ')[0].replace('CREDIT LIMIT FROM : ', '')} TO : {m.desc.split(' TO : ')[1]}
                    </td>
                  </tr>
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 pt-4 border-t border-gray-300">
          <Link href={`/echamps/accounts/${ECHAMPS_ACCOUNT_NUMBER}`}>
            <button className="bg-gray-200 border border-gray-400 px-4 py-1 font-bold shadow-sm" data-testid="btn-goto-acct-list">View A/C List</button>
          </Link>
        </div>
      </div>
    </EChampsLayout>
  );
}

export function EChampsAccounts() {
  const { state } = useSim();
  const [, setLocation] = useLocation();

  if (!state.auth.echamps) {
    setLocation("/echamps/login");
    return null;
  }

  const client = MIVISION_CLIENTS[0];

  return (
    <EChampsLayout>
      <div className="bg-[#000080] text-white font-bold px-2 py-1 inline-block mb-4 text-sm tracking-widest">Commercial Account List</div>
      
      <table className="w-full text-left text-sm border-collapse border border-gray-400 font-mono">
        <thead className="bg-gray-200 border-b-2 border-gray-400 text-gray-800">
          <tr>
            <th className="p-2 border-r border-gray-300">Account Number</th>
            <th className="p-2 border-r border-gray-300">Customer Name</th>
            <th className="p-2 border-r border-gray-300 text-center">Billing Ind</th>
            <th className="p-2 border-r border-gray-300 text-right">Credit Limit</th>
            <th className="p-2 border-r border-gray-300 text-right">Balance</th>
            <th className="p-2 border-r border-gray-300 text-center">Block Code 1</th>
            <th className="p-2">Account Indicator</th>
          </tr>
        </thead>
        <tbody>
          {client.cards.map((c, i) => (
            <tr key={c.fullNumber} className={`border-b border-gray-300 hover:bg-yellow-50 ${i % 2 === 0 ? 'bg-white' : 'bg-[#e8e0ff]'}`}>
              <td className="p-2 border-r border-gray-300">
                <Link href={`/echamps/card/${c.lastFour}`} className="text-[#0000FF] hover:underline font-bold" data-testid={`link-card-${c.lastFour}`}>
                  {c.fullNumber.replace(/-/g, '')}
                </Link>
              </td>
              <td className="p-2 border-r border-gray-300 truncate max-w-[200px]">{c.cardHolder}</td>
              <td className="p-2 border-r border-gray-300 text-center">I</td>
              <td className="p-2 border-r border-gray-300 text-right">{c.creditLimit}</td>
              <td className="p-2 border-r border-gray-300 text-right">{c.outstandingBalance}</td>
              <td className="p-2 border-r border-gray-300 text-center font-bold text-red-600">
                {c.status === 'Closed' ? 'C' : c.unpostedTransaction?.declineReason?.includes('FALC') ? 'F' : ''}
              </td>
              <td className="p-2 text-gray-500 text-xs">C - COMMERCIAL</td>
            </tr>
          ))}
        </tbody>
      </table>
    </EChampsLayout>
  );
}

export function EChampsCardOverview() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();

  if (!state.auth.echamps) {
    setLocation("/echamps/login");
    return null;
  }

  const client = MIVISION_CLIENTS[0];
  const card = client.cards.find(c => c.lastFour === params.cardNumber);

  if (!card) return <EChampsLayout>Card not found</EChampsLayout>;

  return (
    <EChampsLayout cardLastFour={card.lastFour} pageTitle="Account Overview" hideYellowBar>
      <div className="bg-[#c8c8f0] border border-gray-400 px-3 py-1.5 flex gap-6 items-center text-[13px] -mt-4 -mx-4 mb-4">
        <div className="font-bold">Card Number <span className="font-normal ml-1 font-mono">{card.fullNumber.replace(/-/g, '')}</span></div>
        <div className="font-bold">Customer Name <span className="font-normal ml-1">{card.cardHolder}</span></div>
        <div className="font-bold ml-auto">Current Balance <span className="font-normal ml-1">{card.outstandingBalance}</span></div>
      </div>

      <div className="border border-gray-400 bg-white px-4 py-3 mb-4 text-[13px]">
        <div className="flex items-center gap-2 mb-1.5"><span className="w-40">Product Type:</span> <span>{card.productType}</span></div>
        <div className="flex items-center gap-2 mb-1.5"><span className="w-40">Company Account:</span> <span className="font-mono">{card.companyAccountMasked}</span></div>
        <div className="flex items-center gap-2"><span className="w-40">Card Billing Type:</span> <span>{card.cardBillingType}</span></div>
      </div>

      <div className="space-y-1 mb-6 text-[#0000FF] font-bold text-[13px]">
        <div className="cursor-pointer hover:underline">▸ Account Information</div>
        <div className="cursor-pointer hover:underline">▸ Branched Customer</div>
        <div className="cursor-pointer hover:underline">▸ Marketing Codes</div>
        <div className="cursor-pointer hover:underline">▸ Stamp Tax Info</div>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-300 flex gap-4">
        <Link href={`/echamps/card/${card.lastFour}/info`}>
          <button className="bg-gray-200 border border-gray-400 px-4 py-1 font-bold shadow-sm" data-testid="btn-goto-card-info">Card Info</button>
        </Link>
        <Link href={`/echamps/accounts/${ECHAMPS_ACCOUNT_NUMBER}`}>
          <button className="bg-gray-200 border border-gray-400 px-4 py-1 font-bold shadow-sm" data-testid="btn-back-to-acct-list">Return to A/C List</button>
        </Link>
      </div>
    </EChampsLayout>
  );
}

export function EChampsCardInfo() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const [modalOpen, setModalOpen] = useState(false);

  if (!state.auth.echamps) {
    setLocation("/echamps/login");
    return null;
  }

  const client = MIVISION_CLIENTS[0];
  const card = client.cards.find(c => c.lastFour === params.cardNumber);

  if (!card) return <EChampsLayout>Card not found</EChampsLayout>;

  return (
    <EChampsLayout cardLastFour={card.lastFour}>
      <div className="flex gap-1 border-b border-gray-300 mb-6 flex-wrap">
        <div className="bg-gray-200 px-3 py-1 border border-gray-400 border-b-0 font-bold -mb-[1px]">Card Detail</div>
        <div className="bg-gray-100 px-3 py-1 border border-gray-300 border-b-0 text-[#0000FF] cursor-pointer">Maintain Card Detail</div>
        <div className="bg-gray-100 px-3 py-1 border border-gray-300 border-b-0 text-[#0000FF] cursor-pointer">Misc Card Info</div>
        <div className="bg-gray-100 px-3 py-1 border border-gray-300 border-b-0 text-[#0000FF] cursor-pointer">Card Limit Info</div>
        <Link href={`/echamps/accounts/${ECHAMPS_ACCOUNT_NUMBER}`} className="ml-auto bg-gray-100 px-3 py-1 border border-gray-300 border-b-0 text-[#0000FF] font-bold">→ Return to Card List</Link>
      </div>

      <div className="grid grid-cols-[1fr_1fr] gap-x-12 gap-y-2 font-mono text-sm max-w-4xl bg-gray-50 p-6 border border-gray-300">
        <div className="flex justify-between border-b border-gray-200 border-dashed pb-1">
          <span className="text-gray-500">Card Number:</span>
          <Link href={`/echamps/card/${card.lastFour}`} className="font-bold text-[#0000FF] hover:underline" data-testid="link-card-number">{card.fullNumber.replace(/-/g, '')}</Link>
        </div>
        <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">Name Line 1:</span> <span>{card.cardHolder}</span></div>
        
        <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">Sequence Number:</span> <span>0001</span></div>
        <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">Card Technology:</span> <span>Contactless Chip Card</span></div>
        
        <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">Card Expiry Date:</span> <span>{card.expiry}</span></div>
        <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">ATM Access:</span> <span>{card.atmAccess === 'Yes' ? 'ATM access allowed' : 'No ATM'}</span></div>
        
        <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">Card Type:</span> <span>Corporate</span></div>
        <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">PIN Required:</span> <span>No</span></div>
        
        {(() => {
          const isFraudBlocked = card.unpostedTransaction?.declineReason?.includes('FALC');
          const statusLabel = card.status === 'Closed' ? 'CLOSED' : isFraudBlocked ? 'ACTIVE-FRAUD BLOCKED' : 'ACTIVE-PERMANENT';
          const statusClass = card.status === 'Closed' ? 'text-red-600 font-bold' : isFraudBlocked ? 'text-orange-600 font-bold' : 'text-green-700 font-bold';
          return (
            <>
              <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">Card Status:</span> <span className={statusClass}>{statusLabel}</span></div>
              <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">Digital Wallet:</span> <span>Not Registered</span></div>

              {(card.status === 'Closed' || isFraudBlocked) && (
                <>
                  <div className="flex justify-between border-b border-gray-200 border-dashed pb-1">
                    <span className="text-red-600 font-bold">Block Code 1:</span>
                    <span className="text-red-600">{card.status === 'Closed' ? 'C - Closed by cardholder' : 'F - Fraud alert block'}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">Auth Counter:</span> <span>0</span></div>
                  <div className="flex justify-between border-b border-gray-200 border-dashed pb-1">
                    <span className="text-red-600 font-bold">Block Code Date 1:</span>
                    <span>{card.status === 'Closed' ? (card.closedDate ?? '—') : card.unpostedTransaction?.date ?? '—'}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 border-dashed pb-1"><span className="text-gray-500">Auth Amt:</span> <span>AED 0.00</span></div>
                </>
              )}
            </>
          );
        })()}
      </div>

      <div className="mt-8 flex gap-4">
        <Link href={`/echamps/card/${card.lastFour}/auths`}>
          <button className="bg-gray-200 border border-gray-400 px-6 py-1.5 font-bold hover:bg-gray-300 shadow-sm" data-testid="btn-view-auths">View Card Auths</button>
        </Link>
        <button onClick={() => setModalOpen(true)} className="bg-white text-red-600 border border-red-600 px-6 py-1.5 font-bold hover:bg-red-50 shadow-sm">Apply Block Code</button>
      </div>

      <ApprovalGateModal open={modalOpen} onOpenChange={setModalOpen} system="eChamps" actionDesc="Apply status block code to card" />
    </EChampsLayout>
  );
}

export function EChampsAuths() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();

  if (!state.auth.echamps) {
    setLocation("/echamps/login");
    return null;
  }

  // Card-addressed: the auth rows belong to the card in the URL, not to a globally
  // selected scenario. No scenario has to be chosen before a robot opens this page.
  const auths = ECHAMPS_AUTHS[params.cardNumber ?? ""] || [];

  return (
    <EChampsLayout cardLastFour={params.cardNumber}>
      <div className="bg-[#000080] text-white font-bold px-2 py-1 inline-block mb-4 text-sm tracking-widest">Authorisations</div>
      
      {auths.length === 0 ? (
        <div className="border border-gray-400 p-8 text-center bg-gray-50 font-mono text-gray-500">No authorisation records found for this card in the selected time period.</div>
      ) : (
        <table className="w-full text-left text-xs border-collapse border border-gray-400 font-mono">
          <thead className="bg-gray-200 border-b-2 border-gray-400 text-gray-800">
            <tr>
              <th className="p-2 border-r border-gray-300">Date</th>
              <th className="p-2 border-r border-gray-300">Time</th>
              <th className="p-2 border-r border-gray-300">Card Number</th>
              <th className="p-2 border-r border-gray-300 text-right">Txn Amt</th>
              <th className="p-2 border-r border-gray-300 text-right">Settlement Amt</th>
              <th className="p-2 border-r border-red-500 border-l border-l-red-500 bg-red-50 text-red-800">Reason Code/Description</th>
              <th className="p-2 border-r border-gray-300 text-center">Final Action</th>
              <th className="p-2 border-r border-gray-300 text-center">Auth Code</th>
              <th className="p-2 text-center">Reversal Type</th>
            </tr>
          </thead>
          <tbody>
            {auths.map((a, i) => (
              <tr key={i} className={`border-b border-gray-300 ${i % 2 === 0 ? 'bg-white' : 'bg-[#e8e0ff]'}`}>
                <td className="p-2 border-r border-gray-300 whitespace-nowrap">{a.date}</td>
                <td className="p-2 border-r border-gray-300">{a.time}</td>
                <td className="p-2 border-r border-gray-300">{a.cardNumber.replace(/-/g, '')}</td>
                <td className="p-2 border-r border-gray-300 text-right">{a.txnAmt}</td>
                <td className="p-2 border-r border-gray-300 text-right">{a.settlementAmt}</td>
                <td className="p-2 border-r border-red-500 border-l border-l-red-500 bg-red-50 font-bold text-red-700" data-testid="auth-reason-code">
                  {a.reasonCode} - {a.reasonDesc}
                </td>
                <td className="p-2 border-r border-gray-300 text-center text-red-600 font-bold">{a.finalAction}</td>
                <td className="p-2 border-r border-gray-300 text-center">{a.authCode || 'N/A'}</td>
                <td className="p-2 text-center text-gray-500 text-[10px]">{a.reversalType}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </EChampsLayout>
  );
}

// ─── Balance Detail ───────────────────────────────────────────────────────────

export function EChampsBalanceDetail() {
  const { state } = useSim();
  const [, setLocation] = useLocation();

  if (!state.auth.echamps) {
    setLocation('/echamps/login');
    return null;
  }

  // /echamps/balance-detail carries no card, so it shows the card last opened and falls back
  // to the client's first card. No robot visits this page.
  const balanceCardLastFour = state.activeCardLastFour ?? CLIENT.cards[0].lastFour;
  const auths = ECHAMPS_AUTHS[balanceCardLastFour ?? ""] ?? [];
  const firstAuth = auths[0];
  const cardOpenToBuy = firstAuth?.openToBuy ?? '0.00 AED';

  const prog = CLIENT.programs[0];
  const programOpenToBuy = prog.availableCapacity;
  const activeCard = CLIENT.cards.find(c => c.lastFour === balanceCardLastFour) ?? CLIENT.cards[0];

  return (
    <EChampsLayout cardLastFour={activeCard.lastFour}>
      <div className="p-5 text-sm">
        {/* Page title */}
        <div className="bg-[#1a1a2e] text-white px-5 py-3 mb-4 flex items-center justify-between">
          <span className="font-semibold tracking-wide">Balance Detail</span>
          <Link href={`/echamps/card/${activeCard.lastFour}/info`} className="text-cyan-300 text-xs hover:underline">← Back to Card Info</Link>
        </div>

        {/* Account header */}
        <div className="border border-gray-300 bg-white mb-4">
          <div className="bg-gray-100 border-b border-gray-300 px-4 py-2 font-bold text-xs uppercase tracking-wide text-gray-600">Account Information</div>
          <div className="p-4 grid grid-cols-[180px_1fr_180px_1fr] gap-3 text-xs">
            <div className="text-gray-500">Account Number:</div>
            <div className="font-mono" data-testid="bd-account-number">{prog.fullAccountNumber}</div>
            <div className="text-gray-500">Account Name:</div>
            <div data-testid="bd-account-name">{CLIENT.clientName}</div>
            <div className="text-gray-500">Customer Number:</div>
            <div data-testid="bd-customer-number">{CLIENT.customerNumber}</div>
            <div className="text-gray-500">Program:</div>
            <div data-testid="bd-program">{prog.fullProgramNumber}</div>
          </div>
        </div>

        {/* Card-level balance */}
        <div className="border border-gray-300 bg-white mb-4">
          <div className="bg-[#0070C0] text-white px-4 py-2 font-bold text-xs uppercase tracking-wide">Card Level Balance</div>
          <div className="p-4 grid grid-cols-[220px_1fr_220px_1fr] gap-3 text-xs">
            <div className="text-gray-500">Card Number:</div>
            <div className="font-mono" data-testid="bd-card-number">{activeCard.fullNumber}</div>
            <div className="text-gray-500">Cardholder:</div>
            <div data-testid="bd-cardholder">{activeCard.cardHolder}</div>
            <div className="text-gray-500">Credit Limit (AED):</div>
            <div data-testid="bd-card-limit">{activeCard.cardLimit}</div>
            <div className="text-gray-500">Outstanding Balance (AED):</div>
            <div data-testid="bd-outstanding">{activeCard.outstandingBalance}</div>
            <div className="text-gray-500">Available Balance (AED):</div>
            <div className="font-semibold text-[#0070C0]" data-testid="bd-available">{activeCard.availableBalance}</div>
            <div className="text-gray-500">Open to Buy (AED):</div>
            <div className={`font-bold ${cardOpenToBuy.startsWith('0') ? 'text-red-600' : 'text-green-700'}`} data-testid="bd-card-open-to-buy">{cardOpenToBuy}</div>
          </div>
        </div>

        {/* Program-level balance */}
        <div className="border border-gray-300 bg-white">
          <div className="bg-[#1a1a2e] text-white px-4 py-2 font-bold text-xs uppercase tracking-wide">Program Level Balance</div>
          <div className="p-4 grid grid-cols-[220px_1fr_220px_1fr] gap-3 text-xs">
            <div className="text-gray-500">Program Limit (AED):</div>
            <div data-testid="bd-prog-limit">{prog.programLimit}</div>
            <div className="text-gray-500">Total Cardholder Limits (AED):</div>
            <div data-testid="bd-prog-total-limits">{prog.totalCardholderLimits}</div>
            <div className="text-gray-500">Available Capacity (AED):</div>
            <div data-testid="bd-prog-capacity">{prog.availableCapacity}</div>
            <div className="text-gray-500">Program Open to Buy (AED):</div>
            <div className="font-bold text-green-700" data-testid="bd-prog-open-to-buy">{programOpenToBuy}</div>
          </div>
        </div>
      </div>
    </EChampsLayout>
  );
}
