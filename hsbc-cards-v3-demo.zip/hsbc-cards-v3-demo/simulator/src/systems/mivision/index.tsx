import React, { useEffect, useState } from 'react';
import { useLocation, Link, useParams } from 'wouter';
import { useSim } from '../../context/SimContext';
import { BrowserChrome } from '../../shared/BrowserChrome';
import { SimHelper } from '../../shared/SimHelper';
import { ApprovalGateModal } from '../../shared/ApprovalGateModal';
import { MIVISION_CLIENTS, type MiVisionCard } from '../../data/seed';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isVirtual(productType: string) {
  return productType.toLowerCase().includes('virtual');
}

const ADVANCED_SEARCH_FIELDS = [
  'Account Close Date',
  'Account Open Date',
  'Account Status',
  'Account Status Code',
  'Billing Account Card Type',
  'Product Type',
  'Billing Currency',
  'Daily Cash Advance Limit',
  'Days Overdue',
  'Expiry Date',
  'Card Limit',
  'Single Transaction Limit',
  'Lost or Stolen Date',
  'Domicile Country',
  'Preferred Language',
  'Balance Percent Remaining',
  'Balance Percent Spent',
  'Available Balance',
  'Last Purchase Date',
  'Last Four Digits Of Card Number',
];

// ─── Nav ──────────────────────────────────────────────────────────────────────

const HOME_TABS = ['Home', 'Client Groups', 'Programs', 'Requests', 'Reports'];
const CLIENT_TABS = ['Home', 'Accounts', 'Users', 'Transactions', 'Requests', 'Alerts', 'Reports', 'Settings'];

function MiVisionNav({
  children,
  activeTab = 'Home',
  context = 'home',
  url,
  clientId,
}: {
  children: React.ReactNode;
  activeTab?: string;
  context?: 'home' | 'client';
  url?: string;
  clientId?: string;
}) {
  const tabs = context === 'client' ? CLIENT_TABS : HOME_TABS;
  const resolvedUrl = url ?? `https://admin.mivision.hsbc.ae/ba`;
  const [, setLocation] = useLocation();
  return (
    <BrowserChrome url={resolvedUrl}>
      {/* Top bar */}
      <div className="bg-[#1a1a2e] text-white px-6 py-2.5 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <svg width="32" height="32" viewBox="0 0 40 40">
            <polygon points="20,1 37,10 37,30 20,39 3,30 3,10" fill="#DB0011"/>
            <text x="20" y="27" textAnchor="middle" fill="white" fontSize="16" fontWeight="bold">H</text>
          </svg>
          <span className="font-bold text-base tracking-wide">HSBC</span>
        </div>
        <div className="flex items-center gap-5 text-sm">
          <span className="text-gray-300 flex items-center gap-1 cursor-pointer">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          </span>
          <span className="text-gray-300 flex items-center gap-1 cursor-pointer">
            English (United Kingdom)
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>
          </span>
          <span className="text-gray-300 cursor-pointer">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
          </span>
          <div className="flex items-center gap-1 cursor-pointer">
            <div className="text-right">
              <div className="font-semibold text-xs">Roshan Riyaz Afreen</div>
              <div className="text-gray-400 text-[10px]">Last login: 24/06/2026 11:52</div>
            </div>
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>
          </div>
          <button className="bg-[#DB0011] hover:bg-[#C40404] text-white px-4 py-1.5 text-xs font-bold transition-colors">Log Off</button>
        </div>
      </div>
      {/* Tab bar */}
      <div className="bg-[#1a1a2e] px-4 flex text-sm font-medium border-t border-[#2a2a4a]">
        {tabs.map(tab => {
          const handleTabClick = () => {
            if (context === 'client' && clientId) {
              if (tab === 'Home') setLocation(`/mivision/accounts/${clientId}`);
              else if (tab === 'Accounts') setLocation(`/mivision/accounts/${clientId}/list`);
              else if (tab === 'Requests') setLocation(`/mivision/accounts/${clientId}/requests`);
            }
          };
          return (
            <div
              key={tab}
              onClick={handleTabClick}
              className={`px-4 py-3 whitespace-nowrap ${
                tab === activeTab
                  ? 'border-b-2 border-white text-white'
                  : 'text-gray-400 hover:text-gray-200 cursor-pointer'
              }`}
            >
              {tab}
            </div>
          );
        })}
      </div>
      <div className="bg-white min-h-[500px]">
        {children}
      </div>
      {/* Footer */}
      <div className="bg-[#1a1a2e] text-gray-400 text-xs px-6 py-4 mt-auto">
        <div className="flex gap-6 mb-2">
          <span className="flex items-center gap-1 hover:text-white cursor-pointer">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            Privacy and Security
          </span>
          <span className="flex items-center gap-1 hover:text-white cursor-pointer">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
            Hyperlink Policy
          </span>
        </div>
        <div className="flex gap-6">
          <span className="hover:text-white cursor-pointer">Terms &amp; Conditions of use</span>
          <span className="hover:text-white cursor-pointer">Privacy and data protection statement</span>
        </div>
      </div>
    </BrowserChrome>
  );
}

// ─── MV-01: Login ─────────────────────────────────────────────────────────────

export function MiVisionLogin() {
  const [, setLocation] = useLocation();
  const { dispatch } = useSim();

  useEffect(() => {
    dispatch.MIVISION_GENERATE_CHALLENGE();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation('/mivision/security');
  };

  return (
    <BrowserChrome url="https://admin.mivision.hsbc.ae/logon?ReturnUrl=%2Fba">
      <div className="bg-gray-100 min-h-[600px] flex flex-col items-center pt-20">
        <div className="w-[420px] bg-white border-t-4 border-[#DB0011] shadow-md p-8">
          <h2 className="text-2xl font-light mb-6 text-[#212121]">Log On</h2>
          <form onSubmit={handleLogin} className="flex flex-col gap-4">
            <div>
              <label className="block text-sm text-[#595959] mb-1">Email or Username</label>
              <input
                className="w-full border border-gray-300 p-2 outline-none focus:border-[#DB0011]"
                data-testid="input-mivision-username"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-[#595959] mb-1">Password</label>
              <input
                type="password"
                className="w-full border border-gray-300 p-2 outline-none focus:border-[#DB0011]"
                data-testid="input-mivision-password"
                required
              />
            </div>
            <div className="text-sm text-[#0070C0] mt-2 hover:underline cursor-pointer">Forgotten password? &gt;</div>
            <div className="text-sm text-[#0070C0] mb-4 hover:underline cursor-pointer">Register for HSBC Mivision &gt;</div>
            <button
              type="submit"
              className="bg-[#DB0011] text-white py-2.5 font-bold hover:bg-[#C40404] transition-colors"
              data-testid="btn-mivision-login"
            >
              Log On
            </button>
          </form>
        </div>
        <div className="mt-16 text-xs text-gray-500 text-center space-x-2">
          <span className="hover:underline cursor-pointer">Privacy and Security</span>
          <span>|</span>
          <span className="hover:underline cursor-pointer">⚙ Hyperlink Policy</span>
          <span>|</span>
          <span className="hover:underline cursor-pointer">Terms &amp; Conditions of use</span>
          <span>|</span>
          <span className="hover:underline cursor-pointer">Privacy and data protection statement</span>
        </div>
        <div className="mt-4 text-xs text-gray-400">RESTRICTED — Internal PoC use only</div>
      </div>
    </BrowserChrome>
  );
}

// ─── MV-02: Validate Security Number ─────────────────────────────────────────

export function MiVisionSecurity() {
  const { state, dispatch } = useSim();
  const [, setLocation] = useLocation();
  const [vals, setVals] = useState(['', '', '']);

  const challenge = state.mfa.mivision.challenge;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (vals.every(v => v.length > 0)) {
      dispatch.MFA_PASS('mivision');
      dispatch.LOG_ACTION('mivision', 'mfa_passed', null);
      setLocation('/mivision/home');
    }
  };

  return (
    <BrowserChrome url="https://admin.mivision.hsbc.ae/securitynumberandtoken/validate?ReturnUrl=%2Fba&AutomaticallyGenerateToken=True">
      <div className="bg-gray-100 min-h-[600px] flex flex-col items-center pt-20">
        <span data-testid="mivision-challenge-positions" style={{ display: 'none' }}>
          {challenge.join(',')}
        </span>
        <div className="w-[520px] bg-white border-t-4 border-[#DB0011] shadow-md p-8">
          <h2 className="text-2xl font-light mb-2 text-[#212121]">Validate Security Number</h2>
          <p className="text-sm text-[#595959] mb-4">
            Please enter the specific digits of your security number into the textboxes below.
          </p>

          {/* Demo challenge display */}
          <div className="mb-6 bg-amber-50 border-2 border-amber-400 rounded-lg p-4 text-center">
            <div className="text-xs font-bold text-amber-700 uppercase tracking-wider mb-2">⚡ Demo Mode — Security Number</div>
            <div className="flex justify-center gap-1.5 mb-2">
              {state.mfa.mivision.securityNumber.split('').map((digit, i) => {
                const pos = i + 1;
                const isRequired = challenge.includes(pos);
                return (
                  <div key={i} className={`w-8 h-10 flex flex-col items-center justify-between rounded ${isRequired ? 'bg-amber-400' : 'bg-amber-100'}`}>
                    <div className="text-[9px] font-bold text-amber-700 pt-0.5">{pos}</div>
                    <div className={`font-mono text-lg font-bold pb-0.5 ${isRequired ? 'text-amber-900' : 'text-amber-500'}`}>{digit}</div>
                  </div>
                );
              })}
            </div>
            <div className="text-xs text-amber-600">Highlighted positions are required — enter any single digit in each field</div>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-6">
            <div className="flex gap-8 justify-center">
              {challenge.map((pos, i) => (
                <div key={pos} className="flex flex-col items-center gap-2">
                  <label className="text-sm font-medium text-[#212121]">Position {pos}</label>
                  <input
                    type="password"
                    maxLength={1}
                    className="border border-gray-400 w-14 h-12 text-center text-xl outline-none focus:border-[#DB0011]"
                    value={vals[i]}
                    onChange={e => {
                      const newVals = [...vals];
                      newVals[i] = e.target.value;
                      setVals(newVals);
                    }}
                    data-position={pos}
                    data-testid={`mfa-pos-${pos}`}
                    required
                  />
                </div>
              ))}
            </div>

            <div className="text-sm text-[#0070C0] hover:underline cursor-pointer">
              Forgotten Security Number? &gt;
            </div>
            <div className="flex justify-between mt-2">
              <button
                type="button"
                onClick={() => setLocation('/mivision/login')}
                className="border border-gray-400 px-8 py-2 text-[#595959] font-bold hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-[#DB0011] text-white px-10 py-2 font-bold hover:bg-[#C40404]"
                data-testid="btn-mivision-security-submit"
              >
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
      <SimHelper>
        MiVision positional challenge: positions {challenge.join(', ')} | Enter any single digit in each field to proceed
      </SimHelper>
    </BrowserChrome>
  );
}

// ─── MV-03: Home Search ───────────────────────────────────────────────────────

export function MiVisionHome() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const [q, setQ] = useState('');
  const [filterType, setFilterType] = useState('All');

  if (!state.auth.mivision) {
    setLocation('/mivision/login');
    return null;
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    setLocation(`/mivision/search?q=${encodeURIComponent(q.trim())}&type=${filterType}`);
  };

  return (
    <MiVisionNav activeTab="Home" url="https://admin.mivision.hsbc.ae/ba">
      <div className="p-8 max-w-4xl mx-auto">
        <h1 className="text-2xl font-light text-[#212121] mb-8">
          Search for a Client Group, Program, Administrator or Email
        </h1>

        <form onSubmit={handleSearch} className="flex mb-8 shadow-sm">
          <input
            value={q}
            onChange={e => setQ(e.target.value)}
            className="flex-1 border border-gray-400 border-r-0 p-3 outline-none focus:ring-1 focus:ring-[#DB0011] text-sm"
            placeholder="Enter client name or customer number..."
            data-testid="input-mivision-search"
          />
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="border border-gray-400 border-r-0 bg-gray-50 px-3 outline-none text-sm"
          >
            <option>All</option>
            <option>Client Group</option>
            <option>Program</option>
            <option>Administrator</option>
            <option>Email</option>
          </select>
          <button
            type="button"
            className="border border-gray-400 border-r-0 bg-gray-50 px-3 hover:bg-gray-100 text-gray-600"
          >
            ▼
          </button>
          <button
            type="submit"
            className="bg-[#DB0011] text-white px-8 font-bold hover:bg-[#C40404]"
            data-testid="btn-mivision-search"
          >
            Search
          </button>
        </form>

        <div className="flex gap-3 text-sm text-[#0070C0]">
          <span className="border border-gray-300 px-4 py-1.5 rounded hover:bg-gray-50 cursor-pointer">Add Widget</span>
          <span className="border border-gray-300 px-4 py-1.5 rounded hover:bg-gray-50 cursor-pointer">Export Widgets</span>
        </div>
      </div>
    </MiVisionNav>
  );
}

// ─── MV-04: Search Results ────────────────────────────────────────────────────

export function MiVisionSearchResults() {
  const { state } = useSim();
  const [, setLocation] = useLocation();

  if (!state.auth.mivision) {
    setLocation('/mivision/login');
    return null;
  }

  const params = new URLSearchParams(window.location.search);
  const q = params.get('q') || '';
  const filterType = params.get('type') || 'All';

  const matchedClients = MIVISION_CLIENTS.filter(client => {
    const lq = q.toLowerCase();
    return (
      client.clientName.toLowerCase().includes(lq) ||
      client.customerNumber.includes(lq) ||
      client.searchAliases.some(a => a.toLowerCase().includes(lq))
    );
  });

  const hasResults = matchedClients.length > 0;

  return (
    <MiVisionNav activeTab="Client Groups" url={`https://admin.mivision.hsbc.ae/ba?Search=${encodeURIComponent(q)}&FilterType=${filterType}`}>
      <div className="p-8">
        {/* Breadcrumb */}
        <div className="text-xs text-gray-500 mb-4">
          <span
            className="text-[#0070C0] hover:underline cursor-pointer"
            onClick={() => setLocation('/mivision/home')}
          >
            Home
          </span>
          {' / Search Results'}
        </div>

        {/* Retained search bar */}
        <form
          onSubmit={e => {
            e.preventDefault();
            const fd = new FormData(e.target as HTMLFormElement);
            const newQ = fd.get('q') as string;
            if (newQ.trim()) setLocation(`/mivision/search?q=${encodeURIComponent(newQ.trim())}&type=${filterType}`);
          }}
          className="flex mb-8 shadow-sm max-w-4xl"
        >
          <input
            name="q"
            defaultValue={q}
            className="flex-1 border border-gray-400 border-r-0 p-3 outline-none focus:ring-1 focus:ring-[#DB0011] text-sm"
          />
          <select className="border border-gray-400 border-r-0 bg-gray-50 px-3 outline-none text-sm">
            <option>All</option>
          </select>
          <button type="button" className="border border-gray-400 border-r-0 bg-gray-50 px-3 text-gray-600">▼</button>
          <button type="submit" className="bg-[#DB0011] text-white px-8 font-bold hover:bg-[#C40404]">Search</button>
        </form>

        {!hasResults ? (
          <div className="text-gray-500 italic text-sm">No results found for "{q}".</div>
        ) : (
          <div className="grid grid-cols-3 gap-6">
            {/* Client Groups */}
            <div>
              <h3 className="font-bold border-b-2 border-gray-300 pb-2 mb-4 text-[#212121]">
                Client Groups ({matchedClients.length})
              </h3>
              {matchedClients.map(client => (
                <div key={client.id} className="relative border border-gray-200 rounded p-4 mb-3 bg-white shadow-sm hover:shadow">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#DB0011] text-white flex items-center justify-center font-bold text-sm shrink-0">
                      {client.initialsAvatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div
                        className="font-bold text-[#212121] text-sm leading-tight"
                        data-testid="client-name"
                      >
                        {client.clientName}
                      </div>
                      <div className="text-xs text-gray-500 mt-0.5">{client.shortCode}</div>
                      <div
                        className="text-xs text-gray-400 font-mono mt-1"
                        data-testid="customer-number"
                      >
                        {client.customerNumber}/{client.maskedAccountRef.split('/')[1]}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setLocation(`/mivision/accounts/${client.id}`)}
                    className="mt-3 w-full bg-[#DB0011] hover:bg-[#C40404] text-white text-xs font-bold py-1.5 px-3 flex items-center justify-center gap-1.5 transition-colors"
                    data-testid={`sign-in-client-${client.id}`}
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M13 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h7"/>
                      <polyline points="16 8 20 12 16 16"/>
                      <line x1="20" y1="12" x2="10" y2="12"/>
                    </svg>
                    Sign in to client
                  </button>
                </div>
              ))}
            </div>

            {/* Programs */}
            <div>
              <h3 className="font-bold border-b-2 border-gray-300 pb-2 mb-4 text-[#212121]">
                Programs ({matchedClients.reduce((acc, c) => acc + c.programs.length, 0)})
              </h3>
              {matchedClients.flatMap(client =>
                client.programs.map(prog => (
                  <div key={prog.id} className="border border-gray-200 rounded p-4 mb-3 bg-white shadow-sm">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs shrink-0">
                        {prog.displayCode}
                      </div>
                      <div>
                        <div className="font-bold text-[#212121] text-sm leading-tight">{prog.name}</div>
                        <div className="text-xs text-gray-400 font-mono mt-1">{prog.code.slice(0, 16)}</div>
                        <div className="text-xs text-gray-500 mt-0.5">{client.clientName.slice(0, 20)}...</div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Users */}
            <div>
              <h3 className="font-bold border-b-2 border-gray-300 pb-2 mb-4 text-[#212121]">
                Users ({matchedClients.reduce((acc, c) => acc + c.users.length, 0)})
              </h3>
              {matchedClients.flatMap(client =>
                client.users.map((user, i) => (
                  <div key={i} className="border border-gray-200 rounded p-4 mb-3 bg-white shadow-sm">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-green-100 text-green-800 flex items-center justify-center font-bold text-xs shrink-0">
                        {user.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <div className="font-bold text-[#212121] text-sm">{user.name}</div>
                        <div className="text-xs text-gray-500 mt-0.5">{user.company}</div>
                        <div className="text-xs text-gray-400">({user.code})</div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </MiVisionNav>
  );
}

// ─── MV-05: Client Home / Accounts Overview ───────────────────────────────────

export function MiVisionAccounts() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const client = MIVISION_CLIENTS.find(x => x.id === params.clientId);
  const [selectedProg, setSelectedProg] = useState(0);

  if (!state.auth.mivision) {
    setLocation('/mivision/login');
    return null;
  }
  if (!client) return <MiVisionNav context="client" activeTab="Accounts">Client not found</MiVisionNav>;

  const prog = client.programs[selectedProg];

  return (
    <MiVisionNav
      context="client"
      activeTab="Home"
      clientId={client.id}
      url={`https://admin.mivision.hsbc.ae/ca`}
    >
      <div className="p-6 max-w-4xl">
        <div className="flex gap-6">
          {/* Left: Actions */}
          <div className="w-64 shrink-0">
            <div className="border border-gray-300 bg-white">
              <div className="font-semibold p-3 border-b border-gray-200 text-sm text-[#212121]">Actions</div>
              <Link
                href={`/mivision/accounts/${client.id}/limit-amendment`}
                className="block p-3 text-[#0070C0] hover:bg-gray-50 text-sm border-b border-gray-100"
                data-testid="link-limit-amendment"
              >
                Program Limit Amendment &gt;
              </Link>
              <Link
                href={`/mivision/accounts/${client.id}/new-card`}
                className="block p-3 text-[#0070C0] hover:bg-gray-50 text-sm"
                data-testid="link-request-new-card"
              >
                Request New Card &gt;
              </Link>
            </div>
          </div>

          {/* Right: Programs Info */}
          <div className="flex-1">
            <div className="border border-gray-300 bg-white">
              <div className="font-semibold p-3 border-b border-gray-200 text-sm text-[#212121]">Programs</div>
              <div className="p-4">
                {/* Program selector row */}
                <div className="flex gap-2 mb-4">
                  <select
                    className="flex-1 border border-gray-300 p-2 outline-none text-sm"
                    value={selectedProg}
                    onChange={e => setSelectedProg(Number(e.target.value))}
                    data-testid="select-program"
                  >
                    {client.programs.map((p, i) => (
                      <option key={p.id} value={i}>{p.name}</option>
                    ))}
                  </select>
                  <button className="bg-[#DB0011] hover:bg-[#C40404] text-white px-5 py-2 text-sm font-bold transition-colors">Go</button>
                </div>

                {/* Company Info + Statements row */}
                <div className="flex justify-between items-center text-sm mb-3 border-b border-gray-100 pb-3">
                  <span className="text-[#0070C0] hover:underline cursor-pointer">Company Info</span>
                  <span className="text-[#0070C0] hover:underline cursor-pointer text-xs">
                    View Latest <span className="underline">Statements</span>
                  </span>
                </div>

                {/* Program stats — label/value rows matching screenshot */}
                <div className="text-sm space-y-2">
                  <div className="flex justify-between">
                    <span className="text-[#212121]">Program Limit</span>
                    <span className="font-semibold" data-testid="program-limit">{prog.programLimit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#212121]">Total Cardholder Limits</span>
                    <span className="font-semibold" data-testid="total-cardholder-limits">{prog.totalCardholderLimits}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-100 pt-2">
                    <span className="text-[#212121]">Available Capacity</span>
                    <span className="font-bold text-green-700" data-testid="available-capacity">{prog.availableCapacity}</span>
                  </div>
                  <div className="pt-1">
                    <Link
                      href={`/mivision/accounts/${client.id}/unposted`}
                      className="text-[#0070C0] hover:underline text-sm"
                      data-testid="link-unposted-transactions"
                    >
                      View Unposted Transactions
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Widget buttons — bottom right, matching screenshot */}
        <div className="flex justify-end gap-3 text-sm mt-6">
          <button className="border border-gray-400 px-5 py-1.5 bg-white hover:bg-gray-50 text-[#212121]">Add Widget</button>
          <button className="border border-gray-400 px-5 py-1.5 bg-white hover:bg-gray-50 text-[#212121]">Export Widgets</button>
        </div>
      </div>
    </MiVisionNav>
  );
}

// ─── MV-06: Accounts List ─────────────────────────────────────────────────────

export function MiVisionAccountsList() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const client = MIVISION_CLIENTS.find(x => x.id === params.clientId);

  const [activeTab, setActiveTab] = useState('All');
  const [showFilterPanel, setShowFilterPanel] = useState(false);
  const [filterField, setFilterField] = useState('Last Four Digits Of Card Number');
  const [filterOp, setFilterOp] = useState('Contains');
  const [filterVal, setFilterVal] = useState('');
  const [appliedFilter, setAppliedFilter] = useState<{ field: string; op: string; val: string } | null>(null);
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  const [selectedCard, setSelectedCard] = useState<string | null>(null);

  if (!state.auth.mivision) {
    setLocation('/mivision/login');
    return null;
  }
  if (!client) return <MiVisionNav context="client" activeTab="Accounts">Client not found</MiVisionNav>;

  const applyFilter = () => {
    if (filterVal.trim()) {
      setAppliedFilter({ field: filterField, op: filterOp, val: filterVal.trim() });
      setShowFilterPanel(false);
    }
  };

  const removeFilter = () => {
    setAppliedFilter(null);
    setFilterVal('');
  };

  let displayCards = client.cards;

  // Tab filter
  if (activeTab === 'Open') displayCards = displayCards.filter(c => c.status === 'Active');
  if (activeTab === 'Closed') displayCards = displayCards.filter(c => c.status === 'Closed');

  // Applied filter
  if (appliedFilter) {
    if (appliedFilter.field === 'Last Four Digits Of Card Number') {
      displayCards = displayCards.filter(c => c.lastFour.includes(appliedFilter.val));
    } else if (appliedFilter.field === 'Product Type') {
      displayCards = displayCards.filter(c =>
        c.productType.toLowerCase().includes(appliedFilter.val.toLowerCase())
      );
    }
  }

  const missingCount = client.cards.filter(c => !c.email || c.email === 'Not set').length;
  const tabs = ['Amend', 'Open', `Missing Details (${missingCount})`, 'Closed', 'All'];

  return (
    <MiVisionNav
      context="client"
      activeTab="Accounts"
      clientId={client.id}
      url={`https://admin.mivision.hsbc.ae/ca/accounts?Page=1&AccountStatus=All`}
    >
      {/* Dark "Accounts" page title bar */}
      <div className="bg-[#1a1a2e] text-white px-6 py-4">
        <h1 className="text-xl font-semibold">Accounts</h1>
      </div>

      <div className="p-5">
        {/* Filter bar — matches real MiVision layout */}
        <div className="mb-4">
          {/* Row 1: program dropdown + name input + filter icon + Search */}
          <div className="flex gap-2 mb-2">
            <select
              className="border border-gray-300 px-3 py-1.5 text-sm bg-white outline-none min-w-[180px]"
              data-testid="select-all-programs"
            >
              <option value="">All Programs</option>
              {client.programs.map(p => (
                <option key={p.id} value={p.fullAccountNumber}>
                  {p.name} ({p.fullAccountNumber})
                </option>
              ))}
            </select>
            <input
              className="flex-1 border border-gray-300 px-3 py-1.5 text-sm outline-none"
              placeholder="Accountholder Name or Employee ID"
            />
            <button
              onClick={() => setShowFilterPanel(!showFilterPanel)}
              className="border border-gray-300 bg-[#0070C0] px-3 py-1.5 text-white hover:bg-[#005A99] flex items-center"
              data-testid="btn-advanced-search-toggle"
              title="Filter"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="white" stroke="white" strokeWidth="1">
                <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
              </svg>
            </button>
            <button className="border border-gray-300 bg-white px-5 py-1.5 text-sm hover:bg-gray-50">Search</button>
          </div>

          {/* Advanced filter panel */}
          {showFilterPanel && (
            <div className="border border-gray-300 bg-white p-4 mb-2">
              <div className="flex gap-3 flex-wrap items-end">
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Field</label>
                  <select
                    value={filterField}
                    onChange={e => setFilterField(e.target.value)}
                    className="border border-gray-300 px-2 py-1.5 text-sm bg-white outline-none min-w-[220px]"
                    data-testid="select-filter-field"
                  >
                    {ADVANCED_SEARCH_FIELDS.map(f => (
                      <option key={f}>{f}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Operator</label>
                  <select
                    value={filterOp}
                    onChange={e => setFilterOp(e.target.value)}
                    className="border border-gray-300 px-2 py-1.5 text-sm bg-white outline-none"
                    data-testid="select-filter-op"
                  >
                    <option>Contains</option>
                    <option>Equals</option>
                    <option>Starts With</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Value</label>
                  <input
                    value={filterVal}
                    onChange={e => setFilterVal(e.target.value)}
                    className="border border-gray-300 px-2 py-1.5 text-sm outline-none w-28"
                    placeholder="e.g. 9155"
                    data-testid="input-filter-value"
                    onKeyDown={e => e.key === 'Enter' && applyFilter()}
                  />
                </div>
                <button
                  onClick={() => setShowFilterPanel(false)}
                  className="border border-gray-300 px-4 py-1.5 text-sm hover:bg-gray-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Applied filter pill */}
          {appliedFilter && (
            <div className="flex items-center gap-2 text-sm mb-2">
              <span className="bg-white border border-gray-300 px-3 py-1 flex items-center gap-2">
                <span className="font-medium text-gray-700">{appliedFilter.field}</span>
                <span className="text-gray-400">{appliedFilter.op}</span>
                <span className="font-mono bg-gray-100 px-2 py-0.5 text-xs">{appliedFilter.val}</span>
                <button onClick={removeFilter} className="text-red-500 hover:text-red-700 font-bold ml-1">×</button>
              </span>
            </div>
          )}

          {/* Row 2: Add Filter (right-aligned) */}
          <div className="flex justify-end mb-1">
            <button
              onClick={() => setShowFilterPanel(!showFilterPanel)}
              className="border border-gray-300 bg-white px-3 py-1 text-xs hover:bg-gray-50 flex items-center gap-1"
              data-testid="btn-add-filter"
            >
              <span className="font-bold text-base leading-none">⊕</span> Add Filter
            </button>
          </div>

          {/* Row 3: Search (right-aligned) */}
          <div className="flex justify-end">
            <button
              onClick={applyFilter}
              className="border border-gray-300 bg-white px-5 py-1 text-sm hover:bg-gray-50"
              data-testid="btn-apply-filter"
            >
              Search
            </button>
          </div>
        </div>

        {/* Info banner + Amend action button */}
        <div className="flex items-center justify-between mb-4 gap-3">
          <div className="bg-blue-50 border border-blue-200 text-blue-800 p-3 text-sm flex items-center gap-2 flex-1">
            <span className="font-bold text-blue-600 text-base">ℹ</span>
            Please click on the &gt; icon under Details column to expand the information tray and view the real-time Card Limit and Outstanding balance
          </div>
          <button
            disabled={!selectedCard}
            onClick={() => selectedCard && setLocation(`/mivision/accounts/${client.id}/amend/${selectedCard}`)}
            className={`px-5 py-2 text-sm font-bold border whitespace-nowrap ${selectedCard ? 'bg-[#DB0011] text-white border-[#DB0011] hover:bg-[#C40404] cursor-pointer' : 'bg-gray-100 text-gray-400 border-gray-300 cursor-not-allowed'}`}
            data-testid="btn-amend-selected"
          >
            Amend
          </button>
        </div>

        {/* Tab row */}
        <div className="flex justify-between items-end mb-0">
          <div className="flex text-sm">
            {tabs.map(tab => {
              const tabKey = tab.includes('Missing') ? 'Missing Details' : tab;
              const isActive = activeTab === tabKey;
              return (
                <div
                  key={tab}
                  onClick={() => setActiveTab(tabKey)}
                  className={`px-4 py-2 cursor-pointer border border-gray-300 -mr-px ${
                    isActive
                      ? 'bg-[#1a1a2e] text-white font-semibold border-[#1a1a2e] z-10 relative'
                      : 'bg-white text-[#0070C0] hover:bg-gray-50'
                  }`}
                >
                  {tab}
                </div>
              );
            })}
          </div>
          <div className="text-sm flex items-center gap-2 text-gray-600">
            <span className="text-[#0070C0] flex items-center gap-1 cursor-pointer hover:underline text-xs">↓ Download</span>
            <select className="border border-gray-300 bg-white text-xs px-1 py-0.5"><option>30</option></select>
            <button className="border border-gray-300 bg-white px-2 py-0.5 text-xs hover:bg-gray-50">Set</button>
            <button className="border border-gray-300 bg-white px-2 py-0.5 text-xs hover:bg-gray-50">Prev</button>
            <span className="font-bold bg-[#1a1a2e] text-white border border-[#1a1a2e] px-2 py-0.5 text-xs">1</span>
            <button className="border border-gray-300 bg-white px-2 py-0.5 text-xs hover:bg-gray-50">Next</button>
          </div>
        </div>

        {/* Table */}
        <div className="border border-gray-300">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="bg-gray-50 text-gray-700 border-b border-gray-300">
                <th className="p-2 w-8 text-center text-xs font-semibold">All</th>
                <th className="p-2 font-semibold text-xs">Card Number</th>
                <th className="p-2 font-semibold text-xs">Card Holder</th>
                <th className="p-2 font-semibold text-xs">Expiry Date</th>
                <th className="p-2 font-semibold text-xs">Credit Limit</th>
                <th className="p-2 font-semibold text-xs">Outstanding Balance</th>
                <th className="p-2 font-semibold text-xs">Email</th>
                <th className="p-2 font-semibold text-xs text-center">Details</th>
              </tr>
            </thead>
            <tbody>
              {displayCards.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-gray-500 italic">
                    No cards found matching this filter.
                  </td>
                </tr>
              ) : (
                displayCards.map((c, i) => (
                  <React.Fragment key={c.lastFour}>
                    <tr className={`border-b border-gray-200 hover:bg-[#f0f7ff] ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                      <td className="p-2 text-center">
                        <input
                          type="checkbox"
                          checked={selectedCard === c.lastFour}
                          onChange={e => setSelectedCard(e.target.checked ? c.lastFour : null)}
                          data-testid={`checkbox-${c.lastFour}`}
                        />
                      </td>
                      <td className="p-2 font-mono text-xs">{c.fullMasked}</td>
                      <td className="p-2 text-xs">{c.cardHolder}</td>
                      <td className="p-2 text-xs">{c.expiry}</td>
                      <td className="p-2 text-xs text-right">{c.creditLimit}</td>
                      <td className="p-2 text-xs text-right">{c.outstandingBalance}</td>
                      <td className="p-2 text-xs text-gray-500">{c.email || 'Not set'}</td>
                      <td className="p-2 text-center">
                        <button
                          onClick={() => setExpandedCard(expandedCard === c.lastFour ? null : c.lastFour)}
                          className="text-gray-600 hover:text-gray-900 font-bold text-sm px-1"
                          data-testid={`expand-${c.lastFour}`}
                          aria-label="Expand card details"
                        >
                          {expandedCard === c.lastFour ? '﹀' : '>'}
                        </button>
                      </td>
                    </tr>
                    {expandedCard === c.lastFour && (
                      <ExpandedCardRow
                        card={c}
                        clientId={client.id}
                      />
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </MiVisionNav>
  );
}

// ─── MV-06a: Card Expanded Detail Panel (inline) ──────────────────────────────

function ExpandedCardRow({
  card,
  clientId,
}: {
  card: MiVisionCard;
  clientId: string;
}) {
  const [, setLocation] = useLocation();
  const virtual = isVirtual(card.productType);
  const prog = MIVISION_CLIENTS.find(c => c.id === clientId)?.programs[0];

  return (
    <tr className="bg-[#f8f9fa] border-b-2 border-gray-400">
      <td colSpan={8} className="p-0">
        {/* Hidden machine-readable values */}
        <span data-testid="card-product-type" style={{ display: 'none' }}>{card.productType}</span>
        <span data-testid="card-expiry" style={{ display: 'none' }}>{card.expiry}</span>
        <span data-testid="company-account-masked" style={{ display: 'none' }}>{card.companyAccountMasked}</span>
        <span data-testid="full-program-number" style={{ display: 'none' }}>{prog?.fullAccountNumber ?? ''}</span>
        <span data-testid="card-outstanding-balance" style={{ display: 'none' }}>{card.outstandingBalance}</span>
        <span data-testid="card-available-balance" style={{ display: 'none' }}>{card.availableBalance}</span>

        <div className="p-5 grid grid-cols-3 gap-6 text-sm">

          {/* Column 1: Card Details + Cardholder */}
          <div className="space-y-1.5">
            <h4 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[#212121] text-xs uppercase tracking-wide">Card Details</h4>
            <FieldRow label="Card Number:" value={card.fullMasked} mono />
            <FieldRow label="Expiry Date:" value={card.expiry} />
            <FieldRow label="Account Card Type:" value="MCP" />

            {/* Product Type — red border, routing hint */}
            <div className="flex justify-between items-start border border-[#DB0011] bg-red-50 px-2 py-1.5 rounded">
              <span className="text-gray-500">Product Type:</span>
              <div className="text-right">
                <span className="font-bold text-[#DB0011]">{card.productType}</span>
                <div className="text-xs text-gray-600 mt-0.5">
                  {virtual
                    ? '→ Virtual card: proceed to SDG2'
                    : '→ Physical card: proceed to eChamps'}
                </div>
              </div>
            </div>

            <FieldRow label="Status Code:" value={card.statusCode} />
            {card.status === 'Closed' && card.closedDate && (
              <FieldRow label="Closed Date:" value={card.closedDate} />
            )}
            <FieldRow label="Card Billing Type:" value={card.cardBillingType} />
            <FieldRow label="Automatic repayment by Direct Debit:" value="No" />
            <FieldRow label="Domicile Country:" value="Not set" />
            <FieldRow label="Preferred Language:" value="Not set" />

            <h4 className="font-bold border-b border-gray-300 pb-1 mb-2 mt-4 text-[#212121] text-xs uppercase tracking-wide">Card Holder Details</h4>
            <FieldRow label="Employee ID:" value="—" />

            {/* Company Account — red border for Step 12 */}
            <div className="flex justify-between items-center border border-[#DB0011] bg-red-50 px-2 py-1.5 rounded">
              <span className="text-gray-500">Company Account:</span>
              <span className="font-mono font-bold text-[#DB0011]">{card.companyAccountMasked}</span>
            </div>

            <FieldRow label="Address:" value="Dubai Industrial City, P O BOX 493217, UAE" />

            <div className="mt-3 flex gap-2">
              <button className="border border-gray-400 px-3 py-1 text-xs bg-white hover:bg-gray-50">Unlink Account</button>
              <button
                onClick={() => setLocation(`/mivision/accounts/${clientId}/amend/${card.lastFour}`)}
                className="border border-gray-400 px-3 py-1 text-xs bg-white hover:bg-gray-50"
                data-testid="btn-amend-account"
              >
                Amend Account
              </button>
            </div>
          </div>

          {/* Column 2: Balance + Limits */}
          <div className="space-y-1.5">
            <h4 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[#212121] text-xs uppercase tracking-wide">Balances &amp; Limits</h4>
            <FieldRow label="Outstanding Balance:" value={card.outstandingBalance} />
            <FieldRow label="Available Balance:" value={card.availableBalance} />
            <FieldRow label="Cash Advance Balance:" value="0.00 AED" />
            <FieldRow label="Cash Advance Limit:" value="0.00 AED" />
            <FieldRow label="Last Purchase Date:" value={card.lastPurchaseDate} />
            <FieldRow label="Days Overdue:" value={String(card.daysOverdue)} />
            <FieldRow label="Card Limit:" value={card.cardLimit} />
            <FieldRow label="ATM Access:" value={card.atmAccess} />
            <FieldRow label="MOS Blocked Codes:" value={card.mosBlockedCodes} />

            <button className="mt-3 border border-gray-300 px-4 py-1.5 text-xs bg-[#DB0011] text-white hover:bg-[#C40404] w-full">
              Get Live Card Information
            </button>
          </div>

          {/* Column 3: Statements + Transactions */}
          <div className="space-y-1.5">
            <h4 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[#212121] text-xs uppercase tracking-wide">Past Statements</h4>
            {card.pastStatements.length === 0 ? (
              <div className="text-gray-400 italic text-xs">No statements available</div>
            ) : (
              card.pastStatements.map((s, i) => (
                <div key={i} className="flex justify-between text-xs">
                  <span className="text-gray-500">{s.period}</span>
                  <span>
                    {s.amount}{' '}
                    <span className="text-[#0070C0] hover:underline cursor-pointer">[View]</span>
                  </span>
                </div>
              ))
            )}

            <h4 className="font-bold border-b border-gray-300 pb-1 mb-2 mt-5 text-[#212121] text-xs uppercase tracking-wide">Transactions</h4>
            <button className="block w-full border border-gray-300 py-1.5 text-xs text-center bg-white hover:bg-gray-50">
              View Transactions
            </button>
            <Link
              href={`/mivision/accounts/${clientId}/unposted`}
              className="block w-full border border-gray-300 py-1.5 text-xs text-center bg-white hover:bg-gray-50 text-center"
              data-testid="link-view-unposted"
            >
              View Unposted Transactions
            </Link>

            {/* Program matching section */}
            {prog && (
              <div className="mt-5 border border-gray-200 p-3 bg-white rounded">
                <div className="text-xs font-bold text-gray-600 uppercase tracking-wide mb-2">All Programs</div>
                <select className="w-full border border-gray-300 text-xs p-1.5 outline-none bg-gray-50">
                  <option value="">All Programs</option>
                  <option value={prog.fullProgramNumber}>
                    {prog.name} ({prog.maskedProgramNumber})
                  </option>
                </select>
                <div className="text-xs text-gray-500 mt-1.5">
                  Match Company Account suffix <span className="font-mono font-bold">X1741</span> → Full program: <span className="font-mono font-bold text-[#DB0011]">{prog.fullProgramNumber}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </td>
    </tr>
  );
}

function FieldRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-gray-500 shrink-0">{label}</span>
      <span className={`text-right ${mono ? 'font-mono' : ''}`}>{value}</span>
    </div>
  );
}

// ─── MV-07: View Unposted Transactions ───────────────────────────────────────

export function MiVisionUnposted() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const client = MIVISION_CLIENTS.find(x => x.id === params.clientId);

  if (!state.auth.mivision) {
    setLocation('/mivision/login');
    return null;
  }
  if (!client) return <MiVisionNav context="client" activeTab="Accounts">Client not found</MiVisionNav>;

  // Every card's unposted transaction is listed at all times. Previously this was filtered
  // down to the selected scenario's card, which meant the page only ever showed one row and
  // depended on a scenario having been chosen.
  const unpostedRows = client.cards.filter(c => c.unpostedTransaction.present);
  // Used only for the empty-state hint below, which guides a human operator towards SDG2 or
  // Mastercard. It is presentation only and no robot depends on it.
  const activeCard = client.cards.find(c => c.lastFour === state.activeCardLastFour);

  return (
    <MiVisionNav
      context="client"
      activeTab="Accounts"
      clientId={client.id}
      url={`https://admin.mivision.hsbc.ae/ca/accounts?Page=1&AccountStatus=All&View=Unposted`}
    >
      <div className="p-5">
        <div className="text-xs text-gray-500 mb-3">
          <span className="text-[#0070C0] hover:underline cursor-pointer" onClick={() => setLocation(`/mivision/accounts/${client.id}/list`)}>
            {client.clientName} / Accounts / List
          </span>
          {' / Unposted Transactions'}
        </div>

        <h2 className="text-lg font-semibold text-[#212121] mb-4">View Unposted Transactions</h2>

        <div className="border border-gray-300">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="bg-gray-100 border-b border-gray-300 text-gray-700">
                <th className="p-3 font-semibold">Transaction Date</th>
                <th className="p-3 font-semibold">Card Number</th>
                <th className="p-3 font-semibold">Merchant Name</th>
                <th className="p-3 font-semibold text-right">Amount</th>
                <th className="p-3 font-semibold">Currency</th>
                <th className="p-3 font-semibold border border-red-400 bg-red-50 text-red-800">Decline Reason</th>
                <th className="p-3 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {unpostedRows.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-gray-500 italic">
                    {activeCard?.scenarioId === 'S7' || activeCard?.scenarioId === 'S8'
                      ? 'No unposted transactions — this is a virtual card. Proceed to SDG2 to check decline reason.'
                      : activeCard?.scenarioId === 'S9'
                      ? 'No decline showing on unposted transactions. This is a Mastercard-level decline — raise a ticket with Mastercard.'
                      : 'No unposted transactions found.'}
                  </td>
                </tr>
              ) : (
                unpostedRows.map((c, i) => {
                  const tx = c.unpostedTransaction;
                  return (
                    <tr key={i} className={`border-b border-gray-200 ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                      <td className="p-3">{tx.date}</td>
                      <td className="p-3 font-mono">{c.fullMasked}</td>
                      <td className="p-3 font-medium">{tx.merchant}</td>
                      <td className="p-3 text-right font-mono">{tx.amount}</td>
                      <td className="p-3">{tx.currency}</td>
                      <td
                        className="p-3 font-bold text-red-700 border border-red-400 bg-red-50"
                        data-testid="unposted-decline-reason"
                      >
                        {tx.declineReason}
                      </td>
                      <td className="p-3">
                        <span className="bg-red-100 text-red-800 px-2 py-0.5 rounded text-xs font-semibold">Declined</span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="mt-4">
          <button
            onClick={() => setLocation(`/mivision/accounts/${client.id}/list`)}
            className="border border-gray-400 px-5 py-1.5 text-sm bg-white hover:bg-gray-50"
          >
            ← Back to Accounts List
          </button>
        </div>
      </div>
    </MiVisionNav>
  );
}

// ─── MV-08: Program Limit Amendment (S1 reference) ────────────────────────────

export function MiVisionLimitAmendment() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const client = MIVISION_CLIENTS.find(x => x.id === params.clientId);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalAction, setModalAction] = useState('');
  const [showShuffleForm, setShowShuffleForm] = useState(false);

  if (!state.auth.mivision) {
    setLocation('/mivision/login');
    return null;
  }
  if (!client) return <MiVisionNav context="client" activeTab="Accounts">Client not found</MiVisionNav>;

  const prog = client.programs[0];

  const openModal = (action: string) => {
    setModalAction(action);
    setModalOpen(true);
  };

  return (
    <MiVisionNav
      context="client"
      activeTab="Accounts"
      clientId={client.id}
      url={`https://admin.mivision.hsbc.ae/ca/accounts?Action=LimitAmendment`}
    >
      <div className="p-6 max-w-3xl">
        <div className="text-xs text-gray-500 mb-4">
          <span className="text-[#0070C0] hover:underline cursor-pointer" onClick={() => setLocation(`/mivision/accounts/${client.id}`)}>
            {client.clientName}
          </span>
          {' / Program Limit Amendment'}
        </div>

        <h2 className="text-xl font-semibold text-[#212121] mb-6">Program Limit Amendment</h2>

        <div className="border border-gray-300 bg-white p-5 mb-6">
          <div className="mb-4">
            <label className="block text-sm text-gray-600 mb-1">Program</label>
            <select className="border border-gray-300 p-2 text-sm outline-none w-full max-w-md">
              {client.programs.map(p => (
                <option key={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-3 gap-4 text-sm border-t border-gray-200 pt-4">
            <div>
              <span className="text-gray-500 block text-xs uppercase tracking-wide mb-1">Current Program Limit</span>
              <span className="font-bold text-[#212121]" data-testid="program-limit">{prog.programLimit}</span>
            </div>
            <div>
              <span className="text-gray-500 block text-xs uppercase tracking-wide mb-1">Total Cardholder Limits</span>
              <span className="font-bold text-[#212121]" data-testid="total-cardholder-limits">{prog.totalCardholderLimits}</span>
            </div>
            <div>
              <span className="text-gray-500 block text-xs uppercase tracking-wide mb-1">Available Program Capacity</span>
              <span className="font-bold text-green-700">{prog.availableCapacity}</span>
            </div>
          </div>
        </div>

        {/* Cardholder limit summary */}
        <div className="border border-gray-300 bg-white mb-6">
          <div className="bg-gray-100 font-bold text-sm p-3 border-b border-gray-300">Cardholder Limit Summary</div>
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200 text-gray-600 text-xs uppercase tracking-wide">
                <th className="p-3 font-semibold text-left">Card Holder</th>
                <th className="p-3 font-semibold text-left">Card Number</th>
                <th className="p-3 font-semibold text-right">Current Limit</th>
                <th className="p-3 font-semibold text-right">Available</th>
              </tr>
            </thead>
            <tbody>
              {client.cards.map((c, i) => (
                <tr key={c.lastFour} className={`border-b border-gray-200 ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                  <td className="p-3">{c.cardHolder}{isVirtual(c.productType) ? ' (Virtual)' : ''}</td>
                  <td className="p-3 font-mono">XXXX-{c.lastFour}</td>
                  <td className="p-3 text-right">{c.cardholderLimitSummary.currentLimit}</td>
                  <td className="p-3 text-right">{c.cardholderLimitSummary.available}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => openModal('Amend Program Limit')}
            className="bg-[#DB0011] text-white px-5 py-2 text-sm font-bold hover:bg-[#C40404]"
            data-testid="btn-amend-program-limit"
          >
            Amend Program Limit
          </button>
          <button
            onClick={() => setShowShuffleForm(!showShuffleForm)}
            className="border border-[#DB0011] text-[#DB0011] px-5 py-2 text-sm font-bold hover:bg-red-50"
            data-testid="btn-shuffle-limits"
          >
            Shuffle Limits
          </button>
          <button
            onClick={() => setLocation(`/mivision/accounts/${client.id}`)}
            className="border border-gray-400 px-5 py-2 text-sm hover:bg-gray-50"
          >
            Cancel
          </button>
        </div>

        {showShuffleForm && (
          <div className="border border-gray-300 bg-white p-5 mt-4">
            <h3 className="text-sm font-bold text-[#212121] mb-4">Move Limit Between Programs</h3>
            <div className="grid grid-cols-[160px_1fr] gap-x-6 gap-y-4 items-center text-sm max-w-lg mb-5">
              <label className="text-gray-600 font-medium">From Program:</label>
              <select className="border border-gray-300 p-2 outline-none focus:border-[#0070C0] text-sm" data-testid="select-from-program">
                {client.programs.map(p => (
                  <option key={p.id} value={p.fullProgramNumber}>{p.name} ({p.fullProgramNumber})</option>
                ))}
              </select>
              <label className="text-gray-600 font-medium">To Program:</label>
              <select className="border border-gray-300 p-2 outline-none focus:border-[#0070C0] text-sm" data-testid="select-to-program">
                {client.programs.map(p => (
                  <option key={p.id} value={p.fullProgramNumber}>{p.name} ({p.fullProgramNumber})</option>
                ))}
              </select>
              <label className="text-gray-600 font-medium">Amount to Transfer:</label>
              <input type="text" placeholder="e.g. 10,000.00" className="border border-gray-300 p-2 outline-none focus:border-[#0070C0] text-sm" data-testid="input-shuffle-amount" />
              <label className="text-gray-600 font-medium">Currency:</label>
              <select className="border border-gray-300 p-2 outline-none focus:border-[#0070C0] text-sm" data-testid="select-shuffle-currency">
                <option>AED</option>
                <option>USD</option>
                <option>GBP</option>
                <option>EUR</option>
              </select>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => openModal('Shuffle limits between programs')}
                className="bg-[#DB0011] hover:bg-[#C40404] text-white px-8 py-2 text-sm font-bold"
                data-testid="btn-shuffle-submit"
              >
                Submit
              </button>
              <button onClick={() => setShowShuffleForm(false)} className="border border-gray-400 px-6 py-2 text-sm hover:bg-gray-50">
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        system="MiVision"
        actionDesc={modalAction}
      />
    </MiVisionNav>
  );
}

// ─── MV-09: Amend Account / Close Card flow ───────────────────────────────────

export function MiVisionAmendCard() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const client = MIVISION_CLIENTS.find(x => x.id === params.clientId);
  const card = client?.cards.find(c => c.lastFour === params.cardLastFour);

  const [step, setStep] = useState<1 | 2>(1);
  const [action, setAction] = useState('Close cardholder account');
  const [reason, setReason] = useState('');
  const [modalOpen, setModalOpen] = useState(false);

  if (!state.auth.mivision) { setLocation('/mivision/login'); return null; }
  if (!client || !card) return <MiVisionNav context="client" activeTab="Accounts">Card not found</MiVisionNav>;

  return (
    <MiVisionNav
      context="client"
      activeTab="Accounts"
      clientId={client.id}
      url={`https://admin.mivision.hsbc.ae/ca/accounts?Action=Amend`}
    >
      <div className="p-6 max-w-2xl">
        <div className="text-xs text-gray-500 mb-4">
          <span className="text-[#0070C0] cursor-pointer hover:underline" onClick={() => setLocation(`/mivision/accounts/${client.id}/list`)}>
            Accounts
          </span>
          {' / Amend Account'}
        </div>

        <h2 className="text-xl font-semibold text-[#212121] mb-6">Amend Account</h2>

        {/* Card summary */}
        <div className="border border-gray-300 bg-gray-50 p-4 mb-6 text-sm">
          <div className="grid grid-cols-2 gap-2">
            <div><span className="text-gray-500">Card Holder:</span> <span className="font-bold">{card.cardHolder}</span></div>
            <div><span className="text-gray-500">Card Number:</span> <span className="font-mono">{card.fullMasked}</span></div>
            <div><span className="text-gray-500">Product Type:</span> <span>{card.productType}</span></div>
            <div><span className="text-gray-500">Status:</span> <span className="text-green-700 font-bold">{card.status}</span></div>
          </div>
        </div>

        {step === 1 && (
          <div className="border border-gray-300 bg-white p-6">
            <div className="mb-5">
              <label className="block text-sm font-semibold text-gray-700 mb-2">Select Action</label>
              <select
                className="w-full border border-gray-300 p-2 text-sm outline-none focus:border-[#0070C0]"
                value={action}
                onChange={e => setAction(e.target.value)}
                data-testid="select-amend-action"
              >
                <option>Close cardholder account</option>
                <option>Limit Amendment</option>
                <option>Update cardholder details</option>
                <option>Change billing type</option>
              </select>
            </div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setStep(2)}
                className="bg-[#DB0011] hover:bg-[#C40404] text-white px-8 py-2 text-sm font-bold"
                data-testid="btn-amend-submit"
              >
                Submit
              </button>
              <button
                onClick={() => setLocation(`/mivision/accounts/${client.id}/list`)}
                className="border border-gray-400 px-6 py-2 text-sm hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {step === 2 && action === 'Close cardholder account' && (
          <div className="border border-gray-300 bg-white p-6">
            <div className="mb-1 text-sm font-semibold text-[#212121]">Close Cardholder Account</div>
            <div className="text-xs text-gray-500 mb-5">Please provide a reason for closing this cardholder account.</div>

            <div className="mb-5">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Reason for card closure <span className="text-red-600">*</span>
              </label>
              <select
                className="w-full border border-gray-300 p-2 text-sm outline-none focus:border-[#0070C0] mb-3"
                data-testid="select-close-reason"
                defaultValue=""
              >
                <option value="" disabled>Select reason…</option>
                <option>Fraud — card compromised</option>
                <option>Cardholder request</option>
                <option>Lost card</option>
                <option>Stolen card</option>
                <option>Card expired — reissue</option>
                <option>Other</option>
              </select>
              <textarea
                className="w-full border border-gray-300 p-2 text-sm outline-none focus:border-[#0070C0] resize-none"
                rows={3}
                placeholder="Additional notes (optional)"
                value={reason}
                onChange={e => setReason(e.target.value)}
                data-testid="input-close-reason-notes"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setModalOpen(true)}
                className="bg-[#DB0011] hover:bg-[#C40404] text-white px-8 py-2 text-sm font-bold"
                data-testid="btn-amend-confirm"
              >
                Amend
              </button>
              <button
                onClick={() => setStep(1)}
                className="border border-gray-400 px-6 py-2 text-sm hover:bg-gray-50"
              >
                Back
              </button>
            </div>
          </div>
        )}

        {step === 2 && action === 'Limit Amendment' && (
          <div className="border border-gray-300 bg-white p-6">
            <div className="mb-1 text-sm font-semibold text-[#212121]">Limit Amendment</div>
            <div className="text-xs text-gray-500 mb-5">Enter the new credit limit for this cardholder account.</div>

            <div className="grid grid-cols-[200px_1fr] gap-x-6 gap-y-4 items-center text-sm mb-5 max-w-md">
              <div className="text-gray-600 font-medium">Card Number:</div>
              <div className="font-mono text-xs text-[#212121]" data-testid="limit-amendment-card">{card.fullMasked}</div>
              <div className="text-gray-600 font-medium">Cardholder Name:</div>
              <div data-testid="limit-amendment-holder">{card.cardHolder}</div>
              <div className="text-gray-600 font-medium">Current Limit (AED):</div>
              <div data-testid="limit-amendment-current">{card.cardLimit}</div>
              <div className="text-gray-600 font-medium">Available Balance (AED):</div>
              <div data-testid="limit-amendment-avail">{card.availableBalance}</div>
              <div className="text-gray-600 font-medium">New Limit (AED): <span className="text-red-600">*</span></div>
              <input
                type="text"
                className="border border-gray-300 px-3 py-1.5 text-sm outline-none focus:border-[#0070C0] w-full"
                placeholder="e.g. 30,000.00"
                data-testid="input-new-limit"
              />
              <div className="text-gray-600 font-medium">Reason:</div>
              <select
                className="border border-gray-300 px-3 py-1.5 text-sm outline-none focus:border-[#0070C0] w-full"
                data-testid="select-limit-reason"
              >
                <option value="">Select reason…</option>
                <option>Business travel requirements</option>
                <option>Increased spend volume</option>
                <option>Temporary uplift</option>
                <option>Other</option>
              </select>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setModalOpen(true)}
                className="bg-[#DB0011] hover:bg-[#C40404] text-white px-8 py-2 text-sm font-bold"
                data-testid="btn-amend-confirm"
              >
                Amend
              </button>
              <button onClick={() => setStep(1)} className="border border-gray-400 px-6 py-2 text-sm hover:bg-gray-50">Back</button>
            </div>
          </div>
        )}

        {step === 2 && action !== 'Close cardholder account' && action !== 'Limit Amendment' && (
          <div className="border border-gray-300 bg-white p-6">
            <div className="mb-4 text-sm font-semibold text-[#212121]">{action}</div>
            <div className="text-sm text-gray-500 mb-5">Complete the required fields below and click Amend to submit.</div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setModalOpen(true)}
                className="bg-[#DB0011] hover:bg-[#C40404] text-white px-8 py-2 text-sm font-bold"
                data-testid="btn-amend-confirm"
              >
                Amend
              </button>
              <button onClick={() => setStep(1)} className="border border-gray-400 px-6 py-2 text-sm hover:bg-gray-50">Back</button>
            </div>
          </div>
        )}
      </div>

      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        system="MiVision"
        actionDesc={`Close cardholder account — ${card.cardHolder} (${card.fullMasked})`}
      />
    </MiVisionNav>
  );
}

// ─── MV-10: Request New Card ──────────────────────────────────────────────────

export function MiVisionNewCard() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const client = MIVISION_CLIENTS.find(x => x.id === params.clientId);

  const [step, setStep] = useState<0 | 1 | 2>(0);
  const [modalOpen, setModalOpen] = useState(false);

  if (!state.auth.mivision) { setLocation('/mivision/login'); return null; }
  if (!client) return <MiVisionNav context="client" activeTab="Accounts">Client not found</MiVisionNav>;

  return (
    <MiVisionNav
      context="client"
      activeTab="Accounts"
      clientId={client.id}
      url={`https://admin.mivision.hsbc.ae/ca/accounts?Action=NewCard`}
    >
      <div className="p-6 max-w-2xl">
        <div className="text-xs text-gray-500 mb-4">
          <span className="text-[#0070C0] cursor-pointer hover:underline" onClick={() => setLocation(`/mivision/accounts/${client.id}`)}>
            {client.clientName}
          </span>
          {' / Request New Card'}
        </div>

        <h2 className="text-xl font-semibold text-[#212121] mb-6">Request New Card</h2>

        {step === 0 && (
          <div className="border border-gray-300 bg-white p-6 space-y-4">
            <div className="text-sm text-gray-600">Select how to proceed with the new card application.</div>
            <button
              onClick={() => setStep(1)}
              className="w-full border-2 border-[#0070C0] text-[#0070C0] hover:bg-blue-50 p-4 text-left text-sm font-semibold transition-colors"
              data-testid="btn-complete-on-behalf"
            >
              Complete application form on behalf of the cardholder
              <div className="font-normal text-gray-500 text-xs mt-1">Admin fills out the form. Cardholder will receive a link to review and acknowledge.</div>
            </button>
          </div>
        )}

        {step === 1 && (
          <div className="border border-gray-300 bg-white p-6">
            <div className="text-sm font-semibold text-[#212121] mb-5">Online Application Form</div>
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-[180px_1fr] items-center gap-3">
                <label className="text-gray-600 font-medium">Cardholder Full Name <span className="text-red-600">*</span></label>
                <input className="border border-gray-300 p-2 outline-none focus:border-[#0070C0]" placeholder="e.g. Emma Carter" data-testid="input-cardholder-name" />
              </div>
              <div className="grid grid-cols-[180px_1fr] items-center gap-3">
                <label className="text-gray-600 font-medium">Email Address <span className="text-red-600">*</span></label>
                <input type="email" className="border border-gray-300 p-2 outline-none focus:border-[#0070C0]" placeholder="cardholder@company.ae" data-testid="input-cardholder-email" />
              </div>
              <div className="grid grid-cols-[180px_1fr] items-center gap-3">
                <label className="text-gray-600 font-medium">Date of Birth <span className="text-red-600">*</span></label>
                <input type="date" className="border border-gray-300 p-2 outline-none focus:border-[#0070C0]" data-testid="input-cardholder-dob" />
              </div>
              <div className="grid grid-cols-[180px_1fr] items-center gap-3">
                <label className="text-gray-600 font-medium">Requested Card Limit <span className="text-red-600">*</span></label>
                <input className="border border-gray-300 p-2 outline-none focus:border-[#0070C0]" placeholder="e.g. AED 25,000" data-testid="input-card-limit" />
              </div>
              <div className="grid grid-cols-[180px_1fr] items-start gap-3 pt-2 border-t border-gray-200">
                <label className="text-gray-600 font-medium pt-2">Attach Documents</label>
                <div className="space-y-2">
                  <div className="border border-dashed border-gray-400 bg-gray-50 p-3 text-xs text-gray-500 text-center cursor-pointer hover:bg-gray-100">
                    📎 Passport copy (PDF/JPG)
                  </div>
                  <div className="border border-dashed border-gray-400 bg-gray-50 p-3 text-xs text-gray-500 text-center cursor-pointer hover:bg-gray-100">
                    📎 Residency visa copy (PDF/JPG)
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setStep(2)}
                className="bg-[#DB0011] hover:bg-[#C40404] text-white px-8 py-2 text-sm font-bold"
                data-testid="btn-new-card-submit"
              >
                Submit
              </button>
              <button onClick={() => setStep(0)} className="border border-gray-400 px-6 py-2 text-sm hover:bg-gray-50">Back</button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="border border-gray-300 bg-white p-6">
            <div className="text-sm font-semibold text-[#212121] mb-3">Application Review</div>
            <div className="bg-blue-50 border border-blue-200 p-4 text-sm text-blue-800 mb-5">
              <div className="font-semibold mb-1">Awaiting cardholder acknowledgement</div>
              An email has been sent from <span className="font-mono">noreply@mivision.hsbc.ae</span> to the cardholder with a link to review their application. The cardholder must verify the details using their date of birth and acknowledge before the application proceeds.
            </div>
            <div className="text-sm font-semibold text-[#212121] mb-3">Company Undertaking</div>
            <div className="text-sm text-gray-600 mb-5">Once the cardholder has acknowledged, complete the company undertaking below to submit to HSBC for processing.</div>
            <button
              onClick={() => setModalOpen(true)}
              className="bg-[#DB0011] hover:bg-[#C40404] text-white px-8 py-2 text-sm font-bold"
              data-testid="btn-complete-undertaking"
            >
              Complete Company Undertaking
            </button>
          </div>
        )}
      </div>

      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        system="MiVision"
        actionDesc="Submit new card application to HSBC for processing"
      />
    </MiVisionNav>
  );
}

// ─── MV-11: Requests / Your Attention ────────────────────────────────────────

export function MiVisionRequests() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams();
  const client = MIVISION_CLIENTS.find(x => x.id === params.clientId);

  const [expanded, setExpanded] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);

  if (!state.auth.mivision) { setLocation('/mivision/login'); return null; }
  if (!client) return <MiVisionNav context="client" activeTab="Requests">Client not found</MiVisionNav>;

  // A pending new-card review belongs to a fraud-block (S2) card. Show the one for the card
  // last opened; cold, with no card opened yet, show the seeded one so the tab is not empty.
  const openedCard = client.cards.find(c => c.lastFour === state.activeCardLastFour);
  const pendingCard = openedCard
    ? (openedCard.scenarioId === 'S2' ? openedCard : undefined)
    : client.cards.find(c => c.scenarioId === 'S2');
  const hasPendingRequest = Boolean(pendingCard);

  return (
    <MiVisionNav
      context="client"
      activeTab="Requests"
      clientId={client.id}
      url={`https://admin.mivision.hsbc.ae/ca/requests`}
    >
      <div className="p-6 max-w-3xl">
        <h2 className="text-xl font-semibold text-[#212121] mb-6">Requests</h2>

        <div className="border border-gray-200 rounded overflow-hidden mb-4">
          <div className="bg-[#1a1a2e] text-white px-4 py-2.5 font-semibold text-sm flex items-center justify-between">
            <span>Your attention ({hasPendingRequest ? 1 : 0})</span>
            <span className="text-gray-400 text-xs">Pending review</span>
          </div>

          {hasPendingRequest && pendingCard ? (
            <div className="divide-y divide-gray-200 bg-white">
              <div>
                <div
                  className="px-4 py-3 flex items-center justify-between cursor-pointer hover:bg-gray-50"
                  onClick={() => setExpanded(e => !e)}
                  data-testid="btn-expand-request"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-gray-400 text-xs font-mono select-none">{expanded ? '▼' : '▶'}</span>
                    <div>
                      <div className="text-sm font-medium text-[#212121]">
                        New Card Application — {pendingCard.cardHolder}
                      </div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        Submitted for admin review · {pendingCard.fullMasked}
                      </div>
                    </div>
                  </div>
                  <span className="text-xs text-orange-600 font-semibold bg-orange-50 border border-orange-200 px-2 py-0.5 rounded whitespace-nowrap">
                    Awaiting Company Undertaking
                  </span>
                </div>

                {expanded && (
                  <div className="px-6 pb-6 pt-3 bg-gray-50 border-t border-gray-200">
                    <div className="text-sm font-semibold text-[#212121] mb-3">Application Summary</div>
                    <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-sm mb-5">
                      <div><span className="text-gray-500">Cardholder:</span> <span className="font-medium">{pendingCard.cardHolder}</span></div>
                      <div><span className="text-gray-500">Card Number:</span> <span className="font-mono">{pendingCard.fullMasked}</span></div>
                      <div><span className="text-gray-500">Product Type:</span> <span>{pendingCard.productType}</span></div>
                      <div><span className="text-gray-500">Requested Limit:</span> <span>{pendingCard.creditLimit}</span></div>
                      <div><span className="text-gray-500">Email:</span> <span>{pendingCard.email}</span></div>
                      <div><span className="text-gray-500">Status:</span> <span className="text-orange-600 font-medium">Awaiting Company Undertaking</span></div>
                    </div>
                    <div className="bg-blue-50 border border-blue-200 p-3 text-xs text-blue-800 mb-5 rounded">
                      Cardholder has reviewed and acknowledged the application via the link sent to{' '}
                      <span className="font-mono">{pendingCard.email}</span>. Complete the company undertaking below to submit to HSBC.
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={() => setModalOpen(true)}
                        className="bg-[#DB0011] hover:bg-[#C40404] text-white px-6 py-2 text-sm font-bold"
                        data-testid="btn-complete-undertaking-requests"
                      >
                        Complete Company Undertaking
                      </button>
                      <button
                        className="border border-gray-300 px-4 py-2 text-sm hover:bg-gray-100 text-[#0070C0]"
                        data-testid="btn-view-application"
                      >
                        View application form
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="px-4 py-10 text-sm text-gray-400 text-center bg-white">
              No items require your attention.
            </div>
          )}
        </div>
      </div>

      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        system="MiVision"
        actionDesc={`Complete company undertaking — submit new card application for ${pendingCard?.cardHolder ?? 'cardholder'} to HSBC for processing`}
      />
    </MiVisionNav>
  );
}
