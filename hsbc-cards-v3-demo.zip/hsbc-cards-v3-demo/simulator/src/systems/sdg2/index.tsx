import React, { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { useSim } from '../../context/SimContext';
import { BrowserChrome } from '../../shared/BrowserChrome';
import { SimHelper } from '../../shared/SimHelper';
import { ApprovalGateModal } from '../../shared/ApprovalGateModal';
import { SDG2_REPORTS, SDG2_PURCHASE_REQUESTS } from '../../data/seed';

// ─── Nav ──────────────────────────────────────────────────────────────────────

function Sdg2Nav({ children, active }: { children: React.ReactNode; active?: 'reports' | 'purchase-requests' | 'other' }) {
  const { state } = useSim();
  const [, setLocation] = useLocation();

  return (
    <BrowserChrome url="https://smartdata.mastercard.com/incontrol">
      <div className="bg-white border-b border-gray-200">
        <div className="px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center border-2 border-white shadow-sm" />
            <div className="font-light text-xl tracking-tight text-[#1a1a2e]">
              Smart Data <span className="font-semibold border-l border-gray-300 ml-2 pl-2 text-indigo-900">InControl</span>
            </div>
          </div>
          {state.auth.sdg2 && (
            <div className="flex items-center gap-6 text-sm text-gray-600">
              <span className="hover:text-indigo-600 cursor-pointer">Support</span>
              <span className="hover:text-indigo-600 cursor-pointer">Preferences</span>
              <button onClick={() => setLocation('/sdg2/login')} className="font-semibold text-indigo-900">Log Out</button>
            </div>
          )}
        </div>
        {state.auth.sdg2 && (
          <div className="px-6 flex gap-6 text-sm border-t border-gray-100 bg-gray-50">
            <div className="py-3 text-gray-500 hover:text-indigo-900 cursor-pointer font-medium border-b-2 border-transparent hover:border-gray-300">Dashboard</div>
            <div className="py-3 text-gray-500 hover:text-indigo-900 cursor-pointer font-medium border-b-2 border-transparent hover:border-gray-300">Accounts</div>
            <div className="py-3 text-gray-500 hover:text-indigo-900 cursor-pointer font-medium border-b-2 border-transparent hover:border-gray-300">Virtual Cards</div>
            <div
              onClick={() => setLocation('/sdg2/reports/payment-control')}
              className={`py-3 cursor-pointer font-medium border-b-2 transition-colors ${active === 'reports' ? 'text-indigo-900 border-indigo-900 font-bold' : 'text-gray-500 border-transparent hover:text-indigo-900 hover:border-gray-300'}`}
            >
              Reports
            </div>
            <div
              onClick={() => setLocation('/sdg2/purchase-requests')}
              className={`py-3 cursor-pointer font-medium border-b-2 transition-colors ${active === 'purchase-requests' ? 'text-indigo-900 border-indigo-900 font-bold' : 'text-gray-500 border-transparent hover:text-indigo-900 hover:border-gray-300'}`}
            >
              Purchase Requests
            </div>
          </div>
        )}
      </div>
      <div className="bg-gray-50 min-h-[600px] p-8">
        {children}
      </div>
    </BrowserChrome>
  );
}

// ─── Login ────────────────────────────────────────────────────────────────────

export function Sdg2Login() {
  const [, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation("/sdg2/login/otp");
  };

  return (
    <Sdg2Nav>
      <div className="max-w-md mx-auto mt-16 bg-white border border-gray-200 rounded-lg shadow-sm p-8">
        <h2 className="text-2xl font-light text-gray-800 mb-8 text-center">Sign In</h2>
        <form onSubmit={handleLogin} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
            <input className="w-full border border-gray-300 rounded p-2.5 outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all" required data-testid="input-sdg2-username" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input type="password" className="w-full border border-gray-300 rounded p-2.5 outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all" required data-testid="input-sdg2-password" />
          </div>
          <button type="submit" className="w-full bg-indigo-900 text-white rounded py-3 font-semibold hover:bg-indigo-800 transition-colors mt-4 shadow-sm" data-testid="btn-sdg2-signin">
            Log In
          </button>
        </form>
      </div>
    </Sdg2Nav>
  );
}

// ─── OTP ──────────────────────────────────────────────────────────────────────

export function Sdg2Otp() {
  const { state, dispatch } = useSim();
  const [, setLocation] = useLocation();
  const [val, setVal] = useState("");
  const [timeLeft, setTimeLeft] = useState(299);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => prev > 0 ? prev - 1 : 0);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const mins = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;
  const isLocked = state.mfa.sdg2.lockedUntil && state.mfa.sdg2.lockedUntil > Date.now();
  const lockedSecs = isLocked ? Math.ceil((state.mfa.sdg2.lockedUntil! - Date.now()) / 1000) : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch.SDG2_OTP_ATTEMPT(val);
  };

  useEffect(() => {
    if (state.mfa.sdg2.passed) {
      dispatch.LOG_ACTION('sdg2', 'mfa_passed', null);
      setLocation('/sdg2/reports/payment-control');
    }
  }, [state.mfa.sdg2.passed, setLocation, dispatch]);

  return (
    <Sdg2Nav>
      <span data-testid="sdg2-otp-value" style={{ display: 'none' }}>{state.mfa.sdg2.otp}</span>
      <SimHelper>SDG2 OTP for this session: {state.mfa.sdg2.otp}</SimHelper>

      <div className="max-w-md mx-auto mt-16 bg-white border border-gray-200 rounded-lg shadow-sm p-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-2">One-Time Password Verification</h2>
        <p className="text-gray-600 text-sm mb-4 leading-relaxed">
          A verification code has been sent to your registered mobile number ending in ••••7823.
        </p>

        {/* Demo OTP display */}
        <div className="mb-6 bg-amber-50 border-2 border-amber-400 rounded-lg p-4 text-center">
          <div className="text-xs font-bold text-amber-700 uppercase tracking-wider mb-1">⚡ Demo Mode — Your OTP Code</div>
          <div className="font-mono text-3xl font-bold tracking-[0.35em] text-amber-900" data-testid="sdg2-otp-display">{state.mfa.sdg2.otp}</div>
        </div>

        {isLocked ? (
          <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded text-sm font-medium mb-6">
            ⚠ Too many incorrect attempts. Please wait {lockedSecs} seconds before trying again.
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {state.mfa.sdg2.attemptsRemaining < 3 && !isLocked && (
              <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 p-3 rounded text-sm">
                ⚠ Incorrect code. Please try again or request a new code. ({state.mfa.sdg2.attemptsRemaining} attempts remaining)
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Enter OTP</label>
              <input
                value={val}
                onChange={e => setVal(e.target.value)}
                className="w-full border border-gray-300 rounded p-3 text-center tracking-[0.5em] text-lg font-mono outline-none focus:ring-2 focus:ring-indigo-500"
                maxLength={6}
                required
                data-testid="input-sdg2-otp"
              />
            </div>

            <div className="flex gap-3">
              <button type="submit" className="flex-1 bg-indigo-900 text-white rounded py-2.5 font-semibold hover:bg-indigo-800 shadow-sm" data-testid="btn-verify-otp">
                Verify
              </button>
              <button type="button" onClick={() => dispatch.RESET_MFA()} className="flex-1 border border-gray-300 text-gray-700 rounded py-2.5 font-semibold hover:bg-gray-50">
                Resend Code
              </button>
            </div>

            <div className="text-center text-sm text-gray-500 font-mono">
              Code expires in: 0{mins}:{secs.toString().padStart(2, '0')}
            </div>
          </form>
        )}
      </div>
    </Sdg2Nav>
  );
}

// ─── Search helpers ───────────────────────────────────────────────────────────
// SDG2's own search is a formality in this simulator: the robots never open it and a
// presenter types whatever is in front of them. Both boxes therefore do the useful thing
// rather than the literal one — an id search matches on substring, and a card/account
// search narrows to a card when the last four digits typed belong to one, and otherwise
// (an empty box, or the company account number) lists the whole queue.

const containsText = (haystack: string, needle: string) =>
  haystack.toLowerCase().includes(needle.trim().toLowerCase());

const narrowsToCard = (cardLastFour: string, term: string, known: Set<string>) => {
  const last4 = term.replace(/\D/g, '').slice(-4);
  if (last4.length < 4 || !known.has(last4)) return true;
  return cardLastFour === last4;
};

const REPORT_CARD_LAST_FOURS = new Set(SDG2_REPORTS.map(r => r.cardLastFour));
const PR_CARD_LAST_FOURS = new Set(Object.values(SDG2_PURCHASE_REQUESTS).map(pr => pr.cardLastFour));

// ─── Reports / Payment Control ────────────────────────────────────────────────

export function Sdg2Reports() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const [searchBy, setSearchBy] = useState<'account' | 'purchaseRequestId'>('account');
  const [term, setTerm] = useState('');
  const [searched, setSearched] = useState(false);

  if (!state.auth.sdg2) {
    setLocation("/sdg2/login");
    return null;
  }

  // Every exception is listed at all times; the search narrows them. An empty box returns
  // the lot, which is what the account-number search does for this single-account demo.
  const reports = searched
    ? SDG2_REPORTS.filter(r =>
        searchBy === 'purchaseRequestId'
          ? containsText(r.purchaseRequestId, term)
          : narrowsToCard(r.cardLastFour, term, REPORT_CARD_LAST_FOURS))
    : [];

  return (
    <Sdg2Nav active="reports">
      <div className="bg-white border border-gray-200 rounded shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800 mb-6">Reports &rsaquo; Payment Control Exceptions</h2>

          <div className="bg-gray-50 p-4 rounded border border-gray-200 space-y-4">
            <div className="flex gap-6 items-end flex-wrap">
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Search by</label>
                <select
                  value={searchBy}
                  onChange={e => setSearchBy(e.target.value as 'account' | 'purchaseRequestId')}
                  className="border border-gray-300 rounded px-3 py-1.5 text-sm outline-none bg-white min-w-[220px]"
                  data-testid="sdg2-search-by"
                >
                  <option value="account">Account number</option>
                  <option value="purchaseRequestId">Purchase Request ID</option>
                </select>
              </div>

              {searchBy === 'account' ? (
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Card / Account Number</label>
                  <input value={term} onChange={e => setTerm(e.target.value)} placeholder="Enter account or card number" className="border border-gray-300 rounded px-3 py-1.5 text-sm outline-none w-52" data-testid="input-sdg2-account" />
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Purchase Request ID</label>
                  <input value={term} onChange={e => setTerm(e.target.value)} placeholder="e.g. PR-2026-004412" className="border border-gray-300 rounded px-3 py-1.5 text-sm outline-none w-52" data-testid="input-sdg2-pr-id" />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Date Range</label>
                <div className="flex items-center gap-2">
                  <input type="date" className="border border-gray-300 rounded px-3 py-1.5 text-sm outline-none" defaultValue="2026-06-01" />
                  <span className="text-gray-400">to</span>
                  <input type="date" className="border border-gray-300 rounded px-3 py-1.5 text-sm outline-none" defaultValue="2026-06-30" />
                </div>
              </div>

              <button
                onClick={() => setSearched(true)}
                className="bg-indigo-900 text-white px-6 py-1.5 rounded font-semibold hover:bg-indigo-800 h-[34px]"
                data-testid="btn-sdg2-search"
              >
                Search
              </button>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 font-semibold">Purchase Request ID</th>
                <th className="px-6 py-3 font-semibold">Virtual Card Number</th>
                <th className="px-6 py-3 font-semibold">Cardholder</th>
                <th className="px-6 py-3 font-semibold">Date</th>
                <th className="px-6 py-3 font-semibold">Merchant</th>
                <th className="px-6 py-3 font-semibold text-right">Amount</th>
                <th className="px-6 py-3 font-semibold">Status</th>
                <th className="px-6 py-3 font-semibold border-x border-t border-red-500 bg-red-50 text-red-800">InControl Response</th>
                <th className="px-6 py-3 font-semibold text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {!searched ? (
                <tr>
                  <td colSpan={9} className="px-6 py-12 text-center text-gray-400 italic">Enter search criteria above and click Search.</td>
                </tr>
              ) : reports.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-6 py-12 text-center text-gray-500 italic">No payment control exceptions found for this period.</td>
                </tr>
              ) : (
                reports.map((r, i) => (
                  <tr key={i} className="hover:bg-indigo-50/30 transition-colors">
                    <td className="px-6 py-4 font-mono text-indigo-900 font-semibold">{r.purchaseRequestId}</td>
                    <td className="px-6 py-4 font-mono text-gray-600">{r.virtualCardNumber}</td>
                    <td className="px-6 py-4">{r.cardholder}</td>
                    <td className="px-6 py-4 text-gray-600">{r.txnDate}</td>
                    <td className="px-6 py-4 font-medium">{r.merchant}</td>
                    <td className="px-6 py-4 text-right font-mono">{r.currency} {r.amount}</td>
                    <td className="px-6 py-4">
                      <span className="bg-red-100 text-red-800 px-2.5 py-0.5 rounded-full text-xs font-semibold">{r.status}</span>
                    </td>
                    <td className="px-6 py-4 border-x border-red-500 bg-red-50/50 font-semibold text-red-700" data-testid="sdg2-response">
                      {r.incontrolResponse}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <button
                        onClick={() => setLocation(`/sdg2/reports/txn/${encodeURIComponent(r.purchaseRequestId)}`)}
                        className="text-indigo-600 hover:text-indigo-900 font-semibold text-xs border border-indigo-200 px-3 py-1 rounded hover:bg-indigo-50"
                        data-testid={`btn-view-txn-${i}`}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </Sdg2Nav>
  );
}

// ─── Transaction Detail ───────────────────────────────────────────────────────

export function Sdg2TxnDetail() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams<{ purchaseRequestId: string }>();

  if (!state.auth.sdg2) {
    setLocation("/sdg2/login");
    return null;
  }

  const prId = decodeURIComponent(params.purchaseRequestId ?? '');
  const r = SDG2_REPORTS.find(x => x.purchaseRequestId === prId);

  if (!r) {
    return (
      <Sdg2Nav active="reports">
        <div className="text-center py-16 text-gray-500">Transaction not found.</div>
      </Sdg2Nav>
    );
  }

  return (
    <Sdg2Nav active="reports">
      <div className="mb-4">
        <button onClick={() => setLocation('/sdg2/reports/payment-control')} className="text-indigo-600 hover:text-indigo-900 text-sm font-medium flex items-center gap-1">
          ← Back to Payment Control Exceptions
        </button>
      </div>

      <div className="bg-white border border-gray-200 rounded shadow-sm">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-xl font-semibold text-gray-800">Transaction Detail</h2>
          <p className="text-sm text-gray-500 mt-1">Purchase Request ID: <span className="font-mono text-indigo-900 font-semibold" data-testid="detail-pr-id">{r.purchaseRequestId}</span></p>
        </div>

        <div className="p-6 grid grid-cols-2 gap-6">
          <div className="space-y-4">
            <Row label="Virtual Card Number" value={r.virtualCardNumber} testId="detail-vcn" mono />
            <Row label="Cardholder" value={r.cardholder} testId="detail-cardholder" />
            <Row label="Transaction Date" value={r.txnDate} testId="detail-txn-date" />
            <Row label="Merchant" value={r.merchant} testId="detail-merchant" />
            <Row label="Currency" value={r.currency} testId="detail-currency" />
            <Row label="Transaction Amount" value={`${r.currency} ${r.amount}`} testId="detail-amount" mono />
            <Row label="Status" value={r.status} testId="detail-status" badge badgeColor="red" />
            {r.vcnExpiry && <Row label="VCN Expiry" value={r.vcnExpiry} testId="detail-vcn-expiry" />}
          </div>

          <div>
            <div className="bg-red-50 border border-red-400 rounded-lg p-5">
              <div className="text-xs font-bold text-red-700 uppercase tracking-wider mb-3">InControl Response</div>
              <div className="text-2xl font-bold text-red-800 mb-4" data-testid="detail-incontrol-response">{r.incontrolResponse}</div>

              {r.minAmount && r.maxAmount && (
                <div className="border-t border-red-200 pt-4 space-y-3">
                  <div className="text-xs font-semibold text-red-700 uppercase tracking-wider">Exact Amount Range Control</div>
                  <div className="flex gap-6">
                    <div className="bg-white border border-red-200 rounded p-3 flex-1">
                      <div className="text-xs text-gray-500 mb-1">Minimum Amount</div>
                      <div className="font-mono font-bold text-gray-800" data-testid="detail-min-amount">{r.minAmount}</div>
                    </div>
                    <div className="bg-white border border-red-200 rounded p-3 flex-1">
                      <div className="text-xs text-gray-500 mb-1">Maximum Amount</div>
                      <div className="font-mono font-bold text-gray-800" data-testid="detail-max-amount">{r.maxAmount}</div>
                    </div>
                  </div>
                  <p className="text-xs text-red-700 mt-2">
                    The transaction amount ({r.currency} {r.amount}) exceeds the maximum limit of {r.maxAmount}. Transactions outside the configured range are automatically declined.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Sdg2Nav>
  );
}

// ─── View Requests ────────────────────────────────────────────────────────────

export function Sdg2ViewRequests() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const [searchBy, setSearchBy] = useState<'company' | 'prId'>('company');
  const [companyAccount, setCompanyAccount] = useState('');
  const [issuerBank, setIssuerBank] = useState('HSBC');
  const [prIdInput, setPrIdInput] = useState('');
  const [searched, setSearched] = useState(false);

  if (!state.auth.sdg2) {
    setLocation("/sdg2/login");
    return null;
  }

  const results = searched
    ? Object.values(SDG2_PURCHASE_REQUESTS).filter(pr =>
        searchBy === 'prId'
          ? containsText(pr.purchaseRequestId, prIdInput)
          : narrowsToCard(pr.cardLastFour, companyAccount, PR_CARD_LAST_FOURS))
    : [];

  return (
    <Sdg2Nav active="purchase-requests">
      <div className="bg-white border border-gray-200 rounded shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800 mb-1">Purchase Requests &rsaquo; View Requests</h2>
          <p className="text-sm text-gray-500 mb-6">Search for purchase requests by company account or purchase request ID.</p>

          <div className="bg-gray-50 p-4 rounded border border-gray-200 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Search by</label>
              <select
                value={searchBy}
                onChange={e => { setSearchBy(e.target.value as 'company' | 'prId'); setSearched(false); }}
                className="border border-gray-300 rounded px-3 py-1.5 text-sm outline-none bg-white min-w-[260px]"
                data-testid="pr-search-by"
              >
                <option value="company">Company Account Number</option>
                <option value="prId">Purchase Request ID</option>
              </select>
            </div>

            {searchBy === 'company' ? (
              <div className="flex gap-4 items-end flex-wrap">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Company Account Number</label>
                  <input
                    value={companyAccount}
                    onChange={e => setCompanyAccount(e.target.value)}
                    placeholder="e.g. 1100-000000-X1741"
                    className="border border-gray-300 rounded px-3 py-1.5 text-sm outline-none w-56"
                    data-testid="input-pr-company-account"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Issuer Bank Name</label>
                  <input
                    value={issuerBank}
                    onChange={e => setIssuerBank(e.target.value)}
                    className="border border-gray-300 rounded px-3 py-1.5 text-sm outline-none w-36"
                    data-testid="input-pr-issuer-bank"
                  />
                </div>
                <button
                  onClick={() => setSearched(true)}
                  className="bg-indigo-900 text-white px-6 py-1.5 rounded font-semibold hover:bg-indigo-800 h-[34px]"
                  data-testid="btn-pr-search"
                >
                  Search
                </button>
              </div>
            ) : (
              <div className="flex gap-4 items-end flex-wrap">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Purchase Request ID</label>
                  <input
                    value={prIdInput}
                    onChange={e => setPrIdInput(e.target.value)}
                    placeholder="e.g. PR-2026-004412"
                    className="border border-gray-300 rounded px-3 py-1.5 text-sm outline-none w-56"
                    data-testid="input-pr-id-search"
                  />
                </div>
                <button
                  onClick={() => setSearched(true)}
                  className="bg-indigo-900 text-white px-6 py-1.5 rounded font-semibold hover:bg-indigo-800 h-[34px]"
                  data-testid="btn-pr-search"
                >
                  Search
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 font-semibold">Purchase Request ID</th>
                <th className="px-6 py-3 font-semibold">Company Name</th>
                <th className="px-6 py-3 font-semibold">Cardholder</th>
                <th className="px-6 py-3 font-semibold">Amount Range</th>
                <th className="px-6 py-3 font-semibold">Currency</th>
                <th className="px-6 py-3 font-semibold">Status</th>
                <th className="px-6 py-3 font-semibold">Created</th>
                <th className="px-6 py-3 font-semibold">Expiry</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {!searched ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-400 italic">Enter search criteria above and click Search.</td>
                </tr>
              ) : results.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-500 italic">No purchase requests found.</td>
                </tr>
              ) : (
                results.map((r, i) => (
                  <tr key={i} className="hover:bg-indigo-50/30 transition-colors">
                    <td className="px-6 py-4">
                      <button
                        onClick={() => setLocation(`/sdg2/purchase-requests/${encodeURIComponent(r.purchaseRequestId)}`)}
                        className="font-mono text-indigo-700 hover:text-indigo-900 font-semibold hover:underline"
                        data-testid={`link-pr-${i}`}
                      >
                        {r.purchaseRequestId}
                      </button>
                    </td>
                    <td className="px-6 py-4">{r.companyName}</td>
                    <td className="px-6 py-4">{r.cardholder}</td>
                    <td className="px-6 py-4 font-mono text-sm">
                      {r.paymentControls.exactAmountRangeEnabled
                        ? `AED ${r.paymentControls.minAmount} – AED ${r.paymentControls.maxAmount}`
                        : '—'}
                    </td>
                    <td className="px-6 py-4">{r.currency}</td>
                    <td className="px-6 py-4">
                      <span className="bg-green-100 text-green-800 px-2.5 py-0.5 rounded-full text-xs font-semibold">{r.status}</span>
                    </td>
                    <td className="px-6 py-4 text-gray-600">{r.createdDate}</td>
                    <td className="px-6 py-4 text-gray-600">{r.expiryDate}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </Sdg2Nav>
  );
}

// ─── Purchase Request Detail ──────────────────────────────────────────────────

export function Sdg2PurchaseRequestDetail() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams<{ prId: string }>();

  if (!state.auth.sdg2) {
    setLocation("/sdg2/login");
    return null;
  }

  const prId = decodeURIComponent(params.prId ?? '');
  const pr = SDG2_PURCHASE_REQUESTS[prId];

  if (!pr) {
    return (
      <Sdg2Nav active="purchase-requests">
        <div className="text-center py-16 text-gray-500">Purchase request not found.</div>
      </Sdg2Nav>
    );
  }

  return (
    <Sdg2Nav active="purchase-requests">
      <div className="mb-4">
        <button onClick={() => setLocation('/sdg2/purchase-requests')} className="text-indigo-600 hover:text-indigo-900 text-sm font-medium flex items-center gap-1">
          ← Back to View Requests
        </button>
      </div>

      <div className="bg-white border border-gray-200 rounded shadow-sm">
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">Purchase Request</h2>
            <p className="text-sm text-gray-500 mt-1 font-mono font-semibold text-indigo-900" data-testid="pr-detail-id">{pr.purchaseRequestId}</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">{pr.status}</span>
            <button
              onClick={() => setLocation(`/sdg2/purchase-requests/${encodeURIComponent(pr.purchaseRequestId)}/edit`)}
              title="Edit Purchase Request"
              className="flex items-center gap-1.5 border border-gray-300 rounded px-3 py-1.5 text-sm text-gray-700 hover:bg-gray-50 hover:border-indigo-400 hover:text-indigo-700 transition-colors"
              data-testid="btn-edit-pr"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
              </svg>
              Edit
            </button>
          </div>
        </div>

        <div className="p-6 grid grid-cols-2 gap-8">
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4">Request Details</h3>
            <div className="space-y-3">
              <Row label="Company Name" value={pr.companyName} testId="pr-company-name" />
              <Row label="ICA / Issuer Bank" value={`${pr.ica} (HSBC)`} testId="pr-ica" mono />
              <Row label="Company Account" value={pr.companyAccount} testId="pr-company-account" mono />
              <Row label="Requestor" value={pr.requestorName} testId="pr-requestor" />
              <Row label="Requestor Email" value={pr.requestorEmail} testId="pr-requestor-email" />
              <Row label="Cardholder" value={pr.cardholder} testId="pr-cardholder" />
              <Row label="Virtual Card Number" value={pr.cardNumber} testId="pr-vcn" mono />
              <Row label="Currency" value={pr.currency} testId="pr-currency" />
              <Row label="Created Date" value={pr.createdDate} testId="pr-created" />
              <Row label="Expiry Date" value={pr.expiryDate} testId="pr-expiry" />
            </div>
          </div>

          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4">Payment Controls</h3>
            <div className="space-y-4">
              {pr.paymentControls.exactAmountRangeEnabled && (
                <div className="border border-indigo-200 bg-indigo-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-semibold text-indigo-900">Exact Amount Range Control</span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-green-100 text-green-800">ENABLED</span>
                  </div>
                  <div className="flex gap-4">
                    <div className="bg-white border border-indigo-200 rounded p-3 flex-1">
                      <div className="text-xs text-gray-500 mb-1">Minimum Amount</div>
                      <div className="font-mono font-bold text-gray-800" data-testid="pr-min-amount">AED {pr.paymentControls.minAmount}</div>
                    </div>
                    <div className="bg-white border border-indigo-200 rounded p-3 flex-1">
                      <div className="text-xs text-gray-500 mb-1">Maximum Amount</div>
                      <div className="font-mono font-bold text-gray-800" data-testid="pr-max-amount">AED {pr.paymentControls.maxAmount}</div>
                    </div>
                  </div>
                  <div className="mt-3 bg-amber-50 border border-amber-300 rounded p-3 text-xs text-amber-800">
                    <strong>Transaction amount: AED {pr.txnAmount}</strong> exceeds the maximum amount range of AED {pr.paymentControls.maxAmount}. This is why the transaction was declined (Amount Range Control Fail).
                  </div>
                </div>
              )}

              {pr.vcnExpiry && (
                <div className="border border-orange-200 bg-orange-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-semibold text-orange-900">Expiry Date Verification</span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-800">EXPIRY MATCH FAIL</span>
                  </div>
                  <div className="flex gap-4">
                    <div className="bg-white border border-orange-200 rounded p-3 flex-1">
                      <div className="text-xs text-gray-500 mb-1">Actual VCN Expiry</div>
                      <div className="font-mono font-bold text-green-700 text-lg" data-testid="pr-vcn-expiry">{pr.vcnExpiry}</div>
                    </div>
                    {pr.attemptedExpiry && (
                      <div className="bg-white border border-red-200 rounded p-3 flex-1">
                        <div className="text-xs text-gray-500 mb-1">Expiry Entered at Transaction</div>
                        <div className="font-mono font-bold text-red-700 text-lg" data-testid="pr-attempted-expiry">{pr.attemptedExpiry}</div>
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-orange-800 mt-3">
                    The expiry date entered ({pr.attemptedExpiry}) does not match the actual virtual card expiry ({pr.vcnExpiry}). The cardholder should re-attempt using the correct expiry date.
                  </p>
                </div>
              )}

              <div className="border border-gray-200 rounded-lg p-4 space-y-2">
                <Row label="Single Use" value={pr.paymentControls.singleUse ? 'Yes' : 'No'} testId="pr-single-use" />
                <Row label="Currency Restriction" value={pr.paymentControls.currencyRestriction} testId="pr-currency-restriction" mono />
              </div>
            </div>
          </div>
        </div>
      </div>
    </Sdg2Nav>
  );
}

// ─── Edit Purchase Request ────────────────────────────────────────────────────

export function Sdg2EditRequest() {
  const { state } = useSim();
  const [, setLocation] = useLocation();
  const params = useParams<{ prId: string }>();
  const [minAmount, setMinAmount] = useState('');
  const [maxAmount, setMaxAmount] = useState('');
  const [modalOpen, setModalOpen] = useState(false);

  const prId = decodeURIComponent(params.prId ?? '');
  const pr = SDG2_PURCHASE_REQUESTS[prId];

  useEffect(() => {
    if (pr) {
      setMinAmount(pr.paymentControls.minAmount);
      setMaxAmount(pr.paymentControls.maxAmount);
    }
  }, []);

  if (!state.auth.sdg2) {
    setLocation("/sdg2/login");
    return null;
  }

  if (!pr) {
    return (
      <Sdg2Nav active="purchase-requests">
        <div className="text-center py-16 text-gray-500">Purchase request not found.</div>
      </Sdg2Nav>
    );
  }

  return (
    <Sdg2Nav active="purchase-requests">
      <div className="mb-4">
        <button onClick={() => setLocation(`/sdg2/purchase-requests/${encodeURIComponent(prId)}`)} className="text-indigo-600 hover:text-indigo-900 text-sm font-medium flex items-center gap-1">
          ← Back to Purchase Request Detail
        </button>
      </div>

      <div className="bg-white border border-gray-200 rounded shadow-sm">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-xl font-semibold text-gray-800">Edit Purchase Request</h2>
          <p className="text-sm text-gray-500 mt-1 font-mono font-semibold text-indigo-900">{pr.purchaseRequestId}</p>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-2 gap-8">
            <div>
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4">Request Info (read-only)</h3>
              <div className="space-y-3 text-sm">
                <Row label="Company" value={pr.companyName} testId="edit-company" />
                <Row label="Cardholder" value={pr.cardholder} testId="edit-cardholder" />
                <Row label="Virtual Card" value={pr.cardNumber} testId="edit-vcn" mono />
                <Row label="Currency" value={pr.currency} testId="edit-currency" />
                <Row label="Expiry" value={pr.expiryDate} testId="edit-expiry" />
              </div>
            </div>

            <div>
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4">Payment Controls</h3>

              <div className="border border-indigo-200 rounded-lg p-5 space-y-5">
                <div>
                  <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 cursor-pointer">
                    <input type="checkbox" defaultChecked className="w-4 h-4 accent-indigo-700" data-testid="chk-exact-amount-range" />
                    Exact Amount Range Control
                  </label>
                  <p className="text-xs text-gray-500 mt-1 ml-6">Restrict this virtual card to transactions within a specific amount range.</p>
                </div>

                <div className="ml-6 grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Minimum Amount ({pr.currency})</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={minAmount}
                      onChange={e => setMinAmount(e.target.value)}
                      className="border border-gray-300 rounded px-3 py-2 text-sm outline-none w-full focus:ring-2 focus:ring-indigo-500 font-mono"
                      data-testid="input-edit-min-amount"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Maximum Amount ({pr.currency})</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={maxAmount}
                      onChange={e => setMaxAmount(e.target.value)}
                      className="border border-gray-300 rounded px-3 py-2 text-sm outline-none w-full focus:ring-2 focus:ring-indigo-500 font-mono"
                      data-testid="input-edit-max-amount"
                    />
                  </div>
                </div>

                <div>
                  <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                    <input type="checkbox" defaultChecked className="w-4 h-4 accent-indigo-700" />
                    Single Use
                  </label>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wider">Currency Restriction</label>
                  <input type="text" defaultValue={pr.paymentControls.currencyRestriction} disabled className="border border-gray-200 rounded px-3 py-2 text-sm w-24 bg-gray-50 text-gray-500 font-mono" />
                </div>
              </div>

              <div className="mt-4 bg-amber-50 border border-amber-200 rounded p-3 text-xs text-amber-700">
                <strong>Note:</strong> After submission, this Purchase Request will require approval from the designated approver before the cardholder can resume using the card.
              </div>
            </div>
          </div>

          <div className="flex gap-3 mt-8 pt-6 border-t border-gray-100">
            <button
              onClick={() => setModalOpen(true)}
              className="bg-indigo-900 text-white px-8 py-2.5 rounded font-semibold hover:bg-indigo-800 shadow-sm"
              data-testid="btn-submit-edit"
            >
              Submit
            </button>
            <button
              onClick={() => setLocation(`/sdg2/purchase-requests/${encodeURIComponent(prId)}`)}
              className="border border-gray-300 text-gray-700 px-8 py-2.5 rounded font-semibold hover:bg-gray-50"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>

      <ApprovalGateModal
        open={modalOpen}
        onOpenChange={(v) => {
          setModalOpen(v);
          if (!v) setLocation(`/sdg2/purchase-requests/${encodeURIComponent(prId)}`);
        }}
        system="SDG2"
        actionDesc={`Update Exact Amount Range on Purchase Request ${pr.purchaseRequestId} — new range: AED ${minAmount} – AED ${maxAmount}. Pending approver sign-off.`}
      />
    </Sdg2Nav>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function Row({
  label, value, testId, mono, badge, badgeColor
}: {
  label: string;
  value: string;
  testId?: string;
  mono?: boolean;
  badge?: boolean;
  badgeColor?: 'red' | 'green';
}) {
  const valueEl = badge ? (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${badgeColor === 'red' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`} data-testid={testId}>
      {value}
    </span>
  ) : (
    <span className={mono ? 'font-mono' : ''} data-testid={testId}>{value}</span>
  );

  return (
    <div className="flex items-start gap-2">
      <span className="text-xs text-gray-500 w-36 shrink-0 pt-0.5">{label}</span>
      <span className="text-sm text-gray-800 font-medium">{valueEl}</span>
    </div>
  );
}
