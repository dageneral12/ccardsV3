import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { SDG2_OTP, DQM_CASES, DqmCase } from '../data/seed';

export interface SimState {
  activeScenario: string;
  auth: {
    dqm: boolean;
    mivision: boolean;
    echamps: boolean;
    sdg2: boolean;
    whirl: boolean;
    gwis: boolean;
    mc: boolean;
  };
  mfa: {
    mivision: { securityNumber: string; challenge: number[]; passed: boolean; };
    sdg2: { otp: string | null; attemptsRemaining: number; lockedUntil: number | null; passed: boolean; };
  };
  activeCaseId: string | null;
  activeClientId: string | null;
  activeCardLastFour: string | null;
  activeCardType: "physical" | "virtual" | null;
  agentActionLog: Array<{ system: string; event: string; detail: string | null; ts: string; }>;
  dqmSplitCases: DqmCase[];
  dqmCaseOverrides: Record<string, Partial<DqmCase>>;
}

export type ValidSystem = keyof SimState['auth'];

interface SimContextType {
  state: SimState;
  dispatch: {
    LOGIN: (system: ValidSystem) => void;
    SET_SCENARIO: (scenario: string) => void;
    RESET_MFA: () => void;
    MFA_PASS: (system: "mivision" | "sdg2") => void;
    SDG2_OTP_ATTEMPT: (otp: string) => void;
    SET_ACTIVE_CASE: (caseId: string) => void;
    SET_ACTIVE_CLIENT: (clientId: string) => void;
    SET_ACTIVE_CARD: (lastFour: string, cardType: "physical" | "virtual") => void;
    LOG_ACTION: (system: string, event: string, detail: string | null) => void;
    MIVISION_GENERATE_CHALLENGE: () => void;
    DQM_SPLIT_CASE: (caseId: string) => string | null;
    DQM_DELETE_SPLIT_CASE: (caseId: string) => void;
    DQM_CLASSIFY_CASE: (caseId: string, updates: { caseType: string; caseSubType: string; caseSubTypeCategory?: string; owner?: string }) => void;
  };
}

const SimContext = createContext<SimContextType | undefined>(undefined);

function generateSecurityNumber(): string {
  return Array.from({ length: 8 }, () => Math.floor(Math.random() * 10)).join('');
}

function generateChallenge(): number[] {
  const positions = [1, 2, 3, 4, 5, 6, 7, 8];
  const shuffled = positions.sort(() => Math.random() - 0.5);
  return shuffled.slice(0, 3).sort((a, b) => a - b);
}

export function SimProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<SimState>({
    activeScenario: "S1",
    auth: {
      dqm: false,
      mivision: false,
      echamps: false,
      sdg2: false,
      whirl: false,
      gwis: false,
      mc: false,
    },
    mfa: {
      mivision: { securityNumber: generateSecurityNumber(), challenge: generateChallenge(), passed: false },
      sdg2: { otp: SDG2_OTP["S1"] || SDG2_OTP.default, attemptsRemaining: 3, lockedUntil: null, passed: false },
    },
    activeCaseId: null,
    activeClientId: null,
    activeCardLastFour: null,
    activeCardType: null,
    agentActionLog: [],
    dqmSplitCases: [],
    dqmCaseOverrides: {},
  });

  const LOGIN = useCallback((system: ValidSystem) => {
    setState(prev => ({
      ...prev,
      auth: { ...prev.auth, [system]: true }
    }));
  }, []);

  const RESET_MFA = useCallback((scenarioOverride?: string) => {
    setState(prev => {
      const scenario = scenarioOverride || prev.activeScenario;
      return {
        ...prev,
        mfa: {
          mivision: { securityNumber: generateSecurityNumber(), challenge: generateChallenge(), passed: false },
          sdg2: { otp: SDG2_OTP[scenario] || SDG2_OTP.default, attemptsRemaining: 3, lockedUntil: null, passed: false },
        }
      };
    });
  }, []);

  const SET_SCENARIO = useCallback((scenario: string) => {
    setState(prev => ({
      ...prev,
      activeScenario: scenario,
      auth: {
        dqm: false,
        mivision: false,
        echamps: false,
        sdg2: false,
        whirl: false,
        gwis: false,
        mc: false,
      }
    }));
    RESET_MFA(scenario);
  }, [RESET_MFA]);

  const MFA_PASS = useCallback((system: "mivision" | "sdg2") => {
    setState(prev => ({
      ...prev,
      auth: { ...prev.auth, [system]: true },
      mfa: {
        ...prev.mfa,
        [system]: { ...prev.mfa[system], passed: true }
      }
    }));
  }, []);

  const SDG2_OTP_ATTEMPT = useCallback((otp: string) => {
    setState(prev => {
      if (prev.mfa.sdg2.lockedUntil && prev.mfa.sdg2.lockedUntil > Date.now()) return prev;
      
      const isCorrect = otp === prev.mfa.sdg2.otp;
      if (isCorrect) {
        return {
          ...prev,
          auth: { ...prev.auth, sdg2: true },
          mfa: { ...prev.mfa, sdg2: { ...prev.mfa.sdg2, passed: true } }
        };
      } else {
        const rem = prev.mfa.sdg2.attemptsRemaining - 1;
        return {
          ...prev,
          mfa: {
            ...prev.mfa,
            sdg2: {
              ...prev.mfa.sdg2,
              attemptsRemaining: rem,
              lockedUntil: rem <= 0 ? Date.now() + 60000 : null
            }
          }
        };
      }
    });
  }, []);

  const SET_ACTIVE_CASE = useCallback((caseId: string) => {
    setState(prev => ({ ...prev, activeCaseId: caseId }));
  }, []);

  const SET_ACTIVE_CLIENT = useCallback((clientId: string) => {
    setState(prev => ({ ...prev, activeClientId: clientId }));
  }, []);

  const SET_ACTIVE_CARD = useCallback((lastFour: string, cardType: "physical" | "virtual") => {
    setState(prev => ({ ...prev, activeCardLastFour: lastFour, activeCardType: cardType }));
  }, []);

  const LOG_ACTION = useCallback((system: string, event: string, detail: string | null) => {
    setState(prev => {
      const log = [{
        system,
        event,
        detail,
        ts: new Date().toISOString()
      }, ...prev.agentActionLog].slice(0, 50);
      return { ...prev, agentActionLog: log };
    });
  }, []);

  const MIVISION_GENERATE_CHALLENGE = useCallback(() => {
    setState(prev => ({
      ...prev,
      mfa: {
        ...prev.mfa,
        mivision: { securityNumber: generateSecurityNumber(), challenge: generateChallenge(), passed: false }
      }
    }));
  }, []);

  const DQM_SPLIT_CASE = useCallback((caseId: string): string | null => {
    let newCaseId: string | null = null;
    setState(prev => {
      const original = [...DQM_CASES, ...prev.dqmSplitCases].find(c => c.id === caseId);
      if (!original) return prev;

      const suffix = Array.from({ length: 6 }, () => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Math.floor(Math.random() * 32)]).join('');
      const idPrefix = original.id.split('-')[1] || "9103999";
      newCaseId = `HSBC-${idPrefix}-${suffix}`;

      const splitCase: DqmCase = {
        ...original,
        id: newCaseId,
        caseType: "",
        caseSubType: "",
        caseSubTypeCategory: "",
        owner: "Yachnit Sharma",
        status: "New",
        createdOn: original.createdOn,
        splitFromCaseId: original.id,
        email: { ...original.email }
      };

      const log = [{
        system: "DQM",
        event: "Case Split",
        detail: `Case ${original.id} split into new case ${newCaseId}, assigned to Yachnit Sharma`,
        ts: new Date().toISOString()
      }, ...prev.agentActionLog].slice(0, 50);

      return {
        ...prev,
        dqmSplitCases: [...prev.dqmSplitCases, splitCase],
        agentActionLog: log
      };
    });
    return newCaseId;
  }, []);

  const DQM_DELETE_SPLIT_CASE = useCallback((caseId: string) => {
    setState(prev => {
      const target = prev.dqmSplitCases.find(c => c.id === caseId);
      if (!target) return prev;

      const log = [{
        system: "DQM",
        event: "Case Deleted",
        detail: `Split case ${caseId} deleted`,
        ts: new Date().toISOString()
      }, ...prev.agentActionLog].slice(0, 50);

      return {
        ...prev,
        dqmSplitCases: prev.dqmSplitCases.filter(c => c.id !== caseId),
        agentActionLog: log
      };
    });
  }, []);

  const DQM_CLASSIFY_CASE = useCallback((caseId: string, updates: { caseType: string; caseSubType: string; caseSubTypeCategory?: string; owner?: string }) => {
    setState(prev => {
      const splitIdx = prev.dqmSplitCases.findIndex(c => c.id === caseId);

      const applyUpdate = (base: DqmCase): DqmCase => ({
        ...base,
        caseType: updates.caseType,
        caseSubType: updates.caseSubType,
        caseSubTypeCategory: updates.caseSubTypeCategory ?? base.caseSubTypeCategory,
        owner: updates.owner ?? base.owner
      });

      const log = [{
        system: "DQM",
        event: "Case Classified",
        detail: `Case ${caseId} classified as ${updates.caseType} / ${updates.caseSubType}`,
        ts: new Date().toISOString()
      }, ...prev.agentActionLog].slice(0, 50);

      if (splitIdx !== -1) {
        const updatedSplitCases = [...prev.dqmSplitCases];
        updatedSplitCases[splitIdx] = applyUpdate(updatedSplitCases[splitIdx]);
        return { ...prev, dqmSplitCases: updatedSplitCases, agentActionLog: log };
      }

      const seedCase = DQM_CASES.find(c => c.id === caseId);
      if (!seedCase) return prev;
      const merged = applyUpdate({ ...seedCase, ...prev.dqmCaseOverrides[caseId] });
      return {
        ...prev,
        dqmCaseOverrides: { ...prev.dqmCaseOverrides, [caseId]: merged },
        agentActionLog: log
      };
    });
  }, []);

  return (
    <SimContext.Provider value={{
      state,
      dispatch: {
        LOGIN,
        SET_SCENARIO,
        RESET_MFA,
        MFA_PASS,
        SDG2_OTP_ATTEMPT,
        SET_ACTIVE_CASE,
        SET_ACTIVE_CLIENT,
        SET_ACTIVE_CARD,
        LOG_ACTION,
        MIVISION_GENERATE_CHALLENGE,
        DQM_SPLIT_CASE,
        DQM_DELETE_SPLIT_CASE,
        DQM_CLASSIFY_CASE
      }
    }}>
      {children}
    </SimContext.Provider>
  );
}

export function useSim() {
  const ctx = useContext(SimContext);
  if (!ctx) throw new Error("useSim must be used within SimProvider");
  return ctx;
}
