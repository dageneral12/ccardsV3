// ─── Presenter cardholders ────────────────────────────────────────────────────
//
// Cards, cases and system records for the people who actually present the demo, so a
// presenter can e-mail the agent from their own mailbox about their own card and watch
// the robots read their own name back off the screens.
//
// Each presenter gets one card per scenario (S1..S9) under Burj Khalifah Travel, because
// every system in this simulator is keyed by card: a card carries exactly one decline
// reason, so "all scenarios" means one card per scenario, not one card with nine
// histories. Card numbers are Luhn-valid and share the client's 5550-4100 BIN, which the
// MiVision robot checks against the first eight digits quoted in the customer's e-mail.
//
// To add a presenter: append to PRESENTERS below with an unused four-digit `group` and
// nine unused last-fours (`cardSuffixes`), then re-run scripts/check-seed-cards.mjs
// to confirm the numbers are Luhn-valid and unique. Nothing else needs editing — seed.ts
// splices whatever this file exports into every system's tables.

import type { DqmCase, MiVisionCard } from './seed';

export interface Presenter {
  /** Initials used in generated case, ticket and request ids. */
  initials: string;
  name: string;
  jobTitle: string;
  email: string;
  /** Third group of the card number. Pick one no other presenter uses, then choose
   *  cardSuffixes that make each 16-digit number Luhn-valid against it. */
  group: string;
  /** Last four digits per scenario, S1..S9 in order. Each completes a Luhn-valid number. */
  cardSuffixes: string[];
  /** Serial block for the generated ids, keeps each presenter's references distinct. */
  idBlock: string;
}

export const PRESENTERS: Presenter[] = [
  {
    initials: 'NT',
    name: 'Nikita Tihhomirov',
    jobTitle: 'Marketing Manager',
    email: 'nikita.tihhomirov@camunda.com',
    group: '9902',
    cardSuffixes: ['1010', '2026', '3032', '4048', '5052', '6068', '7074', '8080', '9096'],
    idBlock: '46'
  },
  {
    initials: 'KN',
    name: 'Kailash Nair',
    jobTitle: 'Global Head of Commercial Cards',
    email: 'kailashnair@hsbc.com',
    group: '9903',
    cardSuffixes: ['1019', '2025', '3031', '4047', '5051', '6067', '7073', '8089', '9095'],
    idBlock: '47'
  }
];

const ACCOUNT_MASKED = '1100-000000-X1741';
const ACCOUNT_FULL = '1100-031741';
const ACCOUNT_LONG = '0000110000000031741';

interface ScenarioTemplate {
  id: string;
  form: 'physical' | 'virtual';
  subject: string;
  priority: string;
  status: string;
  caseSubTypeCategory: string;
  declineReason: string;
  createdOn: string;
  slaFirstResponseBy: string;
  slaResolveBy: string;
  merchant: string;
  merchantPretty: string;
  amount: string;
  txnDate: string;
  txnTime: string;
  /** eChamps authorisation row, or null for the virtual cards whose decline lives in SDG2. */
  auth: { reasonCode: string; reasonDesc: string; finalAction: string; reversalType: string } | null;
  expiry: string;
  creditLimit: string;
  outstandingBalance: string;
  availableBalance: string;
  mosBlockedCodes: string;
  emailSubject: string;
  emailBody: string;
  /** Extra records this scenario needs in the presenter-facing systems. */
  whirl?: { tableNumber: string; page: string; tableType: 'AOV' | 'MID' };
  gwis?: boolean;
  ghcs?: boolean;
  mastercard?: boolean;
  vcn?: { limit: string; min: string; max: string; expiry: string; attemptedExpiry?: string; incontrolResponse: string };
}

// Every scenario keeps the merchant, amount, date and decline code of its original card, so
// the story a presenter tells is the same one the seed cards tell.
const SCENARIOS: ScenarioTemplate[] = [
  {
    id: 'S1',
    form: 'physical',
    subject: 'EXTERNAL: Transaction Decline — Spend Limit',
    priority: 'Normal',
    status: 'New',
    caseSubTypeCategory: 'Spend Limit',
    declineReason: 'Insufficient spend limit',
    createdOn: '24/06/2026 10:52',
    slaFirstResponseBy: '25/06/2026 10:52',
    slaResolveBy: '27/06/2026 10:52',
    merchant: 'GO FAST FUEL LLC',
    merchantPretty: 'Go Fast Fuel LLC',
    amount: '1,500.00',
    txnDate: '22/06/2026',
    txnTime: '14:31:00',
    auth: { reasonCode: '0023', reasonDesc: 'OPENTOBUY', finalAction: 'Declined', reversalType: 'DECLINED' },
    expiry: 'Sep-29',
    creditLimit: '25,000.00 AED',
    outstandingBalance: '25,000.00 AED',
    availableBalance: '0.00 AED',
    mosBlockedCodes: '0 of 34 Blocked',
    emailSubject: 'EXTERNAL: Card Decline — card ending {last4}',
    emailBody: 'Hi, my transaction was declined at Go Fast Fuel. Card no. ending {last4}. Date: 22/06/2026. Amount: AED 1,500. Merchant: Go Fast Fuel LLC. Please advise.'
  },
  {
    id: 'S2',
    form: 'physical',
    subject: 'EXTERNAL: Card Declined During Overseas Travel — Singapore',
    priority: 'High',
    status: 'New',
    caseSubTypeCategory: 'Fraud Block',
    declineReason: 'Fraud alert block',
    createdOn: '01/07/2026 08:48',
    slaFirstResponseBy: '02/07/2026 08:48',
    slaResolveBy: '04/07/2026 08:48',
    merchant: 'ATLAS HOTEL SINGAPORE',
    merchantPretty: 'Atlas Hotel, Singapore',
    amount: '2,150.00',
    txnDate: '01/07/2026',
    txnTime: '22:21:00',
    auth: { reasonCode: '0713', reasonDesc: 'FALC DECL', finalAction: 'Declined', reversalType: 'DECLINED' },
    expiry: 'Feb-29',
    creditLimit: '25,000.00 AED',
    outstandingBalance: '16,600.00 AED',
    availableBalance: '8,400.00 AED',
    mosBlockedCodes: '1 of 34 Blocked',
    emailSubject: 'EXTERNAL: Card declined — Atlas Hotel, Singapore — card ending {last4}',
    emailBody: 'Hi, I am travelling in Singapore on business and my card ending {last4} was declined at the Atlas Hotel on 01/07/2026. Amount AED 2,150.00. It looks like the fraud system has flagged the overseas transaction. Please advise urgently, I am currently without a working payment method.'
  },
  {
    id: 'S3',
    form: 'physical',
    subject: 'EXTERNAL: Card Decline — MCC Restriction',
    priority: 'Normal',
    status: 'New',
    caseSubTypeCategory: 'MCC Restriction',
    declineReason: 'MCC restriction',
    createdOn: '24/06/2026 11:38',
    slaFirstResponseBy: '25/06/2026 11:38',
    slaResolveBy: '27/06/2026 11:38',
    merchant: 'CARREFOUR UAE',
    merchantPretty: 'Carrefour UAE',
    amount: '450.00',
    txnDate: '18/06/2026',
    txnTime: '10:12:00',
    auth: { reasonCode: '0728', reasonDesc: 'AOV EXCEED', finalAction: 'Declined', reversalType: 'DECLINED' },
    expiry: 'Nov-28',
    creditLimit: '20,000.00 AED',
    outstandingBalance: '8,100.00 AED',
    availableBalance: '11,900.00 AED',
    mosBlockedCodes: '2 of 34 Blocked',
    emailSubject: 'EXTERNAL: Card decline at Carrefour — card ending {last4}',
    emailBody: 'Card ending {last4} declined at Carrefour UAE on 18/06/2026. Amount AED 450. MCC restriction suspected. Please investigate.',
    whirl: { tableNumber: '30', page: '30', tableType: 'AOV' }
  },
  {
    id: 'S4',
    form: 'physical',
    subject: 'EXTERNAL: Card Decline — MID Restriction',
    priority: 'Normal',
    status: 'New',
    caseSubTypeCategory: 'MID Restriction',
    declineReason: 'MID restriction',
    createdOn: '24/06/2026 13:08',
    slaFirstResponseBy: '25/06/2026 13:08',
    slaResolveBy: '27/06/2026 13:08',
    merchant: 'NOON.COM',
    merchantPretty: 'Noon.com',
    amount: '299.00',
    txnDate: '20/06/2026',
    txnTime: '11:37:00',
    auth: { reasonCode: '0854', reasonDesc: 'MID RESTR', finalAction: 'Declined', reversalType: 'DECLINED' },
    expiry: 'Mar-29',
    creditLimit: '15,000.00 AED',
    outstandingBalance: '6,200.00 AED',
    availableBalance: '8,800.00 AED',
    mosBlockedCodes: '1 of 34 Blocked',
    emailSubject: 'EXTERNAL: Card decline at Noon — card ending {last4}',
    emailBody: 'Card ending {last4} was declined at Noon.com on 20/06/2026. Amount AED 299. Please investigate.',
    whirl: { tableNumber: '36', page: '36', tableType: 'MID' },
    gwis: true
  },
  {
    id: 'S5',
    form: 'physical',
    subject: 'EXTERNAL: Card Decline — Incorrect Expiry Date',
    priority: 'Normal',
    status: 'New',
    caseSubTypeCategory: 'Incorrect Card Details',
    declineReason: 'Incorrect expiry date',
    createdOn: '24/06/2026 14:18',
    slaFirstResponseBy: '25/06/2026 14:18',
    slaResolveBy: '27/06/2026 14:18',
    merchant: 'IKEA UAE',
    merchantPretty: 'IKEA UAE',
    amount: '850.00',
    txnDate: '21/06/2026',
    txnTime: '09:52:00',
    auth: { reasonCode: '0080', reasonDesc: 'EXP DTE KY', finalAction: 'Declined', reversalType: 'DECLINED' },
    // The card does not expire until Jul-29; the e-mail below says 01/27 was keyed, which is
    // what the 0080/EXP DTE KY code means and what the agent should correct the customer on.
    expiry: 'Jul-29',
    creditLimit: '10,000.00 AED',
    outstandingBalance: '3,400.00 AED',
    availableBalance: '6,600.00 AED',
    mosBlockedCodes: '0 of 34 Blocked',
    emailSubject: 'EXTERNAL: Card declined at IKEA — card ending {last4}',
    emailBody: 'Card ending {last4} was declined at IKEA UAE on 21/06/2026. Amount AED 850. I entered expiry 01/27 but the transaction was declined.'
  },
  {
    id: 'S6',
    form: 'physical',
    subject: 'EXTERNAL: Card Decline — Incorrect CVV',
    priority: 'Normal',
    status: 'New',
    caseSubTypeCategory: 'Incorrect Card Details',
    declineReason: 'Incorrect CVV',
    createdOn: '24/06/2026 15:08',
    slaFirstResponseBy: '25/06/2026 15:08',
    slaResolveBy: '27/06/2026 15:08',
    merchant: 'EMAAR MALLS',
    merchantPretty: 'Emaar Malls',
    amount: '620.00',
    txnDate: '22/06/2026',
    txnTime: '13:27:00',
    auth: { reasonCode: '0076', reasonDesc: 'INV CVV', finalAction: 'Declined', reversalType: 'DECLINED' },
    expiry: 'Aug-29',
    creditLimit: '12,000.00 AED',
    outstandingBalance: '4,100.00 AED',
    availableBalance: '7,900.00 AED',
    mosBlockedCodes: '0 of 34 Blocked',
    emailSubject: 'EXTERNAL: Card decline — Emaar Malls — card ending {last4}',
    emailBody: 'Card ending {last4} declined at Emaar Malls on 22/06/2026. Amount AED 620. CVV rejected at POS.'
  },
  {
    id: 'S7',
    form: 'virtual',
    subject: 'EXTERNAL: Virtual Card Decline — Amount Range',
    priority: 'Normal',
    status: 'New',
    caseSubTypeCategory: 'Virtual Card — Amount Control',
    declineReason: 'Amount range control',
    createdOn: '23/06/2026 18:30',
    slaFirstResponseBy: '24/06/2026 18:30',
    slaResolveBy: '26/06/2026 18:30',
    merchant: 'AMAZON AE',
    merchantPretty: 'Amazon AE',
    amount: '15,000.00',
    txnDate: '22/06/2026',
    txnTime: '17:04:00',
    // Virtual-card declines are raised by InControl, not by the authorisation host, so there is
    // no eChamps row — the evidence sits in the SDG2 purchase request below.
    auth: null,
    expiry: 'Feb-28',
    creditLimit: '0.00 AED',
    outstandingBalance: '0.00 AED',
    availableBalance: '0.00 AED',
    mosBlockedCodes: '0 of 34 Blocked',
    emailSubject: 'EXTERNAL: Virtual card declined — Amazon AE — card ending {last4}',
    emailBody: 'Our virtual card ending {last4} was declined at Amazon AE on 22/06/2026. Amount AED 15,000. Please investigate.',
    vcn: { limit: '15,000.00 AED', min: '100.00', max: '10,000.00', expiry: 'Feb-28', incontrolResponse: 'Amount Range Control Fail' }
  },
  {
    id: 'S8',
    form: 'virtual',
    subject: 'EXTERNAL: Virtual Card Decline — Incorrect Expiry',
    priority: 'Normal',
    status: 'New',
    caseSubTypeCategory: 'Virtual Card — Incorrect Card Details',
    declineReason: 'Incorrect expiry date (virtual)',
    createdOn: '23/06/2026 20:13',
    slaFirstResponseBy: '24/06/2026 20:13',
    slaResolveBy: '26/06/2026 20:13',
    merchant: 'HILTON HOTELS UAE',
    merchantPretty: 'Hilton Hotels UAE',
    amount: '4,200.00',
    txnDate: '23/06/2026',
    txnTime: '19:48:00',
    auth: null,
    expiry: 'Dec-27',
    creditLimit: '0.00 AED',
    outstandingBalance: '0.00 AED',
    availableBalance: '0.00 AED',
    mosBlockedCodes: '0 of 34 Blocked',
    emailSubject: 'EXTERNAL: Virtual card declined — Hilton Hotels — card ending {last4}',
    emailBody: 'Virtual card ending {last4} was declined at Hilton Hotels UAE on 23/06/2026. Amount AED 4,200. Please investigate.',
    vcn: { limit: '10,000.00 AED', min: '', max: '', expiry: 'Dec-27', attemptedExpiry: 'Mar-26', incontrolResponse: 'Expiry Match Fail' }
  },
  {
    id: 'S9',
    form: 'physical',
    subject: 'EXTERNAL: Card Decline — POS / Mastercard Network',
    priority: 'High',
    status: 'New',
    caseSubTypeCategory: 'POS / Network Decline',
    declineReason: 'POS / Mastercard network decline',
    createdOn: '24/06/2026 16:38',
    slaFirstResponseBy: '25/06/2026 16:38',
    slaResolveBy: '27/06/2026 16:38',
    merchant: 'SPINNEYS UAE',
    merchantPretty: 'Spinneys UAE',
    amount: '2,100.00',
    txnDate: '23/06/2026',
    txnTime: '16:48:00',
    // Present but empty: the whole point of S9 is that eChamps holds no decline, which sends
    // the investigation on to GHCS and then Mastercard Connect.
    auth: { reasonCode: 'N/A', reasonDesc: 'NO DECLINE RECORD', finalAction: 'No Record', reversalType: 'N/A' },
    expiry: 'Oct-28',
    creditLimit: '20,000.00 AED',
    outstandingBalance: '9,800.00 AED',
    availableBalance: '10,200.00 AED',
    mosBlockedCodes: '0 of 34 Blocked',
    emailSubject: 'EXTERNAL: Card declined — Spinneys — card ending {last4}',
    emailBody: 'Card ending {last4} was declined at Spinneys UAE on 23/06/2026. Amount AED 2,100. No clear reason was given at the POS terminal. Please investigate.',
    ghcs: true,
    mastercard: true
  }
];

// ─── Generated records ────────────────────────────────────────────────────────

export interface EChampsAuth {
  date: string; time: string; cardNumber: string; txnAmt: string; settlementAmt: string;
  reasonCode: string; reasonDesc: string; finalAction: string; authCode: string; reversalType: string;
  openToBuy?: string;
}

export interface Sdg2Report {
  purchaseRequestId: string; virtualCardNumber: string; cardholder: string; txnDate: string;
  merchant: string; amount: string; currency: string; status: string; incontrolResponse: string;
  cardLastFour: string;
  minAmount?: string; maxAmount?: string; vcnExpiry?: string;
}

export interface Sdg2PurchaseRequest {
  purchaseRequestId: string; companyName: string; ica: string; companyAccount: string;
  requestorName: string; requestorEmail: string; cardNumber: string; cardholder: string;
  currency: string; status: string; createdDate: string; expiryDate: string; merchant: string;
  txnAmount: string; cardLastFour: string; vcnExpiry?: string; attemptedExpiry?: string;
  paymentControls: { exactAmountRangeEnabled: boolean; minAmount: string; maxAmount: string; singleUse: boolean; currencyRestriction: string };
}

export interface GhcsTicket {
  ticketId: string; subject: string; cardNumber: string; impactedLocation: string;
  lineOfBusiness: string; coreApplication: string; issueDetails: string; status: string;
  resolution: string; createdDate: string; cardLastFour: string;
}

export interface McCase {
  caseId: string; subject: string; cardNumber: string; status: string; category: string;
  subCategory: string; createdDate: string; resolution: string; cardLastFour: string;
  resolvedDate?: string;
}

export interface GwisDoc {
  requestNumber: string; documentType: string; clientName: string; accountNumber: string;
  submittedDate: string; scannedDate: string; status: string; description: string;
  cardLastFour: string;
}

export interface WhirlCardTable { tableNumber: string; org: string; logo: string; page: string; tableType: 'AOV' | 'MID' }

const fmt = (group: string, last4: string) => ({
  full: `5550-4100-${group}-${last4}`,
  masked: `5550-4100-XXXX-${last4}`
});

const cardSeries = (form: 'physical' | 'virtual') => (form === 'virtual' ? 'HSBC-9095058' : 'HSBC-9103999');

export const PRESENTER_CARDS: MiVisionCard[] = [];
export const PRESENTER_DQM_CASES: DqmCase[] = [];
export const PRESENTER_ECHAMPS_AUTHS: Record<string, EChampsAuth[]> = {};
export const PRESENTER_SDG2_REPORTS: Sdg2Report[] = [];
export const PRESENTER_SDG2_PURCHASE_REQUESTS: Record<string, Sdg2PurchaseRequest> = {};
export const PRESENTER_GHCS_TICKETS: Record<string, GhcsTicket> = {};
export const PRESENTER_MC_CASES: McCase[] = [];
export const PRESENTER_GWIS_DOCS: GwisDoc[] = [];
export const PRESENTER_WHIRL_CARD_TABLES: Record<string, WhirlCardTable> = {};

/** Authorised-contact rows for the presenters, spliced into the client's External Contacts table. */
export const PRESENTER_CONTACTS = PRESENTERS.map(p => ({
  name: p.name,
  email: p.email,
  jobTitle: p.jobTitle,
  primaryRole: 'Secondary PoC',
  secondaryRole: ''
}));

/** Names shown in the MiVision client Users column. */
export const PRESENTER_USERS = PRESENTERS.map(p => ({
  name: p.name,
  company: 'Burj Khalifah Travel LLC',
  code: '520'
}));

for (const p of PRESENTERS) {
  SCENARIOS.forEach((s, i) => {
    const last4 = p.cardSuffixes[i];
    const { full, masked } = fmt(p.group, last4);
    const nn = String(i + 1).padStart(2, '0');
    const virtual = s.form === 'virtual';

    PRESENTER_CARDS.push({
      scenarioId: s.id,
      lastFour: last4,
      fullMasked: masked,
      fullNumber: full,
      cardHolder: p.name,
      expiry: s.expiry,
      creditLimit: s.creditLimit,
      outstandingBalance: s.outstandingBalance,
      availableBalance: s.availableBalance,
      email: p.email,
      productType: virtual ? 'Virtual UAE Purchasing' : 'UAE Purchasing',
      status: 'Active',
      statusCode: 'A',
      cardBillingType: 'Individually Billed',
      companyAccountMasked: ACCOUNT_MASKED,
      companyAccountFull: ACCOUNT_FULL,
      lastPurchaseDate: s.txnDate,
      daysOverdue: 0,
      cardLimit: s.creditLimit,
      mosBlockedCodes: s.mosBlockedCodes,
      atmAccess: virtual ? 'No' : 'Yes',
      unpostedTransaction: virtual || s.id === 'S9'
        ? { present: false }
        : {
            present: true,
            date: s.txnDate,
            merchant: s.merchant,
            amount: s.amount,
            currency: 'AED',
            declineReason: `${s.auth!.reasonCode}/${s.auth!.reasonDesc}`
          },
      pastStatements: virtual ? [] : [{ period: 'Jun 2026', amount: s.outstandingBalance }],
      cardholderLimitSummary: virtual
        ? { currentLimit: s.vcn!.limit, available: s.vcn!.limit }
        : { currentLimit: s.creditLimit, available: s.availableBalance }
    });

    const caseId = `${cardSeries(s.form)}-${p.initials}${nn}`;
    PRESENTER_DQM_CASES.push({
      id: caseId,
      subject: s.subject,
      status: s.status,
      priority: s.priority,
      owner: 'Roshan Menon',
      mailbox: 'CSS-UAE-Shared@hsbc.com',
      client: 'Burj Khalifah Travel',
      clientId: 'BKT001',
      caseType: 'Transaction Related',
      caseSubType: 'Decline, Transaction not going through',
      caseSubTypeCategory: s.caseSubTypeCategory,
      createdOn: s.createdOn,
      country: 'United Arab Emirates',
      scenario: s.id,
      cardLastFour: last4,
      cardType: s.form,
      declineReason: s.declineReason,
      accountNumber: ACCOUNT_MASKED,
      slaFirstResponseBy: s.slaFirstResponseBy,
      slaResolveBy: s.slaResolveBy,
      ...(virtual && s.vcn?.expiry ? { vcnExpiry: s.vcn.expiry } : {}),
      ...(s.id === 'S7'
        ? {
            purchaseRequestId: `PR-2026-00${p.idBlock}${nn}`,
            purchaseRequestMin: s.vcn!.min,
            purchaseRequestMax: s.vcn!.max,
            requestorName: p.name
          }
        : {}),
      email: {
        from: p.email,
        to: `${p.name} <${p.email}>`,
        subject: s.emailSubject.replace('{last4}', last4),
        regarding: caseId,
        body: s.emailBody.replace(/\{last4\}/g, last4),
        modifiedOn: s.createdOn,
        status: 'Read',
        authorisedContact: true,
        contactName: p.name,
        contactEmail: p.email,
        contactTitle: p.jobTitle,
        contactRole: 'Secondary PoC'
      }
    });

    if (s.auth) {
      PRESENTER_ECHAMPS_AUTHS[last4] = [{
        date: s.txnDate,
        time: s.txnTime,
        cardNumber: full,
        txnAmt: s.amount,
        settlementAmt: `AED ${s.amount}`,
        reasonCode: s.auth.reasonCode,
        reasonDesc: s.auth.reasonDesc,
        finalAction: s.auth.finalAction,
        authCode: '',
        reversalType: s.auth.reversalType,
        openToBuy: s.availableBalance
      }];
    }

    if (s.vcn) {
      const prId = `PR-2026-00${p.idBlock}${nn}`;
      PRESENTER_SDG2_REPORTS.push({
        purchaseRequestId: prId,
        virtualCardNumber: `XXXX-XXXX-XXXX-${last4}`,
        cardholder: p.name,
        txnDate: s.txnDate,
        merchant: s.merchant,
        amount: s.amount,
        currency: 'AED',
        status: 'Declined',
        incontrolResponse: s.vcn.incontrolResponse,
        cardLastFour: last4,
        ...(s.vcn.min ? { minAmount: `${s.vcn.min} AED`, maxAmount: `${s.vcn.max} AED` } : {}),
        vcnExpiry: s.vcn.attemptedExpiry ?? s.vcn.expiry
      });
      PRESENTER_SDG2_PURCHASE_REQUESTS[prId] = {
        purchaseRequestId: prId,
        companyName: 'Burj Khalifah Travel LLC',
        ica: '031741',
        companyAccount: ACCOUNT_MASKED,
        requestorName: p.name,
        requestorEmail: p.email,
        cardNumber: `XXXX-XXXX-XXXX-${last4}`,
        cardholder: p.name,
        currency: 'AED',
        status: 'Active',
        createdDate: '18/06/2026',
        expiryDate: '28/06/2026',
        merchant: s.merchant,
        txnAmount: s.amount,
        cardLastFour: last4,
        ...(s.vcn.attemptedExpiry ? { vcnExpiry: s.vcn.expiry, attemptedExpiry: s.vcn.attemptedExpiry } : {}),
        paymentControls: {
          exactAmountRangeEnabled: Boolean(s.vcn.min),
          minAmount: s.vcn.min,
          maxAmount: s.vcn.max,
          singleUse: true,
          currencyRestriction: 'AED'
        }
      };
    }

    if (s.ghcs) {
      const ticketId = `INC008${p.idBlock}${nn}`;
      PRESENTER_GHCS_TICKETS[ticketId] = {
        ticketId,
        subject: `Card transaction declined at POS — no decline record on eChamps`,
        cardNumber: full,
        impactedLocation: 'United Arab Emirates',
        lineOfBusiness: 'Commercial Banking (CMB)',
        coreApplication: 'Statement/Transaction enquiries',
        issueDetails: `Physical card ending ${last4} (${p.name}, Burj Khalifah Travel) was declined at ${s.merchantPretty} on ${s.txnDate} for AED ${s.amount}. No decline record is visible on the eChamps authorisation system. Requesting investigation into a possible network-level decline.`,
        status: 'Escalated to Mastercard',
        resolution: 'No eChamps record found. Transaction escalated to Mastercard Connect for network-level investigation.',
        createdDate: '24/06/2026',
        cardLastFour: last4
      };
    }

    if (s.mastercard) {
      PRESENTER_MC_CASES.push({
        caseId: `MC-2026-07${p.idBlock}${nn}`,
        subject: `Transaction declined at POS — no eChamps record — card ending ${last4}`,
        cardNumber: full,
        status: 'Resolved',
        category: 'Transaction Investigation',
        subCategory: 'POS Decline — Network',
        createdDate: '25/06/2026',
        resolvedDate: '26/06/2026',
        resolution: 'Investigation confirmed the transaction was declined at the Mastercard network/acquirer level due to a temporary POS communication timeout at the merchant terminal. No card issue identified. The card is fully operational. Client may re-attempt the transaction at the same or alternative terminal.',
        cardLastFour: last4
      });
    }

    if (s.gwis) {
      PRESENTER_GWIS_DOCS.push({
        requestNumber: `GWIS-2026-4${p.idBlock}${nn}`,
        documentType: 'MID Restriction Addition Request',
        clientName: 'Burj Khalifah Travel LLC',
        accountNumber: ACCOUNT_LONG,
        submittedDate: '25/06/2026',
        scannedDate: '25/06/2026',
        status: 'Scanned — Pending Card Operations',
        description: `Request to add MID-792301445 (NOON.COM UAE) to the MID restriction table for card ending ${last4} (${p.name}). Signed by authorised signatories on company letterhead and submitted in branch.`,
        cardLastFour: last4
      });
    }

    if (s.whirl) {
      PRESENTER_WHIRL_CARD_TABLES[last4] = {
        tableNumber: s.whirl.tableNumber,
        org: '031',
        logo: '741',
        page: s.whirl.page,
        tableType: s.whirl.tableType
      };
    }
  });
}
