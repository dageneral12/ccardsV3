import {
  PRESENTER_CARDS,
  PRESENTER_DQM_CASES,
  PRESENTER_ECHAMPS_AUTHS,
  PRESENTER_SDG2_REPORTS,
  PRESENTER_SDG2_PURCHASE_REQUESTS,
  PRESENTER_GHCS_TICKETS,
  PRESENTER_MC_CASES,
  PRESENTER_GWIS_DOCS,
  PRESENTER_WHIRL_CARD_TABLES,
  PRESENTER_CONTACTS,
  PRESENTER_USERS,
  type EChampsAuth,
  type Sdg2Report,
  type Sdg2PurchaseRequest,
  type GhcsTicket,
  type McCase,
  type GwisDoc,
  type WhirlCardTable
} from './presenters';

// ─── DQM Cases — All 9 scenarios ─────────────────────────────────────────────

export interface DqmCase {
  id: string;
  subject: string;
  status: string;
  priority: string;
  owner: string;
  mailbox: string;
  client: string;
  clientId: string;
  caseType: string;
  caseSubType: string;
  caseSubTypeCategory: string;
  createdOn: string;
  country: string;
  scenario: string;
  cardLastFour: string;
  cardType: string;
  declineReason?: string;
  accountNumber: string;
  slaFirstResponseBy: string;
  slaResolveBy: string;
  vcnExpiry?: string;
  purchaseRequestId?: string;
  purchaseRequestMin?: string;
  purchaseRequestMax?: string;
  requestorName?: string;
  splitFromCaseId?: string | null;
  email: {
    from: string;
    to: string;
    subject: string;
    regarding: string;
    body: string;
    modifiedOn: string;
    status: string;
    authorisedContact: boolean;
    contactName: string;
    contactEmail: string;
    contactTitle: string;
    contactRole: string;
    originalCc?: Array<{ name: string; email: string }>;
  };
}

export const DQM_CASES: DqmCase[] = [
  {
    id: "HSBC-9103999-44T2W9",
    subject: "EXTERNAL: Transaction Decline — Spend Limit",
    status: "New",
    priority: "Normal",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "Transaction Related",
    caseSubType: "Decline, Transaction not going through",
    caseSubTypeCategory: "Spend Limit",
    createdOn: "24/06/2026 10:44",
    country: "United Arab Emirates",
    scenario: "S1",
    cardLastFour: "9155",
    cardType: "physical",
    declineReason: "Insufficient spend limit",
    accountNumber: "1100-000000-X1741",
    slaFirstResponseBy: "25/06/2026 10:44",
    slaResolveBy: "27/06/2026 10:44",
    email: {
      from: "jasmin@burjkhalifahtravel.ae",
      to: "Jasmin Al Rashid <jasmin@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Card Decline — card ending 9155",
      regarding: "HSBC-9103999-44T2W9",
      body: "Hi, my transaction was declined at Go Fast Fuel. Card no. ending 9155. Date: 22/06/2026. Amount: AED 1,500. Merchant: Go Fast Fuel LLC. Please advise.",
      modifiedOn: "24/06/2026 10:44",
      status: "Read",
      authorisedContact: true,
      contactName: "Jasmin Al Rashid",
      contactEmail: "jasmin@burjkhalifahtravel.ae",
      contactTitle: "Programme Administrator",
      contactRole: "Primary PoC"
    }
  },
  {
    id: "HSBC-9103999-FRAUD1",
    subject: "EXTERNAL: Card Declined During Overseas Travel — Singapore",
    status: "New",
    priority: "High",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "Transaction Related",
    caseSubType: "Decline, Transaction not going through",
    caseSubTypeCategory: "Fraud Block",
    createdOn: "01/07/2026 08:40",
    country: "United Arab Emirates",
    scenario: "S2",
    cardLastFour: "3821",
    cardType: "physical",
    declineReason: "Fraud alert block",
    accountNumber: "1100-000000-X1741",
    slaFirstResponseBy: "02/07/2026 08:40",
    slaResolveBy: "04/07/2026 08:40",
    email: {
      from: "jasmin@burjkhalifahtravel.ae",
      to: "Jasmin Al Rashid <jasmin@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Card declined — Atlas Hotel, Singapore — card ending 3821",
      regarding: "HSBC-9103999-FRAUD1",
      body: "Hi, Emma Carter has travelled to Singapore for business and her card ending 3821 was declined during a transaction at the Atlas Hotel on 01/07/2026. Amount AED 2,150.00. It looks like our fraud system flagged the overseas transaction. Please advise urgently as she is currently stranded without a working payment method.",
      modifiedOn: "01/07/2026 08:40",
      status: "Read",
      authorisedContact: true,
      contactName: "Jasmin Al Rashid",
      contactEmail: "jasmin@burjkhalifahtravel.ae",
      contactTitle: "Programme Administrator",
      contactRole: "Primary PoC",
      originalCc: [
        { name: "Omar Sheikh", email: "omar.sheikh@gmail.com" }
      ]
    }
  },
  {
    id: "HSBC-9103999-MCC01",
    subject: "EXTERNAL: Card Decline — MCC Restriction",
    status: "In Progress",
    priority: "Normal",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "Transaction Related",
    caseSubType: "Decline, Transaction not going through",
    caseSubTypeCategory: "MCC Restriction",
    createdOn: "24/06/2026 11:30",
    country: "United Arab Emirates",
    scenario: "S3",
    cardLastFour: "7404",
    cardType: "physical",
    declineReason: "MCC restriction",
    accountNumber: "1100-000000-X1741",
    slaFirstResponseBy: "25/06/2026 11:30",
    slaResolveBy: "27/06/2026 11:30",
    email: {
      from: "sara@burjkhalifahtravel.ae",
      to: "Sara Al Hashimi <sara@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Card decline at Carrefour — card ending 7404",
      regarding: "HSBC-9103999-MCC01",
      body: "Card ending 7404 declined at Carrefour UAE on 18/06/2026. Amount AED 450. MCC restriction suspected. Please investigate.",
      modifiedOn: "24/06/2026 11:30",
      status: "Read",
      authorisedContact: true,
      contactName: "Sara Al Hashimi",
      contactEmail: "sara@burjkhalifahtravel.ae",
      contactTitle: "Procurement Lead",
      contactRole: "Secondary PoC"
    }
  },
  {
    id: "HSBC-9103999-MID01",
    subject: "EXTERNAL: Card Decline — MID Restriction",
    status: "New",
    priority: "Normal",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "Transaction Related",
    caseSubType: "Decline, Transaction not going through",
    caseSubTypeCategory: "MID Restriction",
    createdOn: "24/06/2026 13:00",
    country: "United Arab Emirates",
    scenario: "S4",
    cardLastFour: "2290",
    cardType: "physical",
    declineReason: "MID restriction",
    accountNumber: "1100-000000-X1741",
    slaFirstResponseBy: "25/06/2026 13:00",
    slaResolveBy: "27/06/2026 13:00",
    email: {
      from: "jasmin@burjkhalifahtravel.ae",
      to: "Jasmin Al Rashid <jasmin@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Card decline at Noon — card ending 2290",
      regarding: "HSBC-9103999-MID01",
      body: "Card ending 2290 was declined at Noon.com on 20/06/2026. Amount AED 299. Please investigate.",
      modifiedOn: "24/06/2026 13:00",
      status: "Read",
      authorisedContact: true,
      contactName: "Jasmin Al Rashid",
      contactEmail: "jasmin@burjkhalifahtravel.ae",
      contactTitle: "Programme Administrator",
      contactRole: "Primary PoC"
    }
  },
  {
    id: "HSBC-9103999-EXP01",
    subject: "EXTERNAL: Card Decline — Incorrect Expiry Date",
    status: "New",
    priority: "Normal",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "Transaction Related",
    caseSubType: "Decline, Transaction not going through",
    caseSubTypeCategory: "Incorrect Card Details",
    createdOn: "24/06/2026 14:10",
    country: "United Arab Emirates",
    scenario: "S5",
    cardLastFour: "4412",
    cardType: "physical",
    declineReason: "Incorrect expiry date",
    accountNumber: "1100-000000-X1741",
    slaFirstResponseBy: "25/06/2026 14:10",
    slaResolveBy: "27/06/2026 14:10",
    email: {
      from: "khalid@burjkhalifahtravel.ae",
      to: "Khalid Mansour <khalid@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Card declined at IKEA — card ending 4412",
      regarding: "HSBC-9103999-EXP01",
      body: "Card ending 4412 was declined at IKEA UAE on 21/06/2026. Amount AED 850. Cardholder entered expiry 01/27 but was declined.",
      modifiedOn: "24/06/2026 14:10",
      status: "Read",
      authorisedContact: true,
      contactName: "Khalid Mansour",
      contactEmail: "khalid@burjkhalifahtravel.ae",
      contactTitle: "Finance Manager",
      contactRole: "Authorised Signatory"
    }
  },
  {
    id: "HSBC-9103999-CVV01",
    subject: "EXTERNAL: Card Decline — Incorrect CVV",
    status: "New",
    priority: "Normal",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "Transaction Related",
    caseSubType: "Decline, Transaction not going through",
    caseSubTypeCategory: "Incorrect Card Details",
    createdOn: "24/06/2026 15:00",
    country: "United Arab Emirates",
    scenario: "S6",
    cardLastFour: "8801",
    cardType: "physical",
    declineReason: "Incorrect CVV",
    accountNumber: "1100-000000-X1741",
    slaFirstResponseBy: "25/06/2026 15:00",
    slaResolveBy: "27/06/2026 15:00",
    email: {
      from: "sara@burjkhalifahtravel.ae",
      to: "Sara Al Hashimi <sara@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Card decline — Emaar Malls — card ending 8801",
      regarding: "HSBC-9103999-CVV01",
      body: "Card ending 8801 declined at Emaar Malls on 22/06/2026. Amount AED 620. CVV rejected at POS.",
      modifiedOn: "24/06/2026 15:00",
      status: "Read",
      authorisedContact: true,
      contactName: "Sara Al Hashimi",
      contactEmail: "sara@burjkhalifahtravel.ae",
      contactTitle: "Procurement Lead",
      contactRole: "Secondary PoC"
    }
  },
  {
    id: "HSBC-9095058-VC001",
    subject: "EXTERNAL: Virtual Card Decline — Amount Range",
    status: "New",
    priority: "Normal",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "Transaction Related",
    caseSubType: "Decline, Transaction not going through",
    caseSubTypeCategory: "Virtual Card — Amount Control",
    createdOn: "23/06/2026 18:22",
    country: "United Arab Emirates",
    scenario: "S7",
    cardLastFour: "1040",
    cardType: "virtual",
    declineReason: "Amount range control",
    accountNumber: "1100-000000-X1741",
    purchaseRequestId: "PR-2026-004412",
    purchaseRequestMin: "100.00",
    purchaseRequestMax: "10,000.00",
    requestorName: "Munira Al Hashimi",
    slaFirstResponseBy: "24/06/2026 18:22",
    slaResolveBy: "26/06/2026 18:22",
    email: {
      from: "jasmin@burjkhalifahtravel.ae",
      to: "Jasmin Al Rashid <jasmin@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Virtual card declined — Amazon AE — card ending 1040",
      regarding: "HSBC-9095058-VC001",
      body: "Our virtual card ending 1040 was declined at Amazon AE on 22/06/2026. Amount AED 15,000. Please investigate.",
      modifiedOn: "23/06/2026 18:22",
      status: "Read",
      authorisedContact: true,
      contactName: "Jasmin Al Rashid",
      contactEmail: "jasmin@burjkhalifahtravel.ae",
      contactTitle: "Programme Administrator",
      contactRole: "Primary PoC"
    }
  },
  {
    id: "HSBC-9095058-VC002",
    subject: "EXTERNAL: Virtual Card Decline — Incorrect Expiry",
    status: "New",
    priority: "Normal",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "Transaction Related",
    caseSubType: "Decline, Transaction not going through",
    caseSubTypeCategory: "Virtual Card — Incorrect Card Details",
    createdOn: "23/06/2026 20:05",
    country: "United Arab Emirates",
    scenario: "S8",
    cardLastFour: "2271",
    cardType: "virtual",
    declineReason: "Incorrect expiry date (virtual)",
    accountNumber: "1100-000000-X1741",
    vcnExpiry: "Dec-26",
    slaFirstResponseBy: "24/06/2026 20:05",
    slaResolveBy: "26/06/2026 20:05",
    email: {
      from: "khalid@burjkhalifahtravel.ae",
      to: "Khalid Mansour <khalid@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Virtual card declined — Hilton Hotels — card ending 2271",
      regarding: "HSBC-9095058-VC002",
      body: "Virtual card ending 2271 was declined at Hilton Hotels UAE on 23/06/2026. Amount AED 4,200. Please investigate.",
      modifiedOn: "23/06/2026 20:05",
      status: "Read",
      authorisedContact: true,
      contactName: "Khalid Mansour",
      contactEmail: "khalid@burjkhalifahtravel.ae",
      contactTitle: "Finance Manager",
      contactRole: "Authorised Signatory"
    }
  },
  {
    id: "HSBC-9103999-MC001",
    subject: "EXTERNAL: Card Decline — POS / Mastercard Network",
    status: "New",
    priority: "High",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "Transaction Related",
    caseSubType: "Decline, Transaction not going through",
    caseSubTypeCategory: "POS / Network Decline",
    createdOn: "24/06/2026 16:30",
    country: "United Arab Emirates",
    scenario: "S9",
    cardLastFour: "6614",
    cardType: "physical",
    declineReason: "POS / Mastercard network decline",
    accountNumber: "1100-000000-X1741",
    slaFirstResponseBy: "25/06/2026 16:30",
    slaResolveBy: "27/06/2026 16:30",
    email: {
      from: "jasmin@burjkhalifahtravel.ae",
      to: "Jasmin Al Rashid <jasmin@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Card declined — Spinneys — card ending 6614",
      regarding: "HSBC-9103999-MC001",
      body: "Card ending 6614 was declined at Spinneys UAE on 23/06/2026. Amount AED 2,100. No clear reason given at POS. Please investigate.",
      modifiedOn: "24/06/2026 16:30",
      status: "Read",
      authorisedContact: true,
      contactName: "Jasmin Al Rashid",
      contactEmail: "jasmin@burjkhalifahtravel.ae",
      contactTitle: "Programme Administrator",
      contactRole: "Primary PoC"
    }
  },
  {
    id: "HSBC-9103999-MIXED1",
    subject: "EXTERNAL: Card decline query and new card application status",
    status: "New",
    priority: "Normal",
    owner: "Roshan Menon",
    mailbox: "CSS-UAE-Shared@hsbc.com",
    client: "Burj Khalifah Travel",
    clientId: "BKT001",
    caseType: "",
    caseSubType: "",
    caseSubTypeCategory: "",
    createdOn: "02/07/2026 09:12",
    country: "United Arab Emirates",
    scenario: "S10",
    cardLastFour: "9155",
    cardType: "physical",
    declineReason: "Insufficient spend limit",
    accountNumber: "1100-000000-X1741",
    slaFirstResponseBy: "03/07/2026 09:12",
    slaResolveBy: "05/07/2026 09:12",
    splitFromCaseId: null,
    email: {
      from: "jasmin@burjkhalifahtravel.ae",
      to: "Jasmin Al Rashid <jasmin@burjkhalifahtravel.ae>",
      subject: "EXTERNAL: Card decline query and new card application status",
      regarding: "HSBC-9103999-MIXED1",
      body: "Hi team,\n\nTwo separate items for you today:\n\n1) Could you confirm the status of the new virtual card application (Ref: VCA-2091) we submitted for our new starter Fatima Noor on 24/06/2026? It has been over a week and we have not received an update.\n\n2) Emma Carter has travelled to Singapore for business and her card ending 3821 was declined at the Atlas Hotel while checking in. This is urgent as she is currently stranded without a working payment method. Please investigate and advise as soon as possible.\n\nThanks,\nJasmin",
      modifiedOn: "02/07/2026 09:12",
      status: "Read",
      authorisedContact: true,
      contactName: "Jasmin Al Rashid",
      contactEmail: "jasmin@burjkhalifahtravel.ae",
      contactTitle: "Programme Administrator",
      contactRole: "Primary PoC"
    }
  },

  // One case per scenario for each demo presenter, generated in presenters.ts. They sit after
  // the seeded cases so the DQM robot, which walks the list in order and stops at the first case
  // whose From address or External Contacts match the sender, never has to read this far.
  ...PRESENTER_DQM_CASES
];

// ─── MiVision ─────────────────────────────────────────────────────────────────

export interface MiVisionCard {
  scenarioId: string;
  lastFour: string;
  fullMasked: string;
  fullNumber: string;
  cardHolder: string;
  expiry: string;
  creditLimit: string;
  outstandingBalance: string;
  availableBalance: string;
  email: string;
  productType: string;
  status: string;
  statusCode: string;
  cardBillingType: string;
  companyAccountMasked: string;
  companyAccountFull: string;
  lastPurchaseDate: string;
  daysOverdue: number;
  cardLimit: string;
  mosBlockedCodes: string;
  atmAccess: string;
  closedDate?: string;
  unpostedTransaction: {
    present: boolean;
    date?: string;
    merchant?: string;
    amount?: string;
    currency?: string;
    declineReason?: string;
  };
  pastStatements: Array<{ period: string; amount: string }>;
  cardholderLimitSummary: { currentLimit: string; available: string };
}

export interface MiVisionProgram {
  id: string;
  name: string;
  code: string;
  displayCode: string;
  fullProgramNumber: string;
  maskedProgramNumber: string;
  fullAccountNumber: string;
  programLimit: string;
  totalCardholderLimits: string;
  availableCapacity: string;
  label: string;
}

export interface MiVisionClient {
  id: string;
  clientName: string;
  searchAliases: string[];
  customerNumber: string;
  shortCode: string;
  maskedAccountRef: string;
  initialsAvatar: string;
  cinCountry: string;
  cin: string;
  tier: string;
  country: string;
  programs: MiVisionProgram[];
  users: Array<{ name: string; company: string; code: string }>;
  cards: MiVisionCard[];
  internalContacts?: Array<{ name: string; role: string; email: string; phone: string }>;
  authorisedContacts?: Array<{ name: string; email: string; jobTitle: string; primaryRole: string; secondaryRole?: string }>;
}

export const MIVISION_CLIENTS: MiVisionClient[] = [
  {
    id: "BKT001",
    clientName: "BURJ KHALIFAH TRAVEL LLC",
    searchAliases: ["Burj Khalifah Travel", "Burj Khalifah", "BKT", "burj", "088134520"],
    customerNumber: "088134520",
    shortCode: "LLC",
    maskedAccountRef: "0000/BKTLME088134520",
    initialsAvatar: "BK",
    cinCountry: "United Arab Emirates",
    cin: "DXB 14",
    tier: "GPS Premium",
    country: "United Arab Emirates",

    programs: [
      {
        id: "PROG001",
        name: "BURJ KHALIFAH — UAE Corporate",
        code: "0000BKTLME088134520",
        displayCode: "BKT",
        fullProgramNumber: "031741",
        maskedProgramNumber: "1100-000000-X1741",
        fullAccountNumber: "0000110000000031741",
        programLimit: "500,000.00 AED",
        totalCardholderLimits: "487,500.00 AED",
        availableCapacity: "12,500.00 AED",
        label: "G - UAE Corporate"
      }
    ],

    users: [
      { name: "Jasmin Al Rashid", company: "Burj Khalifah Travel LLC", code: "520" },
      { name: "Khalid Mansour",   company: "Burj Khalifah Travel LLC", code: "520" },
      { name: "Sara Al Hashimi",  company: "Burj Khalifah Travel LLC", code: "520" },
      ...PRESENTER_USERS
    ],

    internalContacts: [
      { name: "Marcus Wentworth", role: "Relationship Manager", email: "marcus.wentworth@hsbc.com", phone: "+971 4 507 8821" },
      { name: "Priya Nair",       role: "RM Support",           email: "priya.nair@hsbc.com",       phone: "+971 4 507 8835" }
    ],

    authorisedContacts: [
      { name: "Jasmin Al Rashid", email: "jasmin@burjkhalifahtravel.ae",  jobTitle: "Programme Administrator", primaryRole: "Primary PoC",         secondaryRole: "" },
      { name: "Sara Al Hashimi",  email: "sara@burjkhalifahtravel.ae",    jobTitle: "Procurement Lead",        primaryRole: "Secondary PoC",       secondaryRole: "" },
      { name: "Khalid Mansour",   email: "khalid@burjkhalifahtravel.ae",  jobTitle: "Finance Manager",         primaryRole: "Authorised Signatory", secondaryRole: "" },
      { name: "Fatima Al Zaabi",  email: "fatima@burjkhalifahtravel.ae",  jobTitle: "Operations Manager",      primaryRole: "Secondary PoC",       secondaryRole: "Authorised Signatory" },
      { name: "Rashid Al Nuaimi", email: "rashid@burjkhalifahtravel.ae",  jobTitle: "IT Administrator",        primaryRole: "Secondary PoC",       secondaryRole: "" },

      // ── Demo presenters ────────────────────────────────────────────────────────
      // Real mailboxes, listed as authorised contacts of Burj Khalifah Travel so a
      // presenter can email the agent from their own address and be recognised instead
      // of routing to UNAUTHORISED_SENDER. Sender authorisation is decided from this
      // table: the DQM robot scrapes it and the intake process matches the From address
      // against the email column, case-insensitively.
      // Kailash Nair's address is an HSBC one. He is listed here because he presents the
      // demo from it, not because a bank employee would really be a client's authorised
      // contact. Edit PRESENTERS in presenters.ts to add, rename or remove a presenter —
      // that one entry also generates their cards and every system record behind them.
      ...PRESENTER_CONTACTS
    ],

    cards: [
      // S1 — Insufficient spend limit — Physical
      {
        scenarioId: "S1",
        lastFour: "9155",
        fullMasked: "5550-4100-XXXX-9155",
        fullNumber: "5550-4100-9901-9155",
        cardHolder: "Ali Jassim Al Mansoori",
        expiry: "Sep-29",
        creditLimit: "25,000.00 AED",
        outstandingBalance: "25,000.00 AED",
        availableBalance: "0.00 AED",
        email: "ali.almansoori@burjkhalifahtravel.ae",
        productType: "UAE Purchasing",
        status: "Active",
        statusCode: "A",
        cardBillingType: "Individually Billed",
        companyAccountMasked: "1100-000000-X1741",
        companyAccountFull: "1100-031741",
        lastPurchaseDate: "22/06/2026",
        daysOverdue: 0,
        cardLimit: "25,000.00 AED",
        mosBlockedCodes: "0 of 34 Blocked",
        atmAccess: "Yes",
        unpostedTransaction: {
          present: true,
          date: "22/06/2026",
          merchant: "GO FAST FUEL LLC",
          amount: "1,500.00",
          currency: "AED",
          declineReason: "0023/OPENTOBUY"
        },
        pastStatements: [
          { period: "Jun 2026", amount: "25,000.00 AED" },
          { period: "May 2026", amount: "21,300.00 AED" },
          { period: "Apr 2026", amount: "18,900.00 AED" }
        ],
        cardholderLimitSummary: { currentLimit: "25,000.00 AED", available: "0.00 AED" }
      },

      // S2 — Fraud alert block (overseas travel) — Physical
      {
        scenarioId: "S2",
        lastFour: "3821",
        fullMasked: "5550-4100-XXXX-3821",
        fullNumber: "5550-4100-9901-3821",
        cardHolder: "Emma Carter",
        expiry: "Feb-27",
        creditLimit: "25,000.00 AED",
        outstandingBalance: "16,600.00 AED",
        availableBalance: "8,400.00 AED",
        email: "emma.carter@burjkhalifahtravel.ae",
        productType: "UAE Purchasing",
        status: "Active",
        statusCode: "A",
        cardBillingType: "Individually Billed",
        companyAccountMasked: "1100-000000-X1741",
        companyAccountFull: "1100-031741",
        lastPurchaseDate: "01/07/2026",
        daysOverdue: 0,
        cardLimit: "25,000.00 AED",
        mosBlockedCodes: "1 of 34 Blocked",
        atmAccess: "Yes",
        unpostedTransaction: {
          present: true,
          date: "01/07/2026",
          merchant: "ATLAS HOTEL SINGAPORE",
          amount: "2,150.00",
          currency: "AED",
          declineReason: "0713/FALC DECL"
        },
        pastStatements: [
          { period: "Jun 2026", amount: "16,600.00 AED" },
          { period: "May 2026", amount: "14,200.00 AED" }
        ],
        cardholderLimitSummary: { currentLimit: "25,000.00 AED", available: "8,400.00 AED" }
      },

      // S3 — MCC restriction — Physical
      {
        scenarioId: "S3",
        lastFour: "7404",
        fullMasked: "5550-4100-XXXX-7404",
        fullNumber: "5550-4100-9901-7404",
        cardHolder: "Madina Karimova",
        expiry: "Nov-28",
        creditLimit: "20,000.00 AED",
        outstandingBalance: "8,100.00 AED",
        availableBalance: "11,900.00 AED",
        email: "madina.karimova@burjkhalifahtravel.ae",
        productType: "UAE Purchasing",
        status: "Active",
        statusCode: "A",
        cardBillingType: "Individually Billed",
        companyAccountMasked: "1100-000000-X1741",
        companyAccountFull: "1100-031741",
        lastPurchaseDate: "18/06/2026",
        daysOverdue: 0,
        cardLimit: "20,000.00 AED",
        mosBlockedCodes: "2 of 34 Blocked",
        atmAccess: "Yes",
        unpostedTransaction: {
          present: true,
          date: "18/06/2026",
          merchant: "CARREFOUR UAE",
          amount: "450.00",
          currency: "AED",
          declineReason: "0728/AOV EXCEED"
        },
        pastStatements: [
          { period: "Jun 2026", amount: "8,100.00 AED" }
        ],
        cardholderLimitSummary: { currentLimit: "20,000.00 AED", available: "11,900.00 AED" }
      },

      // S4 — MID restriction — Physical
      {
        scenarioId: "S4",
        lastFour: "2290",
        fullMasked: "5550-4100-XXXX-2290",
        fullNumber: "5550-4100-9901-2290",
        cardHolder: "Venkatesh Pillai",
        expiry: "Mar-28",
        creditLimit: "15,000.00 AED",
        outstandingBalance: "6,200.00 AED",
        availableBalance: "8,800.00 AED",
        email: "venkatesh.pillai@burjkhalifahtravel.ae",
        productType: "UAE Purchasing",
        status: "Active",
        statusCode: "A",
        cardBillingType: "Individually Billed",
        companyAccountMasked: "1100-000000-X1741",
        companyAccountFull: "1100-031741",
        lastPurchaseDate: "20/06/2026",
        daysOverdue: 0,
        cardLimit: "15,000.00 AED",
        mosBlockedCodes: "1 of 34 Blocked",
        atmAccess: "Yes",
        unpostedTransaction: {
          present: true,
          date: "20/06/2026",
          merchant: "NOON.COM",
          amount: "299.00",
          currency: "AED",
          declineReason: "0854/MID RESTR"
        },
        pastStatements: [
          { period: "Jun 2026", amount: "6,200.00 AED" }
        ],
        cardholderLimitSummary: { currentLimit: "15,000.00 AED", available: "8,800.00 AED" }
      },

      // S5 — Incorrect expiry date — Physical
      {
        scenarioId: "S5",
        lastFour: "4412",
        fullMasked: "5550-4100-XXXX-4412",
        fullNumber: "5550-4100-9901-4412",
        cardHolder: "Rashida Omar Al Farsi",
        expiry: "Jan-27",
        creditLimit: "10,000.00 AED",
        outstandingBalance: "3,400.00 AED",
        availableBalance: "6,600.00 AED",
        email: "rashida.alfarsi@burjkhalifahtravel.ae",
        productType: "UAE Purchasing",
        status: "Active",
        statusCode: "A",
        cardBillingType: "Individually Billed",
        companyAccountMasked: "1100-000000-X1741",
        companyAccountFull: "1100-031741",
        lastPurchaseDate: "21/06/2026",
        daysOverdue: 0,
        cardLimit: "10,000.00 AED",
        mosBlockedCodes: "0 of 34 Blocked",
        atmAccess: "Yes",
        unpostedTransaction: {
          present: true,
          date: "21/06/2026",
          merchant: "IKEA UAE",
          amount: "850.00",
          currency: "AED",
          declineReason: "0080/EXP DTE KY"
        },
        pastStatements: [
          { period: "Jun 2026", amount: "3,400.00 AED" }
        ],
        cardholderLimitSummary: { currentLimit: "10,000.00 AED", available: "6,600.00 AED" }
      },

      // S6 — Incorrect CVV — Physical
      {
        scenarioId: "S6",
        lastFour: "8801",
        fullMasked: "5550-4100-XXXX-8801",
        fullNumber: "5550-4100-9901-8801",
        cardHolder: "Omar Mahmoud Al Tahir",
        expiry: "Aug-28",
        creditLimit: "12,000.00 AED",
        outstandingBalance: "4,100.00 AED",
        availableBalance: "7,900.00 AED",
        email: "omar.altahir@burjkhalifahtravel.ae",
        productType: "UAE Purchasing",
        status: "Active",
        statusCode: "A",
        cardBillingType: "Individually Billed",
        companyAccountMasked: "1100-000000-X1741",
        companyAccountFull: "1100-031741",
        lastPurchaseDate: "22/06/2026",
        daysOverdue: 0,
        cardLimit: "12,000.00 AED",
        mosBlockedCodes: "0 of 34 Blocked",
        atmAccess: "Yes",
        unpostedTransaction: {
          present: true,
          date: "22/06/2026",
          merchant: "EMAAR MALLS",
          amount: "620.00",
          currency: "AED",
          declineReason: "0076/INV CVV"
        },
        pastStatements: [
          { period: "Jun 2026", amount: "4,100.00 AED" }
        ],
        cardholderLimitSummary: { currentLimit: "12,000.00 AED", available: "7,900.00 AED" }
      },

      // S7 — Amount range control — Virtual
      {
        scenarioId: "S7",
        lastFour: "1040",
        fullMasked: "5550-4100-XXXX-1040",
        fullNumber: "5550-4100-9901-1040",
        cardHolder: "Munira Al Hashimi",
        expiry: "Feb-27",
        creditLimit: "0.00 AED",
        outstandingBalance: "0.00 AED",
        availableBalance: "0.00 AED",
        email: "munira.alhashimi@burjkhalifahtravel.ae",
        productType: "Virtual UAE Purchasing",
        status: "Active",
        statusCode: "A",
        cardBillingType: "Individually Billed",
        companyAccountMasked: "1100-000000-X1741",
        companyAccountFull: "1100-031741",
        lastPurchaseDate: "22/06/2026",
        daysOverdue: 0,
        cardLimit: "0.00 AED",
        mosBlockedCodes: "0 of 34 Blocked",
        atmAccess: "No",
        unpostedTransaction: { present: false },
        pastStatements: [],
        cardholderLimitSummary: { currentLimit: "15,000.00 AED", available: "15,000.00 AED" }
      },

      // S8 — Incorrect expiry date — Virtual
      {
        scenarioId: "S8",
        lastFour: "2271",
        fullMasked: "5550-4100-XXXX-2271",
        fullNumber: "5550-4100-9901-2271",
        cardHolder: "Layla Sara Khalil",
        expiry: "Dec-26",
        creditLimit: "0.00 AED",
        outstandingBalance: "0.00 AED",
        availableBalance: "0.00 AED",
        email: "layla.khalil@burjkhalifahtravel.ae",
        productType: "Virtual UAE Purchasing",
        status: "Active",
        statusCode: "A",
        cardBillingType: "Individually Billed",
        companyAccountMasked: "1100-000000-X1741",
        companyAccountFull: "1100-031741",
        lastPurchaseDate: "23/06/2026",
        daysOverdue: 0,
        cardLimit: "0.00 AED",
        mosBlockedCodes: "0 of 34 Blocked",
        atmAccess: "No",
        unpostedTransaction: { present: false },
        pastStatements: [],
        cardholderLimitSummary: { currentLimit: "10,000.00 AED", available: "10,000.00 AED" }
      },

      // S9 — POS / Mastercard network decline — Physical (no decline on eChamps)
      {
        scenarioId: "S9",
        lastFour: "6614",
        fullMasked: "5550-4100-XXXX-6614",
        fullNumber: "5550-4100-9901-6614",
        cardHolder: "Waleed Ahmed El Baz",
        expiry: "Oct-27",
        creditLimit: "20,000.00 AED",
        outstandingBalance: "9,800.00 AED",
        availableBalance: "10,200.00 AED",
        email: "waleed.elbaz@burjkhalifahtravel.ae",
        productType: "UAE Purchasing",
        status: "Active",
        statusCode: "A",
        cardBillingType: "Individually Billed",
        companyAccountMasked: "1100-000000-X1741",
        companyAccountFull: "1100-031741",
        lastPurchaseDate: "23/06/2026",
        daysOverdue: 0,
        cardLimit: "20,000.00 AED",
        mosBlockedCodes: "0 of 34 Blocked",
        atmAccess: "Yes",
        unpostedTransaction: { present: false },
        pastStatements: [
          { period: "Jun 2026", amount: "9,800.00 AED" }
        ],
        cardholderLimitSummary: { currentLimit: "20,000.00 AED", available: "10,200.00 AED" }
      },

      // One card per scenario for each demo presenter (see presenters.ts). Luhn-valid numbers
      // on the same 5550-4100 BIN, so the MiVision robot's first-eight prefix check passes.
      ...PRESENTER_CARDS
    ]
  }
];

// ─── eChamps Auth Records ─────────────────────────────────────────────────────

export const ECHAMPS_AUTHS: Record<string, EChampsAuth[]> = {
  // Keyed by card last-four, not by scenario: every card's authorisation row is present
  // at all times, so a robot reads whichever card it opened and no global scenario has to
  // be selected first. Virtual cards have unpostedTransaction.present false and no row
  // here, by design — an InControl decline never reaches the authorisation host, so the
  // evidence for those lives in SDG2_PURCHASE_REQUESTS instead.
  "9155": [
    { date: "22/06/2026", time: "14:23:00", cardNumber: "5550-4100-9901-9155", txnAmt: "1,500.00", settlementAmt: "AED 1,500.00", reasonCode: "0023", reasonDesc: "OPENTOBUY", finalAction: "Declined", authCode: "", reversalType: "DECLINED", openToBuy: "0.00 AED" }
  ],
  "3821": [
    { date: "01/07/2026", time: "22:14:01", cardNumber: "5550-4100-9901-3821", txnAmt: "2,150.00", settlementAmt: "AED 2,150.00", reasonCode: "0713", reasonDesc: "FALC DECL", finalAction: "Declined", authCode: "", reversalType: "DECLINED", openToBuy: "8,400.00 AED" }
  ],
  "7404": [
    { date: "18/06/2026", time: "10:05:00", cardNumber: "5550-4100-9901-7404", txnAmt: "450.00", settlementAmt: "AED 450.00", reasonCode: "0728", reasonDesc: "AOV EXCEED", finalAction: "Declined", authCode: "", reversalType: "DECLINED", openToBuy: "11,900.00 AED" }
  ],
  "2290": [
    { date: "20/06/2026", time: "11:30:00", cardNumber: "5550-4100-9901-2290", txnAmt: "299.00", settlementAmt: "AED 299.00", reasonCode: "0854", reasonDesc: "MID RESTR", finalAction: "Declined", authCode: "", reversalType: "DECLINED", openToBuy: "8,800.00 AED" }
  ],
  "4412": [
    { date: "21/06/2026", time: "09:45:00", cardNumber: "5550-4100-9901-4412", txnAmt: "850.00", settlementAmt: "AED 850.00", reasonCode: "0080", reasonDesc: "EXP DTE KY", finalAction: "Declined", authCode: "", reversalType: "DECLINED", openToBuy: "6,600.00 AED" }
  ],
  "8801": [
    { date: "22/06/2026", time: "13:20:00", cardNumber: "5550-4100-9901-8801", txnAmt: "620.00", settlementAmt: "AED 620.00", reasonCode: "0076", reasonDesc: "INV CVV", finalAction: "Declined", authCode: "", reversalType: "DECLINED", openToBuy: "7,900.00 AED" }
  ],
  "6614": [
    { date: "23/06/2026", time: "16:41:00", cardNumber: "5550-4100-9901-6614", txnAmt: "2,100.00", settlementAmt: "AED 2,100.00", reasonCode: "N/A", reasonDesc: "NO DECLINE RECORD", finalAction: "No Record", authCode: "", reversalType: "N/A", openToBuy: "10,200.00 AED" }
  ],

  ...PRESENTER_ECHAMPS_AUTHS
};

// ─── SDG2 ─────────────────────────────────────────────────────────────────────

// The OTP is a login challenge, not card data: it stays keyed by the session scenario
// and falls back to `default`, so any card can be investigated after any login.
export const SDG2_OTP: Record<string, string> = {
  S7: "847291",
  S8: "193045",
  default: "000000"
};

// Payment-control exceptions, one row per declined virtual card. A flat list keyed by
// nothing: the reports page shows every row and the detail page finds one by purchase
// request id, so no scenario has to be selected first.
export const SDG2_REPORTS: Sdg2Report[] = [
  {
    purchaseRequestId: "PR-2026-004412",
    virtualCardNumber: "XXXX-XXXX-XXXX-1040",
    cardholder: "Munira Al Hashimi",
    txnDate: "22/06/2026",
    merchant: "AMAZON AE",
    amount: "15,000.00",
    currency: "AED",
    status: "Declined",
    incontrolResponse: "Amount Range Control Fail",
    cardLastFour: "1040",
    minAmount: "100.00 AED",
    maxAmount: "10,000.00 AED",
    vcnExpiry: "Feb-27"
  },
  {
    purchaseRequestId: "PR-2026-004511",
    virtualCardNumber: "XXXX-XXXX-XXXX-2271",
    cardholder: "Layla Sara Khalil",
    txnDate: "23/06/2026",
    merchant: "HILTON HOTELS UAE",
    amount: "4,200.00",
    currency: "AED",
    status: "Declined",
    incontrolResponse: "Expiry Match Fail",
    cardLastFour: "2271",
    vcnExpiry: "Mar-26"
  },

  ...PRESENTER_SDG2_REPORTS
];

// ─── SDG2 Purchase Requests ───────────────────────────────────────────────────

// Keyed by purchase request id, which is what the SDG2 routes carry.
export const SDG2_PURCHASE_REQUESTS: Record<string, Sdg2PurchaseRequest> = {
  "PR-2026-004412": {
    purchaseRequestId: "PR-2026-004412",
    companyName: "Burj Khalifah Travel LLC",
    ica: "031741",
    companyAccount: "1100-000000-X1741",
    requestorName: "Munira Al Hashimi",
    requestorEmail: "munira.alhashimi@burjkhalifahtravel.ae",
    cardNumber: "XXXX-XXXX-XXXX-1040",
    cardholder: "Munira Al Hashimi",
    currency: "AED",
    status: "Active",
    createdDate: "18/06/2026",
    expiryDate: "28/06/2026",
    merchant: "AMAZON AE",
    txnAmount: "15,000.00",
    cardLastFour: "1040",
    paymentControls: {
      exactAmountRangeEnabled: true,
      minAmount: "100.00",
      maxAmount: "10,000.00",
      singleUse: true,
      currencyRestriction: "AED"
    }
  },
  "PR-2026-004511": {
    purchaseRequestId: "PR-2026-004511",
    companyName: "Burj Khalifah Travel LLC",
    ica: "031741",
    companyAccount: "1100-000000-X1741",
    requestorName: "Layla Sara Khalil",
    requestorEmail: "layla.khalil@burjkhalifahtravel.ae",
    cardNumber: "XXXX-XXXX-XXXX-2271",
    cardholder: "Layla Sara Khalil",
    currency: "AED",
    status: "Active",
    createdDate: "20/06/2026",
    expiryDate: "30/06/2026",
    merchant: "HILTON HOTELS UAE",
    txnAmount: "4,200.00",
    cardLastFour: "2271",
    vcnExpiry: "Dec-26",
    attemptedExpiry: "Mar-26",
    paymentControls: {
      exactAmountRangeEnabled: false,
      minAmount: "",
      maxAmount: "",
      singleUse: true,
      currencyRestriction: "AED"
    }
  },

  ...PRESENTER_SDG2_PURCHASE_REQUESTS
};

// ─── WHIRL ────────────────────────────────────────────────────────────────────

// Which AOV or MID table a card's programme points at, keyed by card last-four.
export const WHIRL_CARD_TABLES: Record<string, WhirlCardTable> = {
  "7404": { tableNumber: "30", org: "031", logo: "741", page: "30", tableType: "AOV" },
  "2290": { tableNumber: "36", org: "031", logo: "741", page: "36", tableType: "MID" },

  ...PRESENTER_WHIRL_CARD_TABLES
};

// AOV and MID tables belong to the programme, not to one card, so they are keyed by table
// number — every card that points at table 30 reads the same rows.
//
// Table 30 is deliberately empty: MCC 5411 (Carrefour / grocery) is NOT in the AOV table,
// which is how the agent confirms the decline came from a missing MCC override.
export const WHIRL_AOV: Record<string, Array<{
  seq: string; type: string; code: string; description: string; status: string; effectiveDate: string; expiryDate: string;
}>> = {
  "30": []
};

// ─── WHIRL MID (RRDQ) ─────────────────────────────────────────────────────────
// Table 36 starts empty: the MID is not yet added. After a card ops action it would show
// the MID entry.

export const WHIRL_MID: Record<string, Array<{
  seq: string; type: string; code: string; description: string; status: string; effectiveDate: string; expiryDate: string;
}>> = {
  "36": []
};

// ─── GHCS Solutions Center ────────────────────────────────────────────────────

// Keyed by ticket id, which is what /ghcs/ticket/:ticketId carries. Each ticket also names
// the card it was raised for, so the New Ticket form can prefill from ?card=<last four>.
export const GHCS_TICKETS: Record<string, GhcsTicket> = {
  "INC0084521": {
    ticketId: "INC0084521",
    subject: "Card transaction declined at POS — no decline record on eChamps",
    cardNumber: "5550-4100-9901-6614",
    impactedLocation: "United Arab Emirates",
    lineOfBusiness: "Commercial Banking (CMB)",
    coreApplication: "Statement/Transaction enquiries",
    issueDetails: "Physical card ending 6614 (Waleed Ahmed El Baz, Burj Khalifah Travel) was declined at Spinneys UAE on 23/06/2026 for AED 2,100. No decline record is visible on the eChamps authorisation system. Requesting investigation into a possible network-level decline.",
    status: "Escalated to Mastercard",
    resolution: "No eChamps record found. Transaction escalated to Mastercard Connect for network-level investigation.",
    createdDate: "24/06/2026",
    cardLastFour: "6614"
  },

  ...PRESENTER_GHCS_TICKETS
};

// ─── Mastercard Connect ───────────────────────────────────────────────────────

export const MC_OTP: Record<string, string> = {
  S9: "531847",
  default: "000000"
};

// A flat list: the cases page shows every case and the detail page finds one by case id.
export const MC_CASES: McCase[] = [
  {
    caseId: "MC-2026-007834",
    subject: "Transaction declined at POS — no eChamps record — card ending 6614",
    cardNumber: "5550-4100-9901-6614",
    status: "Resolved",
    category: "Transaction Investigation",
    subCategory: "POS Decline — Network",
    createdDate: "25/06/2026",
    resolvedDate: "26/06/2026",
    resolution: "Investigation confirmed the transaction was declined at the Mastercard network/acquirer level due to a temporary POS communication timeout at the merchant terminal. No card issue identified. The card is fully operational. Client may re-attempt the transaction at the same or alternative terminal.",
    cardLastFour: "6614"
  },

  ...PRESENTER_MC_CASES
];

// ─── GWIS ─────────────────────────────────────────────────────────────────────

// Scanned work items for the account. The document list filters this by the account number
// in the route, so every card under one account shares one work queue, as GWIS really does.
export const GWIS_DOCS: GwisDoc[] = [
  {
    requestNumber: "GWIS-2026-44821",
    documentType: "MID Restriction Addition Request",
    clientName: "Burj Khalifah Travel LLC",
    accountNumber: "0000110000000031741",
    submittedDate: "25/06/2026",
    scannedDate: "25/06/2026",
    status: "Scanned — Pending Card Operations",
    description: "Request to add MID-792301445 (NOON.COM UAE) to MID restriction table for card account. Signed by authorised signatories on company letterhead and submitted in branch.",
    cardLastFour: "2290"
  },

  ...PRESENTER_GWIS_DOCS
];
