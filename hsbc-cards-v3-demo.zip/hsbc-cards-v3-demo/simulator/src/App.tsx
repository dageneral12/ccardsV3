import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SimProvider } from "./context/SimContext";

import SimHome from "./home/SimHome";

import {
  DqmLogin, DqmCases, DqmCaseDetail, DqmEmail, DqmEmailDraft, DqmClient
} from "./systems/dqm";

import {
  MiVisionLogin,
  MiVisionSecurity,
  MiVisionHome,
  MiVisionSearchResults,
  MiVisionAccounts,
  MiVisionAccountsList,
  MiVisionUnposted,
  MiVisionLimitAmendment,
  MiVisionAmendCard,
  MiVisionNewCard,
  MiVisionRequests,
} from "./systems/mivision";

import {
  EChampsLogin, EChampsSearch, EChampsOverview, EChampsAccounts, EChampsCardOverview, EChampsCardInfo, EChampsAuths, EChampsBalanceDetail
} from "./systems/echamps";

import {
  Sdg2Login, Sdg2Otp, Sdg2Reports, Sdg2TxnDetail, Sdg2ViewRequests, Sdg2PurchaseRequestDetail, Sdg2EditRequest
} from "./systems/sdg2";

import {
  WhirlLogin, WhirlSearch, WhirlCard, WhirlAov, WhirlRrdq
} from "./systems/whirl";

import {
  GwisLogin, GwisSearch, GwisDocumentList, GwisDocumentView
} from "./systems/gwis";

import {
  GhcsPortal, GhcsCardsSupport, GhcsNewTicket, GhcsTicketConfirmation
} from "./systems/ghcs";

import {
  McLogin, McOtp, McCases, McNewCase, McCaseDetail
} from "./systems/mastercard";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={SimHome} />

      {/* DQM */}
      <Route path="/dqm/login" component={DqmLogin} />
      <Route path="/dqm/cases" component={DqmCases} />
      <Route path="/dqm/cases/:caseId" component={DqmCaseDetail} />
      <Route path="/dqm/cases/:caseId/email" component={DqmEmail} />
      <Route path="/dqm/cases/:caseId/email-draft" component={DqmEmailDraft} />
      <Route path="/dqm/clients/:clientId" component={DqmClient} />

      {/* MiVision — MV-01 through MV-08 */}
      <Route path="/mivision/login" component={MiVisionLogin} />
      <Route path="/mivision/security" component={MiVisionSecurity} />
      <Route path="/mivision/home" component={MiVisionHome} />
      <Route path="/mivision/search" component={MiVisionSearchResults} />
      <Route path="/mivision/accounts/:clientId" component={MiVisionAccounts} />
      <Route path="/mivision/accounts/:clientId/list" component={MiVisionAccountsList} />
      <Route path="/mivision/accounts/:clientId/unposted" component={MiVisionUnposted} />
      <Route path="/mivision/accounts/:clientId/limit-amendment" component={MiVisionLimitAmendment} />
      <Route path="/mivision/accounts/:clientId/amend/:cardLastFour" component={MiVisionAmendCard} />
      <Route path="/mivision/accounts/:clientId/new-card" component={MiVisionNewCard} />
      <Route path="/mivision/accounts/:clientId/requests" component={MiVisionRequests} />

      {/* eChamps */}
      <Route path="/echamps/login" component={EChampsLogin} />
      <Route path="/echamps/search" component={EChampsSearch} />
      <Route path="/echamps/overview/:accountNumber" component={EChampsOverview} />
      <Route path="/echamps/accounts/:accountNumber" component={EChampsAccounts} />
      <Route path="/echamps/card/:cardNumber" component={EChampsCardOverview} />
      <Route path="/echamps/card/:cardNumber/info" component={EChampsCardInfo} />
      <Route path="/echamps/card/:cardNumber/auths" component={EChampsAuths} />
      <Route path="/echamps/balance-detail" component={EChampsBalanceDetail} />

      {/* SDG2 */}
      <Route path="/sdg2/login" component={Sdg2Login} />
      <Route path="/sdg2/login/otp" component={Sdg2Otp} />
      <Route path="/sdg2/reports/payment-control" component={Sdg2Reports} />
      <Route path="/sdg2/reports/txn/:purchaseRequestId" component={Sdg2TxnDetail} />
      <Route path="/sdg2/purchase-requests" component={Sdg2ViewRequests} />
      <Route path="/sdg2/purchase-requests/:prId/edit" component={Sdg2EditRequest} />
      <Route path="/sdg2/purchase-requests/:prId" component={Sdg2PurchaseRequestDetail} />

      {/* WHIRL */}
      <Route path="/whirl/login" component={WhirlLogin} />
      <Route path="/whirl/search" component={WhirlSearch} />
      <Route path="/whirl/card/:cardNumber" component={WhirlCard} />
      <Route path="/whirl/aov/:programmeNumber" component={WhirlAov} />
      <Route path="/whirl/mid/:tableNumber" component={WhirlRrdq} />

      {/* GWIS */}
      <Route path="/gwis/login" component={GwisLogin} />
      <Route path="/gwis/search" component={GwisSearch} />
      <Route path="/gwis/documents/:accountNumber" component={GwisDocumentList} />
      <Route path="/gwis/document/:requestNumber" component={GwisDocumentView} />

      {/* GHCS Solutions Center */}
      <Route path="/ghcs/portal" component={GhcsPortal} />
      <Route path="/ghcs/cards-support" component={GhcsCardsSupport} />
      <Route path="/ghcs/new-ticket" component={GhcsNewTicket} />
      <Route path="/ghcs/ticket/:ticketId" component={GhcsTicketConfirmation} />

      {/* Mastercard Connect */}
      <Route path="/mastercard/login" component={McLogin} />
      <Route path="/mastercard/login/otp" component={McOtp} />
      <Route path="/mastercard/cases/new" component={McNewCase} />
      <Route path="/mastercard/cases/:caseId" component={McCaseDetail} />
      <Route path="/mastercard/cases" component={McCases} />

      <Route>
        <div className="p-8 text-center text-red-500">Route not found</div>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SimProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </SimProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
