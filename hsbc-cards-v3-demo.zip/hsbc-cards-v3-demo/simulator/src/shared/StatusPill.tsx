import React from 'react';

export function StatusPill({ status }: { status: string }) {
  let colors = "bg-[#F0F0F0] text-[#5C5C5C] border-[#5C5C5C]"; // grey default
  let display = "Cancel";

  if (status === "New") {
    colors = "bg-[#dbeafe] text-[#0070C0] border-[#0070C0]";
    display = "New";
  } else if (status === "In Progress" || status === "In Prog") {
    colors = "bg-[#FFF4CE] text-[#7B4F00] border-[#7B4F00]";
    display = "In Prog";
  } else if (status === "Resolved" || status === "Resolv") {
    colors = "bg-[#DFF6DD] text-[#107C10] border-[#107C10]";
    display = "Resolv";
  } else if (status === "Cancelled" || status === "Cancel") {
    colors = "bg-[#F0F0F0] text-[#5C5C5C] border-[#5C5C5C]";
    display = "Cancel";
  }

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${colors}`}>
      {display}
    </span>
  );
}
