import React from 'react';
import { Link } from 'wouter';

export function BrowserChrome({ url, children }: { url: string, children: React.ReactNode }) {
  return (
    <div className="flex flex-col min-h-screen bg-[#f5f5f5]">
      {/* Fake Browser Toolbar */}
      <div className="flex items-center px-4 h-12 bg-[#e0e0e0] border-b border-[#c0c0c0] shrink-0">
        <div className="flex items-center gap-1.5 mr-4">
          <div className="w-3 h-3 rounded-full bg-[#ff5f56]"></div>
          <div className="w-3 h-3 rounded-full bg-[#ffbd2e]"></div>
          <div className="w-3 h-3 rounded-full bg-[#27c93f]"></div>
        </div>
        
        <div className="flex items-center gap-3 text-[#595959] mr-4">
          <button onClick={() => window.history.back()} title="Back" className="hover:text-black transition-colors cursor-pointer">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
          </button>
          <button onClick={() => window.history.forward()} title="Forward" className="hover:text-black transition-colors cursor-pointer">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </button>
          <button onClick={() => window.location.reload()} title="Reload" className="hover:text-black transition-colors cursor-pointer">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
          </button>
        </div>

        <div className="flex-1 max-w-2xl mx-auto flex items-center bg-white rounded-md h-7 px-3 border border-[#c0c0c0] text-sm text-[#212121] truncate shadow-sm">
          {url}
        </div>

        <div className="ml-4 flex items-center gap-3">
          <Link
            href="/"
            className="flex items-center gap-1.5 bg-[#1a1a2e] text-white text-xs font-semibold px-3 py-1 rounded hover:bg-black transition-colors"
            data-testid="btn-simulator-home"
            title="Return to Simulator Home"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
            Simulator Home
          </Link>
          <svg width="16" height="16" viewBox="0 0 16 16">
            <polygon points="8,0 14,4 14,12 8,16 2,12 2,4" fill="#DB0011"/>
            <text x="8" y="12" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold">H</text>
          </svg>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 relative overflow-auto pb-16">
        {children}
        
        <div className="absolute bottom-4 left-0 right-0 text-center text-xs text-[#595959] pointer-events-none">
          RESTRICTED — Internal PoC use only
        </div>
      </div>
    </div>
  );
}
