import React from 'react';

export function SimHelper({ children }: { children: React.ReactNode }) {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] bg-[#fffacd] border-t-2 border-[#e6c800] px-4 py-1.5 font-mono text-xs text-[#212121] shadow-[0_-2px_10px_rgba(0,0,0,0.1)]">
      <span className="font-bold mr-2 text-[#7B4F00]">SIM HELPER — not visible to agent under test |</span>
      {children}
    </div>
  );
}
