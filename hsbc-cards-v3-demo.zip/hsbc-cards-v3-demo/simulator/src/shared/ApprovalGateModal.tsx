import React from 'react';
import { useSim } from '../context/SimContext';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

export function ApprovalGateModal({ 
  open, 
  onOpenChange, 
  system, 
  actionDesc 
}: { 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
  system: string;
  actionDesc: string;
}) {
  const { dispatch } = useSim();
  const { toast } = useToast();

  const handleAction = (event: string, actionName: string) => {
    dispatch.LOG_ACTION(system, event, actionDesc);
    toast({
      title: `${actionName} Recorded`,
      description: `The action was marked as ${actionName.toLowerCase()} in the simulation log.`,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md border-[#DB0011]">
        <DialogHeader>
          <DialogTitle className="flex items-center text-[#DB0011] gap-2">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            APPROVAL REQUIRED — {system}
          </DialogTitle>
          <DialogDescription className="text-base text-[#212121] pt-4">
            <div className="font-semibold mb-2">Proposed action:</div>
            <div className="bg-gray-100 p-3 rounded text-sm mb-4 border border-gray-200">
              {actionDesc}
            </div>
            <div className="text-sm text-gray-600 mb-1">
              <strong>Requested by:</strong> DSM Agent
            </div>
            <div className="text-sm text-gray-600">
              <strong>Awaiting approval from:</strong> Card Service Manager / Mentor
            </div>
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="sm:justify-start gap-2 mt-4">
          <Button variant="default" className="bg-[#107C10] hover:bg-[#0b5c0b]" onClick={() => handleAction('approval_granted', 'Approved')}>
            ✓ Approve
          </Button>
          <Button variant="destructive" onClick={() => handleAction('approval_rejected', 'Rejected')}>
            ✗ Reject
          </Button>
          <Button variant="outline" onClick={() => handleAction('approval_more_info', 'More Info Requested')}>
            Request more info
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
