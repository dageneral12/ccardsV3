// Guards the invariants the robots and the routes depend on. Run after editing the seed or
// adding a presenter:  node scripts/check-seed-cards.mjs
//
//   1. Every card number sits on the client's 5550-4100 BIN, which the MiVision robot checks
//      against the first eight digits quoted in the customer e-mail, and passes Luhn.
//      The nine cards seeded before presenter cards existed do not pass Luhn. Their numbers
//      are quoted verbatim in demo/send_demo_email.py, docs/test-case-catalogue.md and
//      several build notes, and changing a check digit changes the last four those files
//      key off, so they are listed in LEGACY_NON_LUHN and skipped rather than renumbered.
//      Any card added from now on must pass.
//   2. Card last-fours are unique: MiVision's expand button and the eChamps auth table are
//      both keyed by them, so a duplicate would make the wrong card open.
//   3. DQM case ids, purchase request ids, ticket ids, case ids and GWIS request numbers
//      are unique, because each one addresses a route.
//   4. Every card that should have a decline record has one, and the virtual cards do not.
//   5. demo/send_demo_email.py quotes the same presenter card numbers as presenters.ts, so
//      the e-mail a presenter sends names a card the simulator actually holds.

import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';
import { readFileSync, existsSync } from 'node:fs';

const luhnOk = (n) => {
  const d = [...n.replace(/\D/g, '')].reverse().map(Number);
  if (d.length !== 16) return false;
  const sum = d.reduce((acc, x, i) => acc + (i % 2 ? (x * 2 > 9 ? x * 2 - 9 : x * 2) : x), 0);
  return sum % 10 === 0;
};

// Seeded before the Luhn rule; see the note above. Do not add to this list.
const LEGACY_NON_LUHN = new Set(['9155', '3821', '7404', '4412', '8801', '1040', '2271']);

const fail = [];
const expect = (ok, msg) => { if (!ok) fail.push(msg); };

const dupes = (xs) => [...new Set(xs.filter((x, i) => xs.indexOf(x) !== i))];

// seed.ts is TypeScript; bundle it with the esbuild already in node_modules and import the
// result, so this runs on the project's Node without a TS loader.
const bundle = await build({
  entryPoints: [fileURLToPath(new URL('../src/data/seed.ts', import.meta.url))],
  bundle: true, format: 'esm', write: false, platform: 'neutral', logLevel: 'error'
});
const seed = await import(
  'data:text/javascript;base64,' + Buffer.from(bundle.outputFiles[0].text).toString('base64')
);
const { MIVISION_CLIENTS, DQM_CASES, ECHAMPS_AUTHS, SDG2_PURCHASE_REQUESTS, SDG2_REPORTS, GHCS_TICKETS, MC_CASES, GWIS_DOCS } = seed;

const cards = MIVISION_CLIENTS[0].cards;

const presenterBundle = await build({
  entryPoints: [fileURLToPath(new URL('../src/data/presenters.ts', import.meta.url))],
  bundle: true, format: 'esm', write: false, platform: 'neutral', logLevel: 'error'
});
const { PRESENTERS: seedPresenters } = await import(
  'data:text/javascript;base64,' + Buffer.from(presenterBundle.outputFiles[0].text).toString('base64')
);

for (const c of cards) {
  expect(LEGACY_NON_LUHN.has(c.lastFour) || luhnOk(c.fullNumber), `card ${c.fullNumber} (${c.cardHolder}) fails Luhn`);
  expect(c.fullNumber.startsWith('5550-4100'), `card ${c.fullNumber} is not on the 5550-4100 BIN`);
  expect(c.fullNumber.endsWith(c.lastFour), `card ${c.fullNumber} does not end in its lastFour ${c.lastFour}`);
  expect(c.fullMasked === `5550-4100-XXXX-${c.lastFour}`, `card ${c.lastFour} has a mismatched masked number`);
}

expect(dupes(cards.map(c => c.lastFour)).length === 0, `duplicate card last-fours: ${dupes(cards.map(c => c.lastFour))}`);
expect(dupes(DQM_CASES.map(c => c.id)).length === 0, `duplicate DQM case ids: ${dupes(DQM_CASES.map(c => c.id))}`);
expect(dupes(MC_CASES.map(c => c.caseId)).length === 0, `duplicate Mastercard case ids`);
expect(dupes(GWIS_DOCS.map(d => d.requestNumber)).length === 0, `duplicate GWIS request numbers`);
expect(dupes(SDG2_REPORTS.map(r => r.purchaseRequestId)).length === 0, `duplicate SDG2 report purchase request ids`);

for (const c of DQM_CASES) {
  expect(cards.some(x => x.lastFour === c.cardLastFour), `DQM case ${c.id} names card ${c.cardLastFour}, which no card has`);
}

for (const c of cards) {
  const virtual = c.productType.toLowerCase().includes('virtual');
  const hasAuth = Boolean(ECHAMPS_AUTHS[c.lastFour]);
  if (virtual) {
    expect(!hasAuth, `virtual card ${c.lastFour} has an eChamps row; InControl declines never reach the auth host`);
    expect(Boolean(Object.values(SDG2_PURCHASE_REQUESTS).find(p => p.cardLastFour === c.lastFour)),
      `virtual card ${c.lastFour} has no SDG2 purchase request`);
  } else {
    expect(hasAuth, `physical card ${c.lastFour} has no eChamps authorisation row`);
  }
  if (c.scenarioId === 'S9') {
    expect(Boolean(Object.values(GHCS_TICKETS).find(t => t.cardLastFour === c.lastFour)), `S9 card ${c.lastFour} has no GHCS ticket`);
    expect(MC_CASES.some(m => m.cardLastFour === c.lastFour), `S9 card ${c.lastFour} has no Mastercard case`);
  }
}

// 5. The demo mailer keeps its own copy of the presenter card numbers (it is a standalone
//    script with no TypeScript toolchain). Compare the two rather than trusting them to agree.
// The mailer lives at ../../demo-mailer/ in the distributed package and ../../demo/ in the
// source repo. Try both rather than assuming a layout.
const mailerCandidates = ['../../demo-mailer/send_demo_email.py', '../../demo/send_demo_email.py'];
let mailer = null, mailerPath = null;
for (const rel of mailerCandidates) {
  const u = new URL(rel, import.meta.url);
  if (existsSync(u)) { mailer = readFileSync(u, 'utf8'); mailerPath = rel; break; }
}
if (mailer === null) {
  console.error(`FAIL - send_demo_email.py not found. Looked for: ${mailerCandidates.join(', ')}`);
  process.exit(1);
}
for (const p of seedPresenters) {
  const re = new RegExp(`group="${p.group}",\\s*suffixes=\\[([^\\]]*)\\]`);
  const m = mailer.match(re);
  if (!m) {
    fail.push(`demo/send_demo_email.py has no entry for ${p.name} (group ${p.group})`);
    continue;
  }
  const got = [...m[1].matchAll(/"(\d{4})"/g)].map(x => x[1]);
  expect(got.join(',') === p.cardSuffixes.join(','),
    `demo/send_demo_email.py card suffixes for ${p.name} are ${got.join(',')}, presenters.ts says ${p.cardSuffixes.join(',')}`);
}

if (fail.length) {
  console.error(`FAILED (${fail.length}):`);
  for (const f of fail) console.error('  - ' + f);
  process.exit(1);
}
const luhnCards = cards.filter(c => luhnOk(c.fullNumber)).length;
console.log(`OK — ${cards.length} cards (${luhnCards} Luhn-valid, ${cards.length - luhnCards} legacy), ${DQM_CASES.length} DQM cases, ${Object.keys(ECHAMPS_AUTHS).length} eChamps auth sets, uniquely keyed, every card backed by the right system records.`);
