#!/usr/bin/env bash
# Point every inbound e-mail listener at one mail folder.
#
# Seven places must agree: the five `folderToListen` properties on the inbound connectors, and
# the two `mailFolder` inputs that feed the inline-image RPA script (it re-reads the original
# mail by message id and must look in the same folder).
#
#   scripts/set-mailbox-folder.sh INBOX
#   scripts/set-mailbox-folder.sh INBOX.2026-11-03-nikita-nt-dec-06
#
# Run from the package root, before deploying. See MESSAGE-CORRELATION.md section 4.
set -euo pipefail

if [ $# -ne 1 ]; then
    echo "usage: $0 <folder>    e.g. INBOX   or   INBOX.your-plus-tag" >&2
    exit 2
fi
NEW="$1"
cd "$(dirname "$0")/.."
[ -d process ] || { echo "run this from the package root (no ./process here)" >&2; exit 1; }

python3 - "$NEW" <<'PY'
import glob, io, re, sys
new = sys.argv[1]
total = 0
for path in sorted(glob.glob("process/*.bpmn")):
    s = io.open(path, encoding="utf-8").read()
    before = s
    s = re.sub(r'(name="data\.folderToListen" value=")[^"]*(")', lambda m: m.group(1)+new+m.group(2), s)
    s = re.sub(r'(<zeebe:input source=")[^"]*(" target="mailFolder" />)', lambda m: m.group(1)+new+m.group(2), s)
    if s != before:
        n = len(re.findall(r'name="data\.folderToListen" value="%s"' % re.escape(new), s)) \
          + len(re.findall(r'source="%s" target="mailFolder"' % re.escape(new), s))
        io.open(path, "w", encoding="utf-8").write(s)
        print("  %-44s %d reference(s)" % (path, n))
        total += n
print("updated %d reference(s) -> %s" % (total, new))
if total != 7:
    print("WARNING: expected 7, found %d. Check the models before deploying." % total)
    sys.exit(1)
PY

echo
echo "Now redeploy:  cd process && c8ctl deploy *.bpmn dmn/*.dmn forms/*.form rpa/*.rpa --profile <your-profile>"
