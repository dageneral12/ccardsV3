# How e-mail messages are correlated

Everything in this demo arrives as e-mail into **one mailbox folder**. Five inbound listeners
poll that folder, and every message must match **exactly one** of them. This document is the
reference for how that is arranged, because it is the part that breaks first when something is
changed.

---

## 1. The four subject tags

Correlation is carried in the **subject line**. Four tag shapes exist, and they are deliberately
built so that no message can match two listeners.

| Tag | Shape | Put there by | Means |
|---|---|---|---|
| `[HSBC-CARDS-V3]` | fixed literal | the human sending the first e-mail | "this is a new enquiry" |
| `[HSBC-V3-<n>]` | `<n>` = 17-digit case id | the process, on an e-mail-level notice | reply belongs to case `<n>` |
| `[HSBC-V3-<n>-<i>]` | `<i>` = request index | the process, on a per-request e-mail | reply belongs to request `<i>` of case `<n>` |
| `[HSBC-AFV3-<n>-<i>]` | as above | the process, on a fraud-team e-mail | fraud team's answer for request `<i>` |

`<n>` is the case id: `HSBC-V3-` + a 17-digit timestamp, e.g. `HSBC-V3-20261106102643139`.
One case may own several requests, so `<i>` disambiguates them: `HSBC-V3-20261106102643139-1`.

### Why the two customer tags cannot collide

`[HSBC-V3-<n>]` and `[HSBC-V3-<n>-<i>]` are matched by regexes that differ only in whether a
closing bracket follows the digits:

```
email-level   .*\[HSBC-V3-[0-9]+\].*          <- bracket immediately after the digits
per-request   .*\[HSBC-V3-[0-9]+-[0-9]+\].*   <- a second number first
```

Against `[HSBC-V3-20261106102643139-1]` the first regex needs `]` where it finds `-`, so it
fails; no amount of backtracking rescues it. **If you ever change the tag format, preserve this
property** or a single reply will activate two listeners and the case will fork.

The fraud tag starts `[HSBC-AFV3-`, which contains `HSBC-` but not `[HSBC-V3-`, so it never
matches the customer regexes. The customer listeners also carry an explicit
`not(contains(subject, "[HSBC-AFV3-"))` as a second line of defence.

---

## 2. The five listeners

| # | File | Element | Activates on | Correlation key |
|---|---|---|---|---|
| 1 | `hsbc-agentic-triage.bpmn` | `StartEvent_EmailReceived` | `[HSBC-CARDS-V3]`, no `In-Reply-To` | — (starts a case) |
| 2 | `hsbc-agentic-triage.bpmn` | `Catch_CustomerReply` | `[HSBC-V3-<n>]` | `HSBC-V3-<n>` |
| 3 | `hsbc-decline-request-agent.bpmn` | `Start_CustomerReply` | `[HSBC-V3-<n>-<i>]` | `HSBC-V3-<n>-<i>` |
| 4 | `hsbc-decline-request-agent.bpmn` | `Catch_FraudTeamResponse` | `[HSBC-AFV3-<n>-<i>]` | `HSBC-V3-<n>-<i>` |
| 5 | `hsbc-request-late-reply-wait.bpmn` | `Catch_LateReply` | `[HSBC-V3-<n>-<i>]` | `HSBC-V3-<n>-<i>` |

Listener 4 **rewrites** the tag into the request reference, so the fraud team's answer lands on
the same subscription as a customer reply would:

```feel
=replace(upper case(subject), ".*\[HSBC-AFV3-([0-9]+-[0-9]+)\].*", "HSBC-V3-$1")
```

### The start event cannot correlate, and that is not a limitation

A first enquiry has no case id — the start event is what mints one. Correlation answers
*"which running instance owns this message?"*; it cannot answer *"should an instance exist?"*.
So listener 1 uses a **filter**, not a correlation key, and that filter does negative work:

```feel
=subject != null
 and contains(upper case(subject), "[HSBC-CARDS-V3]")
 and (headers = null or is empty(headers[key = "In-Reply-To"]))   -- not a reply
 and not(contains(upper case(subject), "[HSBC-V3-"))              -- not a customer reply
 and not(contains(upper case(subject), "[HSBC-AFV3-"))            -- not a fraud reply
 and receivedDateTime != null
 and date and time(string(receivedDateTime)) > now() - duration("PT10M")
```

Without the three negative clauses every reply would *both* correlate to its case *and* start a
new one alongside it.

---

## 3. The freshness windows are not reply deadlines

Each listener ends with a `receivedDateTime > now() - duration(...)` clause:

| Listener | Window | Why |
|---|---|---|
| 1 start | `PT10M` | a stale enquiry must not open a case on redeploy |
| 2 e-mail-level reply | `PT24H` | notices can be answered next day |
| 3 per-request reply | `PT10M` | the agent is actively waiting |
| 4 fraud team | `P7D` | the fraud team is slow by design |
| 5 late reply | `PT45S` | catches a reply landing just as the case closes |

These exist because the connector is configured `pollingConfigDiscriminator = allPollingConfig`:
**every poll re-reads every message in the folder**, seen or unseen. Without a freshness clause
an old message would re-trigger on every 15-second cycle.

They are *not* a deadline for the human to answer — a reply is consumed within one poll (~15 s)
of arriving. The real deadline is the process's own `AwaitCustomerReply` SLA. The window only
bites when **delivery itself is delayed** past it, and then the message is dropped in silence:
the case simply waits until its SLA expires. That is the single most confusing failure mode in
this build, so check it first when "nothing happened".

`PT45S` on listener 5 is deliberately tight for a narrow race, but over real SMTP it is close to
a coin flip. Treat it as best-effort.

---

## 4. Which folder is polled

All five listeners poll **one folder**, set in `data.folderToListen`. It is currently:

```
INBOX.2026-11-03-nikita-nt-dec-06
```

**This is not `INBOX`, and that is deliberate.** The demo mailbox is a plus address
(`c8-saas+<tag>@mailserver.camunda-it.rocks`) on a shared server whose sieve rule files
plus-addressed mail into `INBOX.<tag>`. Mail delivered over SMTP therefore **never reaches
`INBOX`**.

This bites in a way that is very hard to diagnose, because `demo-mailer/send_demo_email.py`
appends over IMAP rather than sending, which bypasses the sieve rule entirely. A setup can
therefore pass every scripted test and still ignore every real e-mail. If you change mailbox,
run:

```
scripts/set-mailbox-folder.sh INBOX.<your-plus-tag>
```

which rewrites all **seven** places: the five `folderToListen` properties and the two
`mailFolder` inputs that feed the inline-image RPA script (it re-reads the original mail by
message id and must look in the same folder). The mailer derives its own target from
`INBOUND_MAIL_ADDRESS`, so it needs no change.

The folder is a literal because an inbound connector on a start event has no process instance
to read a variable from. A connector secret would be the alternative.

---

## 5. Deduplication across versions

Each listener sets a manual `deduplicationId` (`hsbc-v3-main-start`, `hsbc-v3-main-reply`, …).

On Camunda 8.9 the connector runtime keeps a listener active for the **latest** version of a
definition *and* for any older version that still has instances waiting on a message
subscription — which every parked case has. Older versions are therefore **not** dormant.

What stops that from double-starting cases is **cross-version deduplication**: when the inbound
configuration is byte-identical across versions, the runtime consolidates them into one
subscription. Verified on 2026-11-06 — versions 4 and 5 both `ACTIVE`, one e-mail, exactly one
case.

The practical rule:

- **Identical inbound config across versions → safe to leave old versions deployed.**
- **Changed inbound config (a tag, a folder, a condition) → old and new both listen.** Delete
  the superseded version, or accept that both are live. Deleting a version cancels its running
  instances.

`c8ctl` cannot delete a process definition; it needs
`POST {baseUrl}/v2/resources/{processDefinitionKey}/deletion`. `c8ctl list pd` does not filter
on state and keeps printing deleted rows — use `c8ctl get pd <key>` for the real state.

---

## 6. Alternatives to subject-tag correlation

Recorded because it comes up every time someone sees the tag on stage.

| Correlate on | How | Trade-off |
|---|---|---|
| **Subject tag** *(current)* | regex the tag | Survives every client and quoting style. Visible. A 17-digit id also collides with PAN detection — see the PCI note in `process/README.md` |
| **`In-Reply-To` header** | match the `messageId` the outbound send returned | No tag anywhere. **Only set when the user hits Reply** — a fresh message about the same case correlates to nothing, and the case waits in silence |
| **`References` header** | match any id in the chain | As above, survives deeper threads |
| **Plus-address reply-to** | send from `…+case-<id>@…`, read the recipient | Robust, no subject tag, no client dependence. Needs the server to accept arbitrary plus tags |
| **Body token** | regex the quoted body | Fragile: HTML mail, trimmed quotes, collapsed history |
| **Sender address** | `fromAddress` | Only works with one open case per sender — useless here |

If the tag is unwanted, the honest options are the plus-address scheme, or `In-Reply-To`
**alongside** the tag rather than instead of it. Replacing the tag outright trades a rare,
deliberate failure (someone edits the subject) for a common, accidental one (someone composes
instead of replying).
