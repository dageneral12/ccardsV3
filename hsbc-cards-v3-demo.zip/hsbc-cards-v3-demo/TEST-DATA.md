# Presenter test data — Nikita Tihhomirov and Kailash Nair

Every card, account and system record behind the two demo presenters. Generated from
`hsbc-ccs-simulator-local/src/data/presenters.ts`; regenerate rather than edit by hand.

Demonstration system. All of it is simulated data — the cardholders, the company, the
transactions and the card numbers are invented. Only the two mailboxes are real.

## Client — shared by both presenters

| Field | Value |
|---|---|
| Client name | BURJ KHALIFAH TRAVEL LLC |
| Client id (DQM / MiVision) | `BKT001` |
| Customer number | `088134520` |
| CIN | DXB 14 (United Arab Emirates) |
| Tier | GPS Premium |
| Masked account ref | `0000/BKTLME088134520` |
| Programme | BURJ KHALIFAH — UAE Corporate |
| Programme number | `031741` |
| Masked company account | `1100-000000-X1741` |
| Full company account | `0000110000000031741` |
| Programme limit | 500,000.00 AED |

Searching MiVision by any of: `Burj Khalifah Travel`, `Burj Khalifah`, `BKT`, `burj`, `088134520`.

## Nikita Tihhomirov

| Field | Value |
|---|---|
| Mailbox | `nikita.tihhomirov@camunda.com` |
| Job title (DQM External Contacts) | Marketing Manager |
| Role | Secondary PoC |
| Card number series | `5550-4100-9902-nnnn` |
| Cards held | 9 (one per scenario) |

### Cards

| Scenario | Card number | Last 4 | Expiry | Product | Credit limit | Available | Luhn |
|---|---|---|---|---|---|---|---|
| S1 Insufficient spend limit | `5550-4100-9902-1010` | `1010` | Sep-29 | UAE Purchasing | 25,000.00 AED | 0.00 AED | ✓ |
| S2 Fraud alert block | `5550-4100-9902-2026` | `2026` | Feb-29 | UAE Purchasing | 25,000.00 AED | 8,400.00 AED | ✓ |
| S3 MCC restriction | `5550-4100-9902-3032` | `3032` | Nov-28 | UAE Purchasing | 20,000.00 AED | 11,900.00 AED | ✓ |
| S4 MID restriction | `5550-4100-9902-4048` | `4048` | Mar-29 | UAE Purchasing | 15,000.00 AED | 8,800.00 AED | ✓ |
| S5 Incorrect expiry date | `5550-4100-9902-5052` | `5052` | Jul-29 | UAE Purchasing | 10,000.00 AED | 6,600.00 AED | ✓ |
| S6 Incorrect CVV | `5550-4100-9902-6068` | `6068` | Aug-29 | UAE Purchasing | 12,000.00 AED | 7,900.00 AED | ✓ |
| S7 Virtual card — amount range | `5550-4100-9902-7074` | `7074` | Feb-28 | Virtual UAE Purchasing | 0.00 AED | 0.00 AED | ✓ |
| S8 Virtual card — expiry mismatch | `5550-4100-9902-8080` | `8080` | Dec-27 | Virtual UAE Purchasing | 0.00 AED | 0.00 AED | ✓ |
| S9 POS / Mastercard network decline | `5550-4100-9902-9096` | `9096` | Oct-28 | UAE Purchasing | 20,000.00 AED | 10,200.00 AED | ✓ |

All cards: status `Active` (code `A`), Individually Billed, company account `1100-000000-X1741` / `1100-031741`, cardholder e-mail `nikita.tihhomirov@camunda.com`.

### What each card has behind it

| Scenario | Mailer command | DQM case | Declined transaction | eChamps | Other systems |
|---|---|---|---|---|---|
| S1 | `nt-s1` | `HSBC-9103999-NT01` | 22/06/2026 · GO FAST FUEL LLC · AED 1,500.00 | `0023 / OPENTOBUY` Declined | — |
| S2 | `nt-s2` | `HSBC-9103999-NT02` | 01/07/2026 · ATLAS HOTEL SINGAPORE · AED 2,150.00 | `0713 / FALC DECL` Declined | — |
| S3 | `nt-s3` | `HSBC-9103999-NT03` | 18/06/2026 · CARREFOUR UAE · AED 450.00 | `0728 / AOV EXCEED` Declined | WHIRL AOV table 30 |
| S4 | `nt-s4` | `HSBC-9103999-NT04` | 20/06/2026 · NOON.COM · AED 299.00 | `0854 / MID RESTR` Declined | WHIRL MID table 36, GWIS `GWIS-2026-44604` |
| S5 | `nt-s5` | `HSBC-9103999-NT05` | 21/06/2026 · IKEA UAE · AED 850.00 | `0080 / EXP DTE KY` Declined | — |
| S6 | `nt-s6` | `HSBC-9103999-NT06` | 22/06/2026 · EMAAR MALLS · AED 620.00 | `0076 / INV CVV` Declined | — |
| S7 | `nt-s7` | `HSBC-9095058-NT07` | — (virtual, InControl) | _no row — see SDG2_ | SDG2 `PR-2026-004607` |
| S8 | `nt-s8` | `HSBC-9095058-NT08` | — (virtual, InControl) | _no row — see SDG2_ | SDG2 `PR-2026-004608` |
| S9 | `nt-s9` | `HSBC-9103999-NT09` | 23/06/2026 · 2,100.00 AED (no unposted row) | `N/A / NO DECLINE RECORD` No Record | GHCS `INC0084609`, MC `MC-2026-074609` |

#### Virtual card payment controls

| Card | Purchase request | Min | Max | VCN expiry | Attempted expiry | InControl response |
|---|---|---|---|---|---|---|
| `7074` | `PR-2026-004607` | 100.00 | 10,000.00 | Feb-28 | — | Amount Range Control Fail |
| `8080` | `PR-2026-004608` | — | — | Dec-27 | Mar-26 | Expiry Match Fail |

## Kailash Nair

| Field | Value |
|---|---|
| Mailbox | `kailashnair@hsbc.com` |
| Job title (DQM External Contacts) | Global Head of Commercial Cards |
| Role | Secondary PoC |
| Card number series | `5550-4100-9903-nnnn` |
| Cards held | 9 (one per scenario) |

### Cards

| Scenario | Card number | Last 4 | Expiry | Product | Credit limit | Available | Luhn |
|---|---|---|---|---|---|---|---|
| S1 Insufficient spend limit | `5550-4100-9903-1019` | `1019` | Sep-29 | UAE Purchasing | 25,000.00 AED | 0.00 AED | ✓ |
| S2 Fraud alert block | `5550-4100-9903-2025` | `2025` | Feb-29 | UAE Purchasing | 25,000.00 AED | 8,400.00 AED | ✓ |
| S3 MCC restriction | `5550-4100-9903-3031` | `3031` | Nov-28 | UAE Purchasing | 20,000.00 AED | 11,900.00 AED | ✓ |
| S4 MID restriction | `5550-4100-9903-4047` | `4047` | Mar-29 | UAE Purchasing | 15,000.00 AED | 8,800.00 AED | ✓ |
| S5 Incorrect expiry date | `5550-4100-9903-5051` | `5051` | Jul-29 | UAE Purchasing | 10,000.00 AED | 6,600.00 AED | ✓ |
| S6 Incorrect CVV | `5550-4100-9903-6067` | `6067` | Aug-29 | UAE Purchasing | 12,000.00 AED | 7,900.00 AED | ✓ |
| S7 Virtual card — amount range | `5550-4100-9903-7073` | `7073` | Feb-28 | Virtual UAE Purchasing | 0.00 AED | 0.00 AED | ✓ |
| S8 Virtual card — expiry mismatch | `5550-4100-9903-8089` | `8089` | Dec-27 | Virtual UAE Purchasing | 0.00 AED | 0.00 AED | ✓ |
| S9 POS / Mastercard network decline | `5550-4100-9903-9095` | `9095` | Oct-28 | UAE Purchasing | 20,000.00 AED | 10,200.00 AED | ✓ |

All cards: status `Active` (code `A`), Individually Billed, company account `1100-000000-X1741` / `1100-031741`, cardholder e-mail `kailashnair@hsbc.com`.

### What each card has behind it

| Scenario | Mailer command | DQM case | Declined transaction | eChamps | Other systems |
|---|---|---|---|---|---|
| S1 | `kn-s1` | `HSBC-9103999-KN01` | 22/06/2026 · GO FAST FUEL LLC · AED 1,500.00 | `0023 / OPENTOBUY` Declined | — |
| S2 | `kn-s2` | `HSBC-9103999-KN02` | 01/07/2026 · ATLAS HOTEL SINGAPORE · AED 2,150.00 | `0713 / FALC DECL` Declined | — |
| S3 | `kn-s3` | `HSBC-9103999-KN03` | 18/06/2026 · CARREFOUR UAE · AED 450.00 | `0728 / AOV EXCEED` Declined | WHIRL AOV table 30 |
| S4 | `kn-s4` | `HSBC-9103999-KN04` | 20/06/2026 · NOON.COM · AED 299.00 | `0854 / MID RESTR` Declined | WHIRL MID table 36, GWIS `GWIS-2026-44704` |
| S5 | `kn-s5` | `HSBC-9103999-KN05` | 21/06/2026 · IKEA UAE · AED 850.00 | `0080 / EXP DTE KY` Declined | — |
| S6 | `kn-s6` | `HSBC-9103999-KN06` | 22/06/2026 · EMAAR MALLS · AED 620.00 | `0076 / INV CVV` Declined | — |
| S7 | `kn-s7` | `HSBC-9095058-KN07` | — (virtual, InControl) | _no row — see SDG2_ | SDG2 `PR-2026-004707` |
| S8 | `kn-s8` | `HSBC-9095058-KN08` | — (virtual, InControl) | _no row — see SDG2_ | SDG2 `PR-2026-004708` |
| S9 | `kn-s9` | `HSBC-9103999-KN09` | 23/06/2026 · 2,100.00 AED (no unposted row) | `N/A / NO DECLINE RECORD` No Record | GHCS `INC0084709`, MC `MC-2026-074709` |

#### Virtual card payment controls

| Card | Purchase request | Min | Max | VCN expiry | Attempted expiry | InControl response |
|---|---|---|---|---|---|---|
| `7073` | `PR-2026-004707` | 100.00 | 10,000.00 | Feb-28 | — | Amount Range Control Fail |
| `8089` | `PR-2026-004708` | — | — | Dec-27 | Mar-26 | Expiry Match Fail |

## Sending mail as a presenter

```
python3 demo/send_demo_email.py nt-s6 --v3     # Nikita, incorrect CVV
python3 demo/send_demo_email.py kn-s2 --v3     # Kailash, fraud block
python3 demo/send_demo_email.py reply <caseId> "Thanks, that worked." --v3 --as nt
python3 demo/send_demo_email.py fraud-reply <caseId> remove --v3
```

Serve the simulator first — the robots default to `http://localhost:8080`:

```
cd hsbc-ccs-simulator-local && npm run build && npx serve -s dist/public -l 8080
```

## Checks

`npm run check:seed` in `hsbc-ccs-simulator-local/` asserts that presenter card numbers are
Luhn-valid and on the client BIN, that last-fours and every generated id are unique, that
each physical card has an eChamps row and each virtual one an SDG2 purchase request, and
that `demo/send_demo_email.py` quotes the same card numbers as the simulator.

The nine cards seeded before the presenters do not pass Luhn. Their numbers are quoted in
demo scripts and build notes, so they are listed as legacy exceptions rather than renumbered.
