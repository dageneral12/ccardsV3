#!/usr/bin/env python3
"""Drop a demo email into the HSBC demo inbox, as if the customer (or the fraud team) had sent it.

The email is appended UNREAD to INBOX over IMAP, so the email listener picks it up within about 20 seconds.
Mailbox details are read from connectors.env (see _find_env_file) and are never printed.

Usage (from anywhere):
  python3 demo/send_demo_email.py list
  python3 demo/send_demo_email.py <scenario> [--image FILE] [--attach] [--dry-run]
  python3 demo/send_demo_email.py reply <caseId> "<reply text>" [--image FILE] [--attach]
  python3 demo/send_demo_email.py fraud-reply <caseId> keep|remove|"<free text>"

<caseId> is the HSBC-DCL-... id shown in Operate (variable caseId) or in the subject of the email the case sent.
--image adds a picture pasted into the body (inline, read by the inline-image RPA step; needs the local RPA worker);
with --attach it is a normal attachment instead (no RPA worker needed).
"""
import argparse, email.utils, imaplib, mimetypes, os, re, sys, time
from email.message import EmailMessage

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def _find_env_file():
    """First existing of: $HSBC_CONNECTORS_ENV, <root>/connectors.env,
    <root>/newcluster2/connectors.env. The last keeps the original repo layout working."""
    candidates = [os.environ.get("HSBC_CONNECTORS_ENV"),
                  os.path.join(ROOT, "connectors.env"),
                  os.path.join(ROOT, "newcluster2", "connectors.env")]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return os.path.join(ROOT, "connectors.env")   # reported in the error message


ENV_FILE = _find_env_file()
DOMAIN = "burjkhalifahtravel.ae"
JASMIN = ("Jasmin Al Rashid", "jasmin@" + DOMAIN)
SARA = ("Sara Al Hashimi", "sara@" + DOMAIN)
UNKNOWN = ("Accounts Payable", "accounts@external-sender.example")
FRAUD_TEAM = ("Card Fraud Team", "fraud-team@bank-demo.example")
SIGN_J = "\n\nKind regards,\nJasmin Al Rashid\nBurj Khalifah Travel LLC"

# simulator = scenario to select on the simulator home page before sending (eChamps data follows it)
SCENARIOS = {
    "s1-no-card": dict(
        title="S1 No card details", sender=JASMIN, simulator="S6",
        subject="[HSBC-CARDS] Corporate card declined at Emaar Malls",
        body="Hi team,\n\nOne of our corporate cards was declined at Emaar Malls on 22 June 2026 for AED 620.00. "
             "Can you tell us why?" + SIGN_J,
        expect="Missing card details: a Mentor-approved email asks for the full card number.",
        next="Reply with the card: reply <caseId> \"The card number is 5550410099018801.\""),
    "s2-incomplete-card": dict(
        title="S2 Incomplete card number", sender=SARA, simulator="S6",
        subject="[HSBC-CARDS] Company card declined",
        body="Hello,\n\nOur card 5550 4100 9901 was declined at Emaar Malls on 22 June 2026 for AED 620.00. "
             "Please advise.\n\nKind regards,\nSara Al Hashimi\nBurj Khalifah Travel LLC",
        expect="Incomplete card number: a Mentor-approved email asks for all 16 digits.",
        next="Reply: reply <caseId> \"The full card number is 5550410099018801.\" -> CVV advice -> RESOLVED"),
    "s3-other-company": dict(
        title="S3 Card of a different company", sender=JASMIN, simulator="S6",
        subject="[HSBC-CARDS] Company card declined",
        body="Hello,\n\nOur card 4111 1111 1111 1111 was declined at Emaar Malls on 22 June 2026 for AED 620.00. "
             "Can you help?" + SIGN_J,
        expect="Card not found for this client: a Mentor-approved email asks the customer to check the card.",
        next="Do nothing to show CLOSED_NO_RESPONSE after customerReplySla (P3D on email starts), or reply with 5550410099018801."),
    "s4-cvv": dict(
        title="S4 Incorrect CVV", sender=JASMIN, simulator="S6",
        subject="[HSBC-CARDS] Card declined at Emaar Malls",
        body="Hello,\n\nOur card 5550410099018801 was declined at Emaar Malls on 22 June 2026 for AED 620.00. "
             "Could you tell us why?" + SIGN_J,
        expect="eChamps decline 0076 (CVV): Mentor approves the CVV retry advice -> RESOLVED.",
        next="Approve the Mentor task in Tasklist; the customer email arrives in your mailbox (demo redirect)."),
    "s5-unauthorised": dict(
        title="S5 Unauthorised sender", sender=UNKNOWN, simulator="S6",
        subject="[HSBC-CARDS] Declined card",
        body="Hi,\n\nCard 5550410099018801 of Burj Khalifah Travel was declined at Emaar Malls on 22 June 2026 "
             "for AED 620.00. Please unblock it.\n\nThanks,\nAccounts Payable",
        expect="UNAUTHORISED_SENDER: a notice goes to the authorised contact (Jasmin); no card data is asked from the sender.",
        next="Approve the Mentor task. (Sending from your own mailbox gives the same route.)"),
    "s6-fraud": dict(
        title="S6 Fraud alert", sender=JASMIN, simulator="S2",
        subject="[HSBC-CARDS] Card declined overseas",
        body="Hello,\n\nOur card 5550410099013821 was declined at Atlas Hotel Singapore on 1 July 2026 for AED 2,150.00. "
             "Please check urgently." + SIGN_J,
        expect="eChamps 0713 FALC: email to the fraud team tagged [HSBC-FRD-n], then the case waits.",
        next="Reply to the fraud email from your mailbox (keep the subject), or: fraud-reply <caseId> keep|remove"),
    "s7-two-requests": dict(
        title="S7 Two requests in one email", sender=JASMIN, simulator="S6",
        subject="[HSBC-CARDS] Two cards declined",
        body="Hello,\n\nTwo of our company cards were declined. Card 5550410099018801 was declined at Emaar Malls on "
             "22 June 2026 for AED 620.00. Separately, card 5550410099013821 was declined at Atlas Hotel Singapore on "
             "1 July 2026 for AED 2,150.00. Please help with both." + SIGN_J,
        expect="Guardrail: two requests -> escalation task for a person (rule 18); no customer email.",
        next="Open the escalation task in Tasklist."),
    "screenshot": dict(
        title="Screenshot only (inline image)", sender=JASMIN, simulator="S6", image="emailImage/HSBC Mobile Banking Transaction Declined.png",
        subject="[HSBC-CARDS] Card declined - see screenshot",
        body="Hi team,\n\nOne of our cards was declined, see the screenshot from the app below. Could you tell us why?" + SIGN_J,
        expect="The agent reads card, amount and merchant from the screenshot. This screenshot has no date and does not "
               "match the simulator, so the case asks for the missing details.",
        next="Needs the local RPA worker running. Reply with the date, or use a screenshot showing AED 620.00 / Emaar Malls / 22/06/2026."),
}


# ─── Presenter cards ──────────────────────────────────────────────────────────
# The people who present the demo hold their own cards under Burj Khalifah Travel, one per
# scenario, so an email can come from a real mailbox about a card in that person's own name.
# Source of truth is hsbc-ccs-simulator-local/src/data/presenters.ts; the simulator's
# `npm run check:seed` fails if the two drift apart.
PRESENTERS = [
    dict(initials="nt", name="Nikita Tihhomirov", email="nikita.tihhomirov@camunda.com",
         group="9902", suffixes=["1010", "2026", "3032", "4048", "5052", "6068", "7074", "8080", "9096"]),
    dict(initials="kn", name="Kailash Nair", email="kailashnair@hsbc.com",
         group="9903", suffixes=["1019", "2025", "3031", "4047", "5051", "6067", "7073", "8089", "9095"]),
]

# One entry per scenario, in the same order as `suffixes` above (S1..S9).
PRESENTER_SCENARIOS = [
    dict(key="s1", title="S1 Insufficient spend limit", merchant="Go Fast Fuel", date="22 June 2026", amount="AED 1,500.00",
         expect="eChamps 0023 OPENTOBUY: the card is at its limit. Mentor approves the explanation.",
         next="Approve the Mentor task in Tasklist."),
    dict(key="s2", title="S2 Fraud alert block", merchant="Atlas Hotel Singapore", date="1 July 2026", amount="AED 2,150.00",
         expect="eChamps 0713 FALC: email to the fraud team tagged [HSBC-AFV3-n], then the case waits.",
         next='Reply as the fraud team: fraud-reply <caseId> keep|remove --v3'),
    dict(key="s3", title="S3 MCC restriction", merchant="Carrefour UAE", date="18 June 2026", amount="AED 450.00",
         expect="eChamps 0728 AOV EXCEED: the merchant category is not on the card's AOV table.",
         next="Approve the Mentor task; WHIRL table 30 is the human follow-up."),
    dict(key="s4", title="S4 MID restriction", merchant="Noon.com", date="20 June 2026", amount="AED 299.00",
         expect="eChamps 0854 MID RESTR: the merchant id is not on the card's MID table.",
         next="Approve the Mentor task; WHIRL table 36 and the GWIS request are the human follow-up."),
    dict(key="s5", title="S5 Incorrect expiry date", merchant="IKEA UAE", date="21 June 2026", amount="AED 850.00",
         expect="eChamps 0080 EXP DTE KY: the expiry keyed at the till was wrong.",
         next="Approve the Mentor task; the reply quotes the card's real expiry."),
    dict(key="s6", title="S6 Incorrect CVV", merchant="Emaar Malls", date="22 June 2026", amount="AED 620.00",
         expect="eChamps 0076 INV CVV: Mentor approves the CVV retry advice -> RESOLVED.",
         next="Approve the Mentor task; the customer email arrives in your mailbox (demo redirect)."),
    dict(key="s7", title="S7 Virtual card amount range", merchant="Amazon AE", date="22 June 2026", amount="AED 15,000.00",
         expect="No eChamps row (InControl decline). The amount is outside the purchase request's 100-10,000 range.",
         next="SDG2 holds the purchase request; the agent explains the control."),
    dict(key="s8", title="S8 Virtual card expiry mismatch", merchant="Hilton Hotels UAE", date="23 June 2026", amount="AED 4,200.00",
         expect="No eChamps row. SDG2 shows an Expiry Match Fail against the virtual card.",
         next="Approve the Mentor task; the reply quotes the card's real expiry."),
    dict(key="s9", title="S9 POS / Mastercard network decline", merchant="Spinneys UAE", date="23 June 2026", amount="AED 2,100.00",
         expect="eChamps holds NO DECLINE RECORD, so the trail runs on to GHCS and Mastercard Connect.",
         next="The GHCS ticket and the Mastercard case for this card are already in the simulator."),
]


def _presenter_scenarios():
    """nt-s1 .. nt-s9 and kn-s1 .. kn-s9: the same nine scenarios, sent from a presenter's own
    mailbox about a card in their own name."""
    out = {}
    for p in PRESENTERS:
        for sc, last4 in zip(PRESENTER_SCENARIOS, p["suffixes"]):
            pan = "5550 4100 %s %s" % (p["group"], last4)
            sign = "\n\nKind regards,\n%s\nBurj Khalifah Travel LLC" % p["name"]
            out["%s-%s" % (p["initials"], sc["key"])] = dict(
                title="%s (%s)" % (sc["title"], p["name"]),
                sender=(p["name"], p["email"]),
                simulator="-",
                subject="[HSBC-CARDS] Card declined at %s" % sc["merchant"],
                body="Hello,\n\nMy card %s was declined at %s on %s for %s. Could you tell me why?%s"
                     % (pan, sc["merchant"], sc["date"], sc["amount"], sign),
                expect=sc["expect"],
                next=sc["next"])
    return out


SCENARIOS.update(_presenter_scenarios())


def load_env(required=True):
    """Read connectors.env. With required=False (a dry run) a missing file is not fatal,
    so scenarios can be previewed before any mailbox is configured."""
    env = {}
    if not os.path.exists(ENV_FILE):
        if not required:
            return {"INBOUND_MAIL_ADDRESS": "(dry run - connectors.env not configured)"}
        sys.exit("connectors.env not found. Looked for %s. Copy connectors.env.example and fill it in."
                 % ENV_FILE)
    with open(ENV_FILE) as f:
        for line in f:
            m = re.match(r"\s*(?:export\s+)?(\w+)=['\"]?(.*?)['\"]?\s*$", line)
            if m:
                env[m.group(1)] = m.group(2)
    missing = [k for k in ("INBOUND_MAIL_ADDRESS", "INBOUND_MAIL_SERVER", "INBOUND_MAIL_USER", "INBOUND_MAIL_PASSWORD") if not env.get(k)]
    if missing and required:
        sys.exit("connectors.env (%s) is missing: %s" % (ENV_FILE, ", ".join(missing)))
    return env


def case_number(case_id):
    m = re.search(r"(\d{6,})", case_id)
    if not m:
        sys.exit("caseId should look like HSBC-DCL-20261030095031743")
    return m.group(1)


# Agentic build profiles. Each build owns its own subject tags so v2 and v3 can be
# deployed at the same time without one build's mail reaching the other's listeners.
PROFILES = {
    "v2": dict(intake="[HSBC-CARDS-AI]", req="HSBC-AGT", fraud="HSBC-AFR",
               triage="HSBC_Scenario_Triage"),
    "v3": dict(intake="[HSBC-CARDS-V3]", req="HSBC-V3", fraud="HSBC-AFV3",
               triage=None),
}


def agentic_tag(case_id, prefix="HSBC-AGT"):
    """Agentic subject tag. Accepts a full tag (<prefix>-<n>-<i>), a case id (<prefix>-<n>) or bare digits.
    A request-level tag needs the -<i> suffix; it defaults to -1 (the first request of the email)."""
    m = re.search(r"(\d{6,})(?:-(\d+))?", case_id)
    if not m:
        sys.exit("caseId should look like %s-20261104220404131 or %s-20261104220404131-1" % (prefix, prefix))
    return "%s-%s-%s" % (prefix, m.group(1), m.group(2) or "1")


def build(env, sender, subject, body, image=None, attach=False, in_reply_to=None):
    msg = EmailMessage()
    msg["From"] = email.utils.formataddr(sender)
    msg["To"] = env["INBOUND_MAIL_ADDRESS"]
    msg["Subject"] = subject
    msg["Date"] = email.utils.formatdate(localtime=False)
    msg["Message-ID"] = email.utils.make_msgid(idstring="demo%d" % int(time.time()), domain=sender[1].split("@")[1])
    if in_reply_to:
        msg["In-Reply-To"] = in_reply_to
    msg.set_content(body)
    if image:
        path = image if os.path.isabs(image) else os.path.join(ROOT, image)
        data = open(path, "rb").read()
        ctype = mimetypes.guess_type(path)[0] or "image/png"
        maintype, subtype = ctype.split("/", 1)
        fname = re.sub(r"[^A-Za-z0-9._-]", "_", os.path.basename(path))
        if attach:
            msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=fname)
        else:
            cid = email.utils.make_msgid(domain=sender[1].split("@")[1])
            html = "".join("<p>%s</p>" % p.replace("\n", "<br>") for p in body.split("\n\n"))
            parts = html.split("</p>", 1)  # picture after the first paragraph, like a pasted screenshot
            html = parts[0] + "</p><p><img src=\"cid:%s\" width=\"320\"></p>" % cid[1:-1] + (parts[1] if len(parts) > 1 else "")
            msg.add_alternative(html, subtype="html")
            msg.get_payload()[1].add_related(data, maintype=maintype, subtype=subtype, cid=cid, filename=fname, disposition="inline")
    return msg


def mail_folder(env):
    """The folder the inbound connectors poll: INBOX.<plus tag> for a plus-addressed mailbox.

    A real SMTP delivery to c8-saas+TAG@host is sieve-filed into INBOX.TAG, so that is where
    the connectors listen. A scripted append has to land in the same place.
    """
    local = env["INBOUND_MAIL_ADDRESS"].split("@", 1)[0]
    if "+" in local:
        return "INBOX." + local.split("+", 1)[1]
    return "INBOX"


def deliver(env, msg, dry_run):
    if dry_run:
        print("--- dry run, not sent ---")
        print("From: %s\nSubject: %s\n\n%s" % (msg["From"], msg["Subject"], (msg.get_body(("plain",)) or msg).get_content()))
        return
    imap = imaplib.IMAP4_SSL(env["INBOUND_MAIL_SERVER"], int(env.get("INBOUND_MAIL_IMAP_PORT") or 993))
    try:
        imap.login(env["INBOUND_MAIL_USER"], env["INBOUND_MAIL_PASSWORD"])
        # The mail server files plus-addressed mail into INBOX.<plus tag>, and that is the
        # folder the inbound connectors poll. Appending to INBOX instead would put scripted
        # mail somewhere nothing listens. Derived from the address so the two cannot drift.
        folder = mail_folder(env)
        status, _ = imap.append(folder, None, imaplib.Time2Internaldate(time.time()), msg.as_bytes())  # no \Seen flag: stays unread
    finally:
        try:
            imap.logout()
        except Exception:
            pass
    if status != "OK":
        sys.exit("IMAP append failed: " + status)
    print("Delivered to %s (unread): %s\n  From: %s" % (folder, msg["Subject"], msg["From"]))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", help="list | <scenario> | reply | fraud-reply")
    ap.add_argument("args", nargs="*")
    ap.add_argument("--image", help="picture to include (default: the scenario's own, if any)")
    ap.add_argument("--attach", action="store_true", help="send the picture as a normal attachment instead of inline")
    ap.add_argument("--dry-run", action="store_true", help="print the email instead of delivering it")
    ap.add_argument("--as", dest="as_who", metavar="WHO",
                    help="send a reply as a presenter instead of Jasmin: " + "|".join(p["initials"] for p in PRESENTERS))
    ap.add_argument("--v2", action="store_true",
                    help="target the v2 agentic process: intake tag [HSBC-CARDS-AI], replies [HSBC-AGT-n-i], fraud [HSBC-AFR-n-i]")
    ap.add_argument("--v3", action="store_true",
                    help="target the v3 agentic process: intake tag [HSBC-CARDS-V3], replies [HSBC-V3-n-i], fraud [HSBC-AFV3-n-i]")
    a = ap.parse_args()
    if a.v2 and a.v3:
        sys.exit("Pick one of --v2 or --v3, not both.")
    prof = PROFILES["v3"] if a.v3 else (PROFILES["v2"] if a.v2 else None)
    replier, replier_sign = JASMIN, SIGN_J
    if a.as_who:
        who = next((p for p in PRESENTERS if p["initials"] == a.as_who.lower()), None)
        if not who:
            sys.exit("Unknown --as '%s'. One of: %s" % (a.as_who, ", ".join(p["initials"] for p in PRESENTERS)))
        replier = (who["name"], who["email"])
        replier_sign = "\n\nKind regards,\n%s\nBurj Khalifah Travel LLC" % who["name"]

    if a.command == "list":
        for key, s in SCENARIOS.items():
            print("%-20s %-52s simulator %s  from %s" % (key, s["title"], s["simulator"], s["sender"][1]))
        return

    env = load_env(required=not a.dry_run)
    if a.command == "reply":
        if len(a.args) != 2:
            sys.exit('usage: reply <caseId> "<reply text>"')
        if prof:
            tag = agentic_tag(a.args[0], prof["req"])
            # No In-Reply-To: the request agent's listener matches on the subject tag alone.
            msg = build(env, replier, "RE: Your declined card enquiry [%s]" % tag, a.args[1] + replier_sign, a.image, a.attach)
            deliver(env, msg, a.dry_run)
            print("The request agent picks the reply up and continues the same conversation.")
            return
        n = case_number(a.args[0])
        msg = build(env, replier, "RE: [HSBC-CARDS] Card declined [HSBC-DCL-%s]" % n, a.args[1] + replier_sign,
                    a.image, a.attach, in_reply_to="<case-HSBC-DCL-%s@demo>" % n)
        deliver(env, msg, a.dry_run)
        print("The case re-triages with the reply within about a minute.")
        return

    if a.command == "fraud-reply":
        if len(a.args) != 2:
            sys.exit("usage: fraud-reply <caseId> keep|remove|\"<free text>\"")
        n = case_number(a.args[0])
        text = {"keep": "The card must stay blocked and be reissued: the card details appear to have been exposed.",
                "remove": "Block removed. The transaction is genuine and the card can be used again."}.get(a.args[1].lower(), a.args[1])
        if prof:
            msg = build(env, FRAUD_TEAM, "RE: Fraud review needed [%s]" % agentic_tag(a.args[0], prof["fraud"]),
                        text + "\n\nRegards,\nCard Fraud Team")
            deliver(env, msg, a.dry_run)
            print("The fraud tool interprets the reply, then a Mentor task prepares the customer email.")
            return
        msg = build(env, FRAUD_TEAM, "RE: Fraud review needed [HSBC-FRD-%s]" % n,
                    text + "\n\nRegards,\nCard Fraud Team", in_reply_to="<fraud-HSBC-FRD-%s@demo>" % n)
        deliver(env, msg, a.dry_run)
        print("The fraud process interprets the reply, then a Mentor task prepares the customer email.")
        return

    s = SCENARIOS.get(a.command)
    if not s:
        sys.exit("Unknown scenario '%s'. Run: python3 demo/send_demo_email.py list" % a.command)
    if prof and prof["triage"]:
        print("%s\n  %s: %s selects the simulator dataset itself; no manual selection needed."
              % (s["title"], "v3" if a.v3 else "v2", prof["triage"]))
    elif prof:
        print("%s\n  v3: no scenario anywhere. Every card's records are always present and each page\n"
              "      is addressed by card or account. Make sure the local simulator build is served\n"
              "      on http://localhost:8080 - that is where the robots look by default."
              % s["title"])
    else:
        print("%s\n  Before sending: select simulator scenario %s on the simulator home page." % (s["title"], s["simulator"]))
    subject = s["subject"].replace("[HSBC-CARDS]", prof["intake"]) if prof else s["subject"]
    msg = build(env, s["sender"], subject, s["body"], a.image or s.get("image"), a.attach)
    deliver(env, msg, a.dry_run)
    print("  Expect: %s\n  Next:   %s" % (s["expect"], s["next"]))


if __name__ == "__main__":
    main()
