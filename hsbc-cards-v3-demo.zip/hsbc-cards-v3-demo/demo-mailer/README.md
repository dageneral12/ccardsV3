# Demo emails

One command per scenario. Each script drops an email, unread, into the demo inbox, as if the customer had sent it. The email listener starts the case within about 20 seconds. Mailbox details come from `connectors.env` (package root; see `connectors.env.example`) and are never printed. The script **appends over IMAP** rather than sending over SMTP, so it writes straight into the folder the connectors poll — which also means it bypasses any server-side filing rule a real e-mail would go through. See `MESSAGE-CORRELATION.md` section 4.

Add `--v3` to target the v3 agentic build (subject tag `[HSBC-CARDS-V3]`, replies `[HSBC-V3-n-i]`, fraud `[HSBC-AFV3-n-i]`), or `--v2` for v2. With `--v3` nothing has to be selected on the simulator home page: every record is reached from the card or account named in the e-mail. Serve the local build first — `cd hsbc-ccs-simulator-local && npm run build && npx serve -s dist/public -l 8080` — because that is where the v3 robots look by default.

Without `--v3`, select the matching scenario on the simulator home page first: `S2` for the fraud case, `S6` for all others.

| Command | Scenario | Simulator | Expected outcome |
|---|---|---|---|
| `demo/s1-no-card.sh` | S1 no card details | S6 | Email asks for the card number |
| `demo/s2-incomplete-card.sh` | S2 incomplete card number | S6 | Email asks for all 16 digits |
| `demo/s3-other-company.sh` | S3 card of another company | S6 | Email asks the customer to check the card |
| `demo/s4-cvv.sh` | S4 incorrect CVV | S6 | CVV retry advice, then RESOLVED |
| `demo/s5-unauthorised.sh` | S5 unauthorised sender | S6 | Notice to the authorised contact |
| `demo/s6-fraud.sh` | S6 fraud alert | S2 | Email to the fraud team; the case waits |
| `demo/s7-two-requests.sh` | S7 two requests in one email | S6 | Escalation task, no customer email |
| `demo/screenshot.sh` | Pasted screenshot only | S6 | Agent reads the image (needs the local RPA worker) |

## Sending as yourself

Each presenter holds their own cards under Burj Khalifah Travel — one per scenario, in their own name — so the e-mail comes from a real mailbox about a card the simulator really holds, and the robots read that person's name back off the screens.

| Command | Sent from | Scenario |
|---|---|---|
| `python3 demo/send_demo_email.py nt-s1 --v3` … `nt-s9` | `nikita.tihhomirov@camunda.com` | S1–S9 on Nikita Tihhomirov's own cards |
| `python3 demo/send_demo_email.py kn-s1 --v3` … `kn-s9` | `kailashnair@hsbc.com` | S1–S9 on Kailash Nair's own cards |

`python3 demo/send_demo_email.py list` prints all of them with the mailbox each one sends from. The card numbers are on the simulator home page under **Demo Cards** and in `process-v3/README.md`.

Add `--as nt` or `--as kn` to `reply` to send the customer reply from that mailbox instead of Jasmin's.

Follow-ups:

- `demo/reply.sh <caseId> "<text>"` sends a customer reply as Jasmin. Example: `demo/reply.sh HSBC-DCL-20261030095031743 "The full card number is 5550410099018801."`
- `demo/fraud-reply.sh <caseId> keep|remove` sends a fraud team reply. You can also pass your own text in quotes instead of `keep` or `remove`.

Options for any command:

- `--dry-run` prints the email instead of sending it.
- `--image FILE` adds a picture pasted into the body.
- `--attach` sends that picture as a normal attachment instead.

To list all scenarios, run `python3 demo/send_demo_email.py list`.

Notes:

- **Where outbound email goes:** demo mode sends every outbound email, including the fraud team email, to the `demoEmailRedirect` address.
- **Replying from a mail client:** you can reply straight from your mail client instead of using `reply.sh` or `fraud-reply.sh`. Keep the `[HSBC-DCL-n]` or `[HSBC-FRD-n]` tag in the subject. In demo mode, replies are accepted from any sender.
- **Read emails are skipped:** the listener only picks up unread mail. Don't open the demo inbox in a mail client while presenting.
- **Your own address:** an address listed in the client's External Contacts table is recognised, and anything else starts the S5 unauthorised-sender route. `nikita.tihhomirov@camunda.com` and `kailashnair@hsbc.com` are listed; to add a colleague, edit `PRESENTERS` in `hsbc-ccs-simulator-local/src/data/presenters.ts`, mirror the entry in `send_demo_email.py`, run `npm run check:seed`, then rebuild and re-serve the simulator.
