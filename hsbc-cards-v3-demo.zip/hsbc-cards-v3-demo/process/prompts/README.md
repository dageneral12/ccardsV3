# Extracted AI prompts

Verbatim copies of the prompts configured on the AI agent connectors, for review.
**These files are documentation only** - the live values are the ioMapping inputs in the BPMN.

| Element | Model file | System prompt | User prompt |
|---|---|---|---|
| `Task_DraftCommunication` | `hsbc-customer-communication-agentic.bpmn` | 2711 chars | 2105 chars |
| `RequestAgent` | `hsbc-decline-request-agent.bpmn` | 11251 chars | 91 chars |
| `Task_TranscribeReplyAttachments` | `hsbc-decline-request-agent.bpmn` | 557 chars | 166 chars |
| `Task_ExtractEmail` | `hsbc-email-intake.bpmn` | 4250 chars | 1206 chars |
| `Task_InterpretFraudReply` | `hsbc-tool-interpret-fraud-reply.bpmn` | 1312 chars | 798 chars |
