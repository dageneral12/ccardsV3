# process-v3

A full, independent copy of `process-v2`, created on 2026-11-05. Every deployable
identifier is suffixed so **v2 and v3 can be deployed to the same cluster at the same
time** and demoed independently. Nothing here shares state with v2.

**v3 drops the simulator scenario plumbing.** The simulator is now card-addressed, so
nothing has to choose a dataset before the robots run. See "Scenario plumbing removed"
below and `retired/README.md`.

## Identifier mapping

| Kind | v2 | v3 |
|---|---|---|
| Processes | `HSBC_Commercial_Cards_Agentic_Triage` | `…_V3` (all 8 processes) |
| Decisions | `SimulatorScenarioFromCard` | `SimulatorScenarioFromCard_V3` |
| | `CustomerResponseTypeV2` | `CustomerResponseType_V3` |
| | `MentorApprovalDecisionV2` | `MentorApprovalDecision_V3` |
| | `TriageRoutingV2` | `TriageRouting_V3` |
| Forms | `hsbc-mentor-approval-v2` | `hsbc-mentor-approval-v3` |
| | `hsbc-escalation-review` | `hsbc-escalation-review-v3` (and the other three) |
| RPA resources | `RPA_0daw5hw` / `EChampsDeclineInvestigation` | `RPA_0daw5hw_V3` / `EChampsDeclineInvestigationV3` |
| Messages | `hsbc-agt-customer-reply` | `hsbc-v3-customer-reply` (all 5) |
| Connector dedup ids | `hsbc-agt-main-start` | `hsbc-v3-main-start` (all 5) |
| Intake subject tag | `[HSBC-CARDS-AI]` | `[HSBC-CARDS-V3]` |
| Case / request tag | `[HSBC-AGT-<n>-<i>]` | `[HSBC-V3-<n>-<i>]` |
| Fraud-team tag | `[HSBC-AFR-<n>-<i>]` | `[HSBC-AFV3-<n>-<i>]` |

The three `…V2` decisions were renamed to plain `…_V3` rather than `…V2_V3`.
The `-v2` suffixed DMN and form **filenames** were renamed to `-v3` to match.

## Why the dedup ids and message names had to change

Each inbound Email connector carries a `deduplicationId`. Two connector definitions
that share one are treated as a **single subscription**, so leaving v2's values in
place would have made v3's listeners collapse into v2's and silently stop receiving
mail. Message names are cluster-wide, so those are separated for the same reason.
This is the part that makes side-by-side deployment actually work; the process-id
rename alone would not have been enough.

## Folder contents

| Path | What it is | Deployed? |
|---|---|---|
| `*.bpmn` (8) | the processes | yes |
| `dmn/*.dmn` (11) | the decisions | yes |
| `forms/*.form` (5) | the user-task forms | yes |
| `rpa/*.rpa` (4) | **the robots this build runs**, ids suffixed `_V3` | yes |
| `rpaScripts/*.rpa` (3) | the untouched 27 Oct originals, kept as selector reference | **no — see its README** |
| `BUILD-NOTES.md` | inherited v2 build notes | n/a |

`rpaScripts/` carries the original **unsuffixed** ids, which are the ids v2's live RPA
resources use. Deploying from it would publish an older script over v2's robot. The
deploy command below globs `rpa/*.rpa` and does not reach it — do not widen that glob.


## Scenario plumbing removed

In v2 the simulator held one globally selected scenario and served only that scenario's
records, so `HSBC_Scenario_Triage` had to decide the dataset and every robot had to select
it in its own browser. That whole mechanism is gone.

**Simulator** (`hsbc-ccs-simulator-local/`)

| Change | File |
|---|---|
| `ECHAMPS_AUTHS` re-keyed from `"S1".."S9"` to card last-four (`"9155"`, `"3821"`, …) | `src/data/seed.ts` |
| Card Auths page reads the card in its own URL instead of the selected scenario | `src/systems/echamps/index.tsx` |
| Balance Detail falls back to the card last opened | `src/systems/echamps/index.tsx` |
| MiVision unposted list no longer filtered to one scenario's card | `src/systems/mivision/index.tsx` |
| Presenter mailboxes added as authorised contacts | `src/data/seed.ts` |
| `SDG2_REPORTS` and `MC_CASES` flattened to lists; `SDG2_PURCHASE_REQUESTS` keyed by request id, `GHCS_TICKETS` by ticket id | `src/data/seed.ts` |
| `WHIRL_CARD_AOV` → `WHIRL_CARD_TABLES` keyed by card last-four; `WHIRL_AOV` / `WHIRL_MID` keyed by table number | `src/data/seed.ts` |
| `GWIS_DATA` → `GWIS_DOCS`, one work queue filtered by account number | `src/data/seed.ts` |
| SDG2, GHCS, Mastercard, WHIRL and GWIS pages resolve their record from the route (or `?card=`) instead of the selector | `src/systems/{sdg2,ghcs,mastercard,whirl,gwis}/index.tsx` |
| MiVision Requests tab and DQM row highlight follow the card last opened | `src/systems/{mivision,dqm}/index.tsx` |

The MiVision card list, the eChamps account card list and all DQM cases were
**already** unfiltered — no change was needed there.

**Robots** (`rpa/*.rpa`) — `Open Simulator And Launch` now opens the system login
directly. The `simulatorScenario` input, the `SIM_SCENARIO` variable and the scenario
evidence are gone from all three. MFA is untouched: MiVision's security-number
challenge, SDG2 and Mastercard OTPs all still run.

**Processes** — removed `CallActivity_ScenarioTriage` (main), `BRT_ScenarioRefresh`
(investigate tool), and every `simulatorScenario` input, output and init field.
`HSBC_Scenario_Triage_V3` and `SimulatorScenarioFromCard_V3` moved to `retired/`.

### What the selector on the simulator home page does now

Nothing to do with data. Every record in every one of the eight systems is reached from
the card, account, request, ticket or case id in front of it. The control at the bottom of
the simulator home page is labelled **MFA code set** and picks only the SDG2 and Mastercard
Connect demo OTPs, which are login challenges rather than card records.

Run `npm run check:seed` in `hsbc-ccs-simulator-local/` to assert the invariants this
relies on: every card number on the client's BIN and (presenter cards) Luhn-valid, card
last-fours and every generated id unique, each physical card carrying an eChamps row and
each virtual card an SDG2 purchase request instead, and `demo/send_demo_email.py` quoting
the same card numbers as the simulator.

### Where the robots look for the simulator

The robots default to **`http://localhost:8080`** — the locally served build of
`hsbc-ccs-simulator-local`. The hosted build at `https://atlas-simulator.replit.app` does
**not** contain the v3 simulator changes, so it is no longer the default: a mail-started
case can pass no variables at all, and would otherwise read the wrong data silently.

Serve the build before running anything:

```
cd hsbc-ccs-simulator-local && npm run build && npx serve -s dist/public -l 8080
```

To point the robots elsewhere, set the process variable `simulatorBaseUrl` at start, or on
a running instance:

```
c8ctl create pi --id HSBC_Commercial_Cards_Agentic_Triage_V3 \
  --variables '{"simulatorBaseUrl":"https://atlas-simulator.replit.app"}' --profile hsbc-cards
```

It propagates through every call activity and reaches all six RPA tasks. Blank or absent
falls back to `http://localhost:8080`. Each robot records the URL it actually used in
`<system>Result.evidence.simulatorBaseUrl`, so a wrong target is visible in the variables
rather than silent.

## Emailing the agent as a customer

Sender authorisation is decided from the DQM **External Contacts** table: the DQM robot
scrapes `authorised-contact-row-*`, and intake matches the From address against the email
column, case-insensitively. An address that is not listed routes to `UNAUTHORISED_SENDER`
and the reply goes to the primary contact instead of the sender.

Authorised addresses include the presenters' real mailboxes alongside the five fictional
Burj Khalifah Travel contacts:

| Name | Mailbox | Job title in DQM |
|---|---|---|
| Nikita Tihhomirov | `nikita.tihhomirov@camunda.com` | Marketing Manager |
| Kailash Nair | `kailashnair@hsbc.com` | Global Head of Commercial Cards |

Kailash's address is an HSBC one. He is listed as a client contact because he presents the
demo from that mailbox, not because a bank employee would really be one.

### Presenter cards

Each presenter also holds **one card per scenario** under Burj Khalifah Travel, in their own
name, so the e-mail can come from a real mailbox about a real-looking card and the robots
read that person's name back off MiVision, eChamps and the rest. The numbers are Luhn-valid
and sit on the client's `5550-4100` BIN, which is what the MiVision robot checks against the
first eight digits quoted in the e-mail.

| Scenario | Nikita Tihhomirov | Kailash Nair |
|---|---|---|
| S1 Insufficient spend limit | `5550-4100-9902-1010` | `5550-4100-9903-1019` |
| S2 Fraud alert block | `5550-4100-9902-2026` | `5550-4100-9903-2025` |
| S3 MCC restriction | `5550-4100-9902-3032` | `5550-4100-9903-3031` |
| S4 MID restriction | `5550-4100-9902-4048` | `5550-4100-9903-4047` |
| S5 Incorrect expiry date | `5550-4100-9902-5052` | `5550-4100-9903-5051` |
| S6 Incorrect CVV | `5550-4100-9902-6068` | `5550-4100-9903-6067` |
| S7 Virtual card — amount range | `5550-4100-9902-7074` | `5550-4100-9903-7073` |
| S8 Virtual card — expiry mismatch | `5550-4100-9902-8080` | `5550-4100-9903-8089` |
| S9 POS / network decline | `5550-4100-9902-9096` | `5550-4100-9903-9095` |

The same table is on the simulator home page under **Demo Cards**, and the mailer can send
any of them for you:

```
python3 demo/send_demo_email.py nt-s6 --v3      # Nikita, incorrect CVV
python3 demo/send_demo_email.py kn-s2 --v3      # Kailash, fraud block
python3 demo/send_demo_email.py reply <caseId> "Thanks, that worked." --v3 --as nt
```

Behind each card sit the records that scenario needs: a DQM case, a MiVision card with its
unposted transaction, an eChamps authorisation row (physical cards) or an SDG2 purchase
request (virtual ones), and for S9 a GHCS ticket and a Mastercard Connect case.

To add, rename or remove a presenter, edit `PRESENTERS` in
`hsbc-ccs-simulator-local/src/data/presenters.ts` — that one entry generates the cards and
every system record behind them — mirror the entry in `demo/send_demo_email.py`, run
`npm run check:seed`, then rebuild and re-serve the simulator.

## Deploy

Deploy the whole set together — called processes, DMNs and forms use
`bindingType="deployment"`, so a partial deploy binds against the wrong versions.

```
cd process-v3 && c8ctl deploy *.bpmn dmn/*.dmn forms/*.form rpa/*.rpa --profile hsbc-cards
```

Deploying this does **not** disturb v2: different ids mean new definitions at version 1,
not new versions of v2's.

**Superseded versions: when they matter.** On 8.9 the connector runtime keeps an inbound
connector active for the latest version of a definition *and* for any older version that
still has instances waiting on a message subscription — which every parked v3 case has
(`AwaitCustomerReply`, `AwaitFraudTeamReply`). Those older versions are not dormant.

What stops that from double-starting cases is **cross-version deduplication**: when the
inbound configuration is byte-identical across versions, the runtime consolidates them into
one subscription. Verified on 2026-11-06 — versions 4 and 5 both ACTIVE, one e-mail, exactly
one case (on version 5).

So you only need to delete a superseded version when its inbound configuration *differs*
from the new one — which is what the subject tag and dedup-id changes above did. Identical
configs are safe to leave. `c8ctl` cannot delete a process definition; it needs
`POST /v2/resources/{processDefinitionKey}/deletion` (see `recent-changes.md`). `c8ctl list
pd` does not filter on state and keeps printing deleted rows — use `c8ctl get pd <key>` to
read the real state.

Deleting a version cancels its running instances, so prefer leaving it when the configs match.

## Run it

```
python3 demo/send_demo_email.py <scenario> --v3
python3 demo/send_demo_email.py reply HSBC-V3-<n>-1 "<text>" --v3
python3 demo/send_demo_email.py fraud-reply HSBC-V3-<n>-1 keep --v3
```

`--v2` and `--v3` are mutually exclusive and the script rejects both at once.
Everything else in `new_demo_flow.md` applies unchanged, substituting the v3 tags.

## The DQM robot opens the sender's own case

The robot walked the case list and stopped at the first case matching the sender *either* by
From address *or* by the External Contacts table. Every case of a client carries the same
contacts table, so the first case in the list always won: a mail from a presenter opened
Jasmin Al Rashid's case, with her name and her card on screen. Adding the presenter cases
made the other half worse — an unrecognised sender matched nothing and walked all 28 cases,
two page loads each.

Both halves come from the same cause: the list showed nothing about who sent a case, so the
only way to test a row was to open it. The case list now has a **Contact** column
(`case-contact-<caseId>` carries the From address), which a real case queue would show
anyway, and `Order Candidates` in the robot uses it:

1. every case the sender actually sent, identified from the list without opening anything;
2. then one case per remaining distinct client — one is enough, because every case of a
   client shows the same External Contacts table.

| Sender | Cases opened before | After |
|---|---|---|
| A presenter (`nikita.tihhomirov@camunda.com`) | 1 — Jasmin's, the wrong person | 1 — their own |
| A seeded contact (`jasmin@…`) | 1 — hers | 1 — hers, unchanged |
| An unknown sender | 28, then `CUSTOMER_NOT_FOUND` | 1, then `CUSTOMER_NOT_FOUND` |

The outputs are unchanged, including the `NOT_FOUND` contract the unauthorised-sender route
depends on. The robot falls back cleanly on a simulator build without the Contact column:
the first group is empty and it degrades to one case per client.

`bindingType` is absent on the `zeebe:linkedResource`, so it defaults to `latest` and the
robot deploys on its own:

```
c8ctl deploy rpa/dqm-customer-lookup.rpa --profile hsbc-cards
```

## Mentor sees the fraud team's answer

The Mentor approval form (`forms/mentor-approval-v3.form`) showed the draft, the customer's
last message and the rework history, but nothing about what the fraud team actually replied
— even though `fraudTeamSummary` was already being fed into the drafting prompt. On a fraud
case that meant approving "your block has been removed" without seeing the sentence it came
from. The form now carries a `Text_FraudSummary` block, hidden when `fraudTeamSummary` is
empty, so it appears only on the fraud branch.

The form is bound with `bindingType="deployment"`, so this needed the whole set redeployed
rather than the form alone.

**The form block alone was not enough.** `fraudTeamSummary` never reached COMM on the path
that creates a Mentor task: the agent mapped it into `CallActivity_SendFraudEmail` (the
internal fraud-team mail, which has no Mentor) but not into `CallActivity_SendCustomerEmail`.
The variable was absent, the conditional hid the block, and the change was inert — confirmed
on a live v5 run, where the Mentor task had no `fraudTeamSummary` at all. The call activity
now maps it:

```
source: =if get value(ledger, "latestFraudInterp") = null then null
        else ledger.latestFraudInterp.fraudTeamSummary
target: fraudTeamSummary
```

`get value` rather than `is defined` so a `ledger` without the key returns null silently
instead of raising a FEEL warning. On a non-fraud email the result is null and the block
stays hidden, which is what the conditional is for. Fixed 2026-11-06, deployed as version 6.

## The PCI guard knows the v3 case tags

`Task_PciScan` in `hsbc-customer-communication-agentic.bpmn` refuses any outbound body that
still contains 12 or more consecutive digits. A case id is a 17-digit timestamp, so the scan
strips case references before counting — but the pattern it stripped was copied from v2 and
only knew `HSBC-AGT-…` and `HSBC-AFR-…`. Every v3 tag (`HSBC-V3-…`, `HSBC-AFV3-…`) survived
the strip and was read as a card number, so the fraud-team email on the S2 branch came back
`REFUSED` / `PCI_PATTERN` and the case fell through to a handover task.

The pattern is now `HSBC-(AGT|AFR|AFV3|V3)-[0-9]+(-[0-9]+)?`, which keeps v2's references
exempt as well. A genuine PAN in the body is still refused — the digits of a card number are
not preceded by a case tag, so nothing about the real check changed.

The same strip pattern exists **twice**: in COMM's `Task_PciScan` and in the `EmailCustomer`
guard in `hsbc-decline-request-agent.bpmn`. Both had to be changed. The guard copy never
fired in testing because the agent puts the case tag in the subject, which COMM adds, not in
the body it drafts — but any draft quoting the case reference would have been refused with
the same misleading "possible card or account number" message.

Found and fixed 2026-11-06: COMM in version 5, the agent guard in version 6.

## A missing decline is a diagnosis, not a missing detail

S7, S8 and S9 all ended by emailing the customer to re-confirm the date, amount, merchant and
last four — details they had already given correctly. The cause was in the eChamps robot: it
collapsed three different situations into one `notFoundReason = NO_MATCHING_AUTH`, and
`RecordNotFoundAction_V3` mapped that to `REQUEST_COMPLETE_DETAILS`. Since the rule above it
already catches incomplete details, that rule only ever fired when the details *were*
complete — exactly when asking again cannot help.

The signal needed was already in the robot. `Select Auth Row` filters on
`'DECLIN' in finalAction` *before* it filters by date and amount, so the count of declined
rows on the card separates a near miss from an absence:

| situation | declined rows | reason now emitted | action |
|---|---|---|---|
| virtual card: no authorisation table at all | n/a | `NO_AUTH_RECORDS` | escalate — evidence is in SDG2 / InControl |
| rows exist, none is a decline (S9's `No Record`) | 0 | `NO_DECLINE_ON_CARD` | escalate — network path, GHCS then Mastercard Connect |
| declines exist, none matches the stated date | > 0 | `NO_MATCHING_AUTH` | ask the customer, **unchanged** |

`cardForm` (`VIRTUAL` / `PHYSICAL`) was already returned by the MiVision robot and consumed by
nothing; it is now an input of the decision, so the virtual rule can name SDG2 rather than
give generic wording. `ESCALATE_RECORD_NOT_FOUND` already maps to
`RECORD_NOT_FOUND_ESCALATION`, which the agent playbook answers with `HandToTeam`, so no agent
or prompt change was needed.

Changed: `rpa/echamps-decline-investigation.rpa` (three reasons, plus `declinedRowCount` and
`authRowCount`), `hsbc-tool-investigate-card-decline.bpmn` (passes `cardForm`),
`dmn/record-not-found-action.dmn` (new `cardForm` column, three rules before the
`NO_MATCHING_AUTH` rule).

Verified 2026-11-06 on live runs: 7074 and 8080 gave `VIRTUAL` / `NO_AUTH_RECORDS`, 9096 gave
`PHYSICAL` / `NO_DECLINE_ON_CARD`, all three routed to `RECORD_NOT_FOUND_ESCALATION` and
produced a handover task carrying the right guidance, with **no customer email sent**. The
four unchanged paths (near miss, incomplete details, `CUSTOMER_NOT_FOUND`, already-asked) were
re-checked against the deployed decision and still ask the customer or escalate as before.

## The listeners poll the plus-tag folder, not INBOX

The demo mailbox is a plus address (`c8-saas+<tag>@mailserver.camunda-it.rocks`) on a shared
server, and the server sieve-files plus-addressed mail into `INBOX.<tag>` — there are ~56 such
folders, one per demo. Mail delivered over SMTP therefore never lands in `INBOX`.

`send_demo_email.py` appends over IMAP instead of sending, so it bypasses the sieve rule
entirely. That is why every scripted scenario worked while a real e-mail from a mail client was
silently ignored: it arrived correctly, with the right subject tag, into a folder nothing was
listening to.

All five inbound listeners now poll `INBOX.2026-11-03-nikita-nt-dec-06`:

| File | Element |
|---|---|
| `hsbc-agentic-triage.bpmn` | `StartEvent_EmailReceived`, `Catch_CustomerReply` |
| `hsbc-decline-request-agent.bpmn` | `Start_CustomerReply`, `Catch_FraudTeamResponse` |
| `hsbc-request-late-reply-wait.bpmn` | `Catch_LateReply` |

The two `mailFolder` inputs that feed the inline-image RPA script were changed with them — it
re-reads the original mail by message id and would otherwise look in the wrong folder.

`send_demo_email.py` now derives the folder from `INBOUND_MAIL_ADDRESS` (`mail_folder()`:
plus tag → `INBOX.<tag>`, no plus → `INBOX`) rather than hardcoding it, so the scripted and
real paths cannot drift apart again.

**If the mailbox changes, these seven references change with it.** They are literals because an
inbound connector on a start event has no process instance to read a variable from; a connector
secret would be the alternative. Deployed as version 8 on 2026-11-06.

## Validation at the time of the copy

- `c8ctl bpmn lint` — **0 errors, 0 warnings** on all 8 processes, matching the v2 baseline
- All DMN and BPMN files parse as XML; all 5 forms parse as JSON
- All 9 rules of `SimulatorScenarioFromCard_V3` verified against
  `hsbc-ccs-simulator-local/src/data/seed.ts` — the authoritative card→scenario source
- `--v2` output confirmed byte-identical to before the script change

## Demo timing

The windows a mail-started case cannot override were lowered for the demo, because an
inbound email start carries no variables and so always takes the defaults:

| Variable | Was | Now | What it controls |
|---|---|---|---|
| `conversationWindow` | PT20M | **PT5M** | How long the agent waits for a customer reply after its advice email |
| `lateReplyWindow` | PT1H | **PT5M** | The post-close hold during which a late reply resumes the same conversation |

Unchanged, deliberately: `customerReplySla` PT15M (shortening it risks a premature
`CLOSED_NO_RESPONSE` while a presenter is typing), `fraudTeamSlaDuration` PT10M,
`mentorSlaDuration` PT4H (and `handoverSlaDuration` / `replyHoldMax`, which default to it
— a mentor wait that expires mid-demo is worse than a long one), `requestResolutionSla`
PT2H and `firstResponseSla` PT24H.

Both windows are set in two places and both were changed: `Task_InitialiseCase` in
`hsbc-agentic-triage.bpmn`, and the request agent's own fallbacks in
`hsbc-decline-request-agent.bpmn` (used when the agent is started directly). Pass the
variables at start to override, as before.

Tail after the final email is now about 10 minutes worst case instead of about 80.

## Verified runs

**2026-11-05 — v3 version 2, local simulator build.** Two end-to-end runs of the CVV
journey (card ending 8801, `5550410099018801`), started manually with the s4 email body:

| | run 1 (`6755399443115826`) | run 2 (`4503599629510889`) |
|---|---|---|
| `simulatorBaseUrl` at start | `http://localhost:8080` | **not set** (propagates as `null`) |
| Robots' `evidence.simulatorBaseUrl` | `http://localhost:8080` | `http://localhost:8080` |
| `closeStatus` | RESOLVED | RESOLVED |
| `emailsSent` | 1 | 1 |
| Tool sequence | 4 calls | 4 calls |
| Incidents | none | none |

Run 2 is the one that matters: it reproduces the **mail-started condition**, where no
variable can be supplied, and the robots still reached the local build from their own
default. `simulatorScenario` and `scenarioSource` do not exist on either instance —
`c8ctl search vars --name simulatorScenario` returns nothing. Pages hit include
`/echamps/card/8801/auths`, `/mivision/accounts/BKT001/list` and
`/dqm/cases/HSBC-9103999-44T2W9/email`: every page addressed by card or account, none
by scenario. MiVision's `/mivision/security` MFA step ran unchanged.

Deployed state: v3 at **version 2**; the seven version-1 definitions were deleted via
`POST /v2/resources/{key}/deletion` so that only one inbound email subscription per
listener remains (two live versions would start two cases per email). `c8ctl list pd`
still prints deleted rows — `c8ctl get pd <key>` shows `state: DELETED`.
