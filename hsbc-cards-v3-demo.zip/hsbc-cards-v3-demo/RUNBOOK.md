# Running the HSBC Commercial Cards agentic demo (v3) from scratch

Written for someone who has **not** seen this project before. Follow it in order. Steps 1–6 are
one-time setup; step 7 onwards is what you do each time you present.

Budget about 90 minutes for a first run, most of it waiting on accounts and the model.

---

## What the demo is

A commercial-card customer e-mails to ask why their card was declined. An AI agent runs the
investigation the way a human analyst would: it opens the case in a CRM, looks the card up in
one back-office system, finds the declined authorisation in another, applies the bank's own
decision tables, and drafts a reply. A human ("the Mentor") approves every customer e-mail
before it is sent. Where the agent cannot help, it hands over to a person with its evidence
attached.

The back-office systems are a **simulator** you run locally. The agent drives it through a real
browser using RPA, exactly as it would drive the real screens.

---

## 0. What you need

| | Why |
|---|---|
| **Camunda 8.9 SaaS cluster** (Orchestration Cluster) | runs the processes |
| **An API client** on that cluster, with the **RPA** role among its scopes | deployment + the RPA worker |
| **An LLM** — AWS Bedrock (default) or another supported provider | the agent |
| **An IMAP/SMTP mailbox** you control | the demo's inbox |
| **Node.js 20+** | the simulator |
| **Python 3.9+** | the demo mailer |
| **Google Chrome** | the RPA worker drives it |
| **`c8ctl`** | deploy and operate |
| **Camunda RPA worker** 1.3.2+ | runs the `.rpa` scripts |

macOS and Linux are the tested platforms. Windows should work but is untested.

---

## 1. Install and connect `c8ctl`

```bash
npm install -g @camunda/c8ctl        # or see the Camunda docs for other install routes
c8ctl --help
```

Create a profile for your cluster. You need the client ID, client secret, cluster base URL,
OAuth URL and audience from the SaaS console (**Clusters → your cluster → API → Create client**,
with the **RPA** scope ticked as well as Zeebe/Operate/Tasklist).

```bash
c8ctl use profile <name>            # follow the prompts, or edit the profile file directly
c8ctl cluster --profile <name>      # should print your cluster, not an error
```

Everywhere below, replace `--profile hsbc-cards` with your profile name. **The flag is not
optional** — without it `c8ctl` talks to whatever profile is default.

---

## 2. Create the connector secrets

In the SaaS console, **Clusters → your cluster → Connector secrets**, create these eight. The
models reference them as `{{secrets.NAME}}` and will fail at runtime if any is missing.

| Secret | Value |
|---|---|
| `INBOUND_MAIL_SERVER` | your mail host, e.g. `mail.example.com` |
| `INBOUND_MAIL_USER` | mailbox login |
| `INBOUND_MAIL_PASSWORD` | mailbox password |
| `INBOUND_MAIL_ADDRESS` | the address mail is sent to |
| `INBOUND_MAIL_IMAP_PORT` | usually `993` |
| `INBOUND_MAIL_SMTP_PORT` | usually `587` |
| `AWS_ACCESS_KEY_ID` | Bedrock access key |
| `AWS_ACCESS_KEY_SECRET` | Bedrock secret |

`connectors.env.example` in this package lists the same keys for the local mailer script. Copy
it to `connectors.env`, fill it in, and **never commit it**.

Not using Bedrock? The model is chosen by the `llmModelId` process variable, set on the start
of `hsbc-agentic-triage.bpmn`. Change it there and swap the two AWS secrets for your provider's.

---

## 3. Point the listeners at your mail folder

**Do this before deploying, and read `MESSAGE-CORRELATION.md` §4 if you want to know why.**

If your mailbox is a plain address and mail lands in `INBOX`:

```bash
scripts/set-mailbox-folder.sh INBOX
```

If your address is plus-tagged (`user+tag@host`) and your server files such mail into a
subfolder:

```bash
scripts/set-mailbox-folder.sh INBOX.tag
```

**How to find out which**: send yourself one e-mail and look at which folder it lands in. Do not
assume `INBOX`. A mismatch here is silent — every scripted test passes and every real e-mail is
ignored, because the mailer appends over IMAP and bypasses the server's filing rules.

---

## 4. Deploy

Everything must go in **one deployment**: the call activities, DMNs and forms use
`bindingType="deployment"`, so a partial deploy binds against the wrong versions.

```bash
cd process
c8ctl deploy *.bpmn dmn/*.dmn forms/*.form rpa/*.rpa --profile hsbc-cards
```

Expect 7 processes, 10 decisions, 5 forms and 4 RPA resources. Check for errors; a `Process`
row for each `*_V3` id means it worked.

```bash
c8ctl list pd --profile hsbc-cards | grep _V3
```

**On redeploying**, see `MESSAGE-CORRELATION.md` §5 — if you changed anything in a listener
(tag, folder, condition), the old version keeps listening too and you should delete it.

---

## 5. Run the simulator

The eight back-office screens the robots drive.

```bash
cd simulator
npm install
npm run build
npx serve -s dist/public -l 8080
```

Open <http://localhost:8080>. You should see the system tiles and a **Demo Cards** section
listing the presenter cards. Leave it serving.

Port 8080 is where the robots look by default. To use another, set the `SIMULATOR_BASE_URL`
process variable on the triage start event.

Nothing needs selecting on that home page. Every screen is addressed by card or account number
taken from the e-mail — the old scenario selector is gone. The only thing the selector still
picks is which demo MFA code the SDG2 and Mastercard login screens expect.

---

## 6. Start the RPA worker

```bash
cd ~/Downloads/rpa-worker_1.3.2_<your-platform> && ./rpa-worker_1.3.2_<your-platform>
```

Configure it with the same API client credentials, and **`secrets.backend=camunda`** so it can
read the connector secrets. Wait for `Accepting Zeebe jobs for tags` in its log.

Without the worker, cases stop at the first lookup with no incident and no error — they simply
sit there. If a case stalls early, check this log first.

---

## 7. Send the first e-mail

Two ways. **Both must target the folder you configured in step 3.**

### From your own mail client (what a real demo looks like)

```
To:      <your INBOUND_MAIL_ADDRESS>
Subject: [HSBC-CARDS-V3] Card declined at Emaar Malls

My card 5550 4100 9902 6068 was declined at Emaar Malls on 22/06/2026.
Amount AED 620. Could you tell me why?

Kind regards,
Nikita Tihhomirov
Burj Khalifah Travel LLC
```

Rules that are easy to get wrong:

- The subject **must contain `[HSBC-CARDS-V3]`**. No tag, no case.
- It must be a **new message, not a reply** — an `In-Reply-To` header routes it elsewhere.
- It must **arrive within 10 minutes** of being sent, or it is ignored in silence.
- The **sender address must be a seeded authorised contact**, or the case routes to
  `UNAUTHORISED_SENDER`. See `TEST-DATA.md` for who is authorised.
- Put a **card number or last four digits** in the body, or the agent will (correctly) write
  back to ask for them.

### From the scripted mailer

```bash
python3 demo-mailer/send_demo_email.py list          # all scenarios
python3 demo-mailer/send_demo_email.py nt-s6 --v3    # one of them
```

The script appends over IMAP, so it needs `connectors.env` from step 2. It never prints
mailbox details.

---

## 8. Watch it run

```bash
c8ctl list pi --profile hsbc-cards | grep Agentic_Triage_V3    # the case
c8ctl list ut --profile hsbc-cards                             # human tasks
c8ctl search inc --profile hsbc-cards                          # incidents
```

Or use Operate and Tasklist in the SaaS console — better for an audience.

A case takes **1–3 minutes** to reach its first human task: the robots take ~50 s each and the
model adds a few turns.

### Completing the human tasks

- **Approve customer email** (the Mentor) — needs all five fields: `approvedSubject`,
  `approvedBody`, `decision` (`APPROVE` | `REWORK` | `REJECT` | `ESCALATE`), `comments`,
  `mentorName`.
- **Hand request to the team** — the handover. Read `notFoundGuidance`; it names the system to
  go to.

Outbound mail is redirected to the `demoEmailRedirect` variable and prefixed
`[DEMO] Intended recipient: <address>`. Keep that inbox on screen — it is half the demo.

**That address is a literal in the model, not a setting.** It is on **line 17** of
`process/hsbc-agentic-triage.bpmn`, in the `Task_InitialiseCase` script, together with
`fraudTeamEmail`. A case started by e-mail has no caller to override it, so the literal *is*
the value: change both and redeploy, or every e-mail the demo sends goes to the original
author's inbox with no error of any kind. Full instructions in
`SETUP-AND-CONFIGURATION.md` §2.

---

## 9. Scenarios

`SCENARIOS.md` lists all 18 (9 per presenter), the card each uses, what the systems hold behind
it, and the expected outcome. `TEST-DATA.md` has the full card, account and contact data.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| E-mail sent, nothing starts | wrong folder | step 3; check which folder the mail actually landed in |
| E-mail sent, nothing starts | missing `[HSBC-CARDS-V3]` | add the tag |
| E-mail sent, nothing starts | arrived > 10 min after sending | re-send |
| E-mail sent, nothing starts | it was a reply (`In-Reply-To`) | compose a new message |
| Case stalls at the first lookup | RPA worker down, or Chrome missing | step 6; look for `Received Job from Zeebe` |
| Case stalls at a lookup | simulator not served on 8080 | step 5 |
| One e-mail starts two cases | two versions with *different* inbound config | `MESSAGE-CORRELATION.md` §5 |
| Reply ignored | subject tag lost, or delivery delayed past the window | keep the tag; re-send |
| `REFUSED` / `PCI_PATTERN` | body contains 12+ consecutive digits | expected if you pasted a card number |
| Model errors / 404 | wrong `llmModelId`, or region without that model | step 2 |
| Agent asks for details already given | may be correct — see `SCENARIOS.md` for which scenarios legitimately ask | — |

**Do not leave the demo mailbox open in a mail client during a run.** It is not fatal — the
connector re-reads all messages, not just unread ones — but a client that moves or files mail
will take messages out of the polled folder.
